# (Timing on cpu=x86-L6-R0806 host=BUTTERCUP)
#  (_goto:                   0.02)
Vertex 1  -14.3756 -3.86579 -3.23286
Vertex 2  -13.2439 -3.91144 -0.885273
Vertex 3  -11.38 -13.9645 0.0900178
Vertex 4  -8.91671 1.21805 -2.35035 {wid=139 normal=(0.877147 -0.283488 0.387617)}
Vertex 5  -4.47238 -40.1122 -5.88958
Vertex 6  -8.85841 -27.1986 -2.76198
Vertex 7  -6.78819 -40.8417 -4.09376
Vertex 8  -4.67008 -40.3637 -0.63966
Vertex 9  -3.53316 12.8103 -5.35875
Vertex 10  -3.02809 20.0013 0.844792
Vertex 11  -2.82287 18.6263 -1.60159
Vertex 12  -3.01367 17.7145 1.2887 {wid=12 normal=(-0.977778 -0.144486 0.151904)}
Vertex 13  -2.73716 19.0044 1.75517 {wid=13 normal=(-0.980836 -0.136368 -0.139155)}
Vertex 14  -0.469166 17.8877 2.18496 {wid=1091 normal=(0.35939 -0.916933 0.173412)}
Vertex 15  -0.107195 -13.4529 -1.25434
Vertex 16  0.553317 17.8158 2.13775 {wid=1090 normal=(-0.257664 -0.95258 0.161861)}
Vertex 17  -0.423777 22.3887 -4.40757 {wid=17 normal=(0 0.826484 -0.562961)}
Vertex 18  -0.519603 19.5374 2.55552 {wid=1205 normal=(-0.926347 0.213606 0.310249)}
Vertex 19  -0.449372 22.1147 -3.77166
Vertex 20  -0.265169 20.7487 2.59592 {wid=20 normal=(0.49728 0.834592 0.237002)}
Vertex 21  0.465971 22.1166 -3.57536
Vertex 22  3.09147 21.7398 -2.01515
Vertex 23  1.58847 20.9125 2.06635 {wid=23 normal=(0.371064 0.928418 0.0187263)}
Vertex 24  2.88241 -40.9391 -2.90416
Vertex 25  4.67776 -40.3574 -0.640785
Vertex 26  3.60592 -12.1766 -6.42527
Vertex 27  6.33745 -41.0823 -4.36244
Vertex 28  5.83857 -3.68003 -2.3413
Vertex 29  9.01707 -45.1664 1.25431
Vertex 30  10.4942 -4.21631 -6.03063
Vertex 31  10.5201 -11.0639 -0.283056
Vertex 32  11.1957 -11.88 -4.10927
Vertex 33  12.2469 6.70295 -4.09403 {wid=33 normal=(0.913472 0.125108 -0.387192)}
Vertex 34  13.2817 -3.92108 -1.13676
Vertex 35  12.7806 -10.7257 -0.0248846
Vertex 36  1.60227 -25.8483 -3.68468
Vertex 37  3.19915 -19.9026 -8.04036
Vertex 38  -5.74414 -9.09098 3.62068 {wid=58 normal=(-0.446804 0.0578372 0.89276)}
Vertex 39  3.71204 4.51603 -5.07813
Vertex 40  1.59413 -2.23107 4.59981
Vertex 41  4.95612 13.3753 1.50445
Vertex 42  0.0255721 -11.5215 -6.19993
Vertex 43  -7.03703 -25.7952 -0.958151
Vertex 44  -7.7972 -25.6443 -5.36473
Vertex 45  -3.20875 -19.9696 -8.04827
Vertex 46  8.71316 -23.8758 -3.30307
Vertex 47  8.43853 10.9651 1.19992
Vertex 48  6.70002 -27.4077 -5.98977
Vertex 49  2.28712 -27.5692 -4.95154
Vertex 50  2.55963 -27.5138 -1.27044
Vertex 51  -6.15246 -3.6521 0.852204
Vertex 52  -5.2093 -26.3061 -0.185329
Vertex 53  -3.21772 -27.7598 -1.23922
Vertex 54  4.65216 -3.68285 3.03718
Vertex 55  -5.50245 8.61698 -5.8071
Vertex 56  6.79197 4.43467 2.80853
Vertex 57  -9.09049 10.3008 -6.11475 {wid=4 normal=(-0.213777 0.236735 -0.947763)}
Vertex 58  11.861 -15.8749 -1.32812
Vertex 59  12.6217 11.3726 -1.77157 {wid=34 normal=(0.88911 0.424404 0.17136)}
Vertex 60  3.76464 -26.6899 -0.624774
Vertex 61  3.08744 -41.76 -2.32265
Vertex 62  -10.9788 -11.919 -4.13411
Vertex 63  0.431407 -21.5928 -3.49675
Vertex 64  -13.0277 -11.8973 -4.17459
Vertex 65  -7.99633 -27.441 -3.1367
Vertex 66  -3.39355 -27.5916 -0.470344
Vertex 67  -5.61097 -27.4824 -6.45225
Vertex 68  -8.48785 -21.8375 -6.49986
Vertex 69  6.84195 -33.4223 -5.75951
Vertex 70  6.01745 -20.9654 2.19932
Vertex 71  -4.7936 14.2461 -4.04019
Vertex 72  -4.88496 -45.1493 1.94048
Vertex 73  7.06733 -12.9287 -4.09001
Vertex 74  -9.34854 -19.6317 -7.22713
Vertex 75  4.49077 -45.147 2.16304
Vertex 76  -6.92067 6.74884 3.92207 {wid=92 normal=(-0.676634 -0.0723808 0.732753)}
Vertex 77  2.95397 18.4084 1.40374 {wid=22 normal=(0.977796 -0.0396663 0.205772)}
Vertex 78  2.76088 16.1922 0.291452 {wid=202 normal=(0.950049 -0.308335 0.0483486)}
Vertex 79  8.21877 -22.1618 -5.85489
Vertex 80  -8.76955 -45.1057 1.21356
Vertex 81  -4.63867 -42.7311 2.14056
Vertex 82  -1.94656 -24.0149 -1.47212
Vertex 83  -5.75305 -22.5081 0.458318
Vertex 84  7.97193 -42.45 0.670428
Vertex 85  4.83439 13.988 -4.23019
Vertex 86  3.31231 8.03903 -6.21989 {wid=26 normal=(0.157965 -0.111427 -0.981138)}
Vertex 87  5.9943 -25.7229 -6.96552
Vertex 88  0.797721 -20.1169 -0.22535 {wid=236 normal=(-0.82338 -0.282095 0.49241)}
Vertex 89  1.6087 -31.7839 -2.58458
Vertex 90  -1.55881 -22.2687 -3.26737
Vertex 91  6.18661 -0.845176 -2.61884
Vertex 92  1.6151 -0.836443 4.40002
Vertex 93  -6.53572 -34.4405 -5.21055
Vertex 94  -2.57878 -34.4995 -4.28208
Vertex 95  2.00812 13.314 -3.08167
Vertex 96  -2.42918 11.7076 2.08088
Vertex 97  -2.42366 7.6682 5.20465
Vertex 98  3.41875 10.0465 3.09367
Vertex 99  -11.739 -15.3713 -0.352731
Vertex 100  5.72929 -42.238 2.45997
Vertex 101  -7.29942 -12.8749 -4.04507
Vertex 102  -3.15595 0.697216 -4.2926
Vertex 103  -6.48659 -45.1302 -3.77581
Vertex 104  -4.97235 -26.0512 -0.433961
Vertex 105  -6.61742 -33.3746 -5.7795
Vertex 106  -7.89975 -42.3459 0.693461
Vertex 107  -2.5893 -40.3255 -3.87004
Vertex 108  -5.37622 -34.4109 -1.22053
Vertex 109  -0.737907 -20.1444 -0.23733 {wid=294 normal=(0.82338 -0.282095 0.49241)}
Vertex 110  7.5345 -34.4759 -4.56786
Vertex 111  6.76447 -24.0753 -0.461546
Vertex 112  5.48115 -34.372 -1.29755
Vertex 113  10.9132 -21.3063 -2.75801
Vertex 114  7.74883 14.1504 -2.16018
Vertex 115  6.17288 4.436 -1.70674
Vertex 116  -1.50669 -13.4105 2.79943
Vertex 117  3.06274 -9.32939 3.70347
Vertex 118  2.65081 -34.4506 -2.8018
Vertex 119  6.51399 -45.1258 -3.68446
Vertex 120  3.18591 -40.5901 -4.72335
Vertex 121  -1.68174 0.58044 4.57488
Vertex 122  -10.9643 -21.0857 -3.50677
Vertex 123  11.4039 -15.9248 -2.3348
Vertex 124  -11.261 -15.6566 -2.61278
Vertex 125  13.0673 -15.2295 0.0786137
Vertex 126  -4.47765 -45.2508 -6.1586
Vertex 127  6.63577 12.4643 0.0323712 {wid=351 normal=(-0.425051 0.718633 0.550361)}
Vertex 128  -8.79098 -42.9974 4.66667
Vertex 129  8.80888 -43.0476 4.53862
Vertex 130  -3.09614 -3.66914 3.53702
Vertex 131  -6.15941 10.5971 0.702008 {wid=366 normal=(0.667973 0.197744 0.717432)}
Vertex 132  8.04161 -10.8871 -0.233885
Vertex 133  -3.66187 4.50165 -4.77031
Vertex 134  -7.08084 -40.6214 -2.68282
Vertex 135  3.666 -24.1057 -6.4596
Vertex 136  -7.9537 -10.9145 -0.238715
Vertex 137  2.47491 17.762 -1.40003
Vertex 138  -6.02166 -19.8563 -8.95316
Vertex 139  -0.463176 14.0194 1.18818 {wid=378 normal=(-0.036991 -0.980617 -0.19241)}
Vertex 140  2.8887 0.585479 -4.13139
Vertex 141  -6.59962 0.644756 -0.590611
Vertex 142  -12.7744 -14.8201 0.996438
Vertex 143  -3.09106 13.0124 -4.73222
Vertex 144  2.4435 13.5703 -3.67427
Vertex 145  -5.531 14.2679 0.473959
Vertex 146  -3.42512 10.0537 3.11058
Vertex 147  7.72529 12.113 -5.65334 {wid=399 normal=(-0.225515 0.562587 -0.795386)}
Vertex 148  1.59209 -3.67108 4.15208
Vertex 149  -7.53631 6.94121 0.899117
Vertex 150  5.86885 -2.25298 -2.35069
Vertex 151  -6.24203 -2.2286 -2.27831
Vertex 152  5.93429 -19.9993 -9.07709
Vertex 153  5.7261 -25.8031 -0.296686
Vertex 154  8.47914 -25.6395 -3.11499
Vertex 155  4.47122 -45.1719 -6.24002
Vertex 156  -1.17173 17.1573 -2.55651
Vertex 157  3.11084 20.2514 -0.691003 {wid=203 normal=(0.735789 0.656285 -0.167045)}
Vertex 158  2.66361 15.7842 -2.10565
Vertex 159  -10.8785 -10.7338 -0.0840734
Vertex 160  -8.53912 11.1171 1.53787
Vertex 161  -6.28373 4.4227 -1.75889
Vertex 162  -0.506383 16.7541 -4.57973
Vertex 163  -5.89251 -23.9683 -7.05218
Vertex 164  -2.70621 -25.7568 -0.815913
Vertex 165  -5.57892 -24.0322 -0.214216
Vertex 166  -12.3933 11.4951 -1.44295 {wid=441 normal=(-0.874508 0.457513 0.160991)}
Vertex 167  -2.61229 15.76 -0.392426 {wid=442 normal=(-0.9812 -0.164494 -0.100941)}
Vertex 168  -1.60633 13.6167 -3.61937
Vertex 169  -2.25346 17.3066 3.25616 {wid=447 normal=(-0.471947 -0.375211 0.797799)}
Vertex 170  -8.98303 -23.9008 -3.37477
Vertex 171  -0.0267003 18.9728 4.23535 {wid=448 normal=(0.106452 0.564584 0.818482)}
Vertex 172  5.63897 -2.23954 2.23951
Vertex 173  4.8538 0.597422 3.18119
Vertex 174  9.44212 -19.5581 -7.25077
Vertex 175  0.185489 17.0108 4.04399
Vertex 176  -0.68781 18.2147 4.0791 {wid=461 normal=(-0.835918 0.343169 0.428343)}
Vertex 177  5.39274 14.8879 -1.82191
Vertex 178  1.26906 6.64179 4.95521
Vertex 179  2.43591 11.6988 2.04618
Vertex 180  -1.66747 -3.72614 4.41861
Vertex 181  6.30821 6.43149 -3.23734
Vertex 182  -2.17404 -22.3054 -1.53296
Vertex 183  8.60454 -27.4104 -3.2481
Vertex 184  2.00335 -22.3393 -1.46902
Vertex 185  -0.0428739 15.1913 -3.76675
Vertex 186  1.56421 -13.1418 -4.99122
Vertex 187  3.53885 -22.345 -6.69216
Vertex 188  5.34759 -41.3062 -5.63136
Vertex 189  -3.5756 -22.3378 -6.99728
Vertex 190  7.29627 -45.1703 6.1637
Vertex 191  -11.9469 -15.6676 0.0868933
Vertex 192  -10.3493 -16.7385 -0.883825
Vertex 193  9.06301 -22.1404 -2.9656
Vertex 194  0.0671864 -11.3429 3.00671
Vertex 195  -6.07416 -0.858909 -2.69275
Vertex 196  -5.2596 -0.856364 3.25982
Vertex 197  -0.344442 16.0371 4.0537
Vertex 198  0.48701 18.4413 4.7826 {wid=516 normal=(0.657742 0.387261 0.646068)}
Vertex 199  6.46457 0.601901 -0.615321
Vertex 200  -3.62678 -12.2026 -6.40516
Vertex 201  -1.57007 -13.1388 -5.00301
Vertex 202  11.2086 -13.902 -0.0182479
Vertex 203  9.9777 -13.4804 0.0594021
Vertex 204  10.4507 -12.6906 0.890886
Vertex 205  5.75373 14.98 -1.83337
Vertex 206  2.40959 14.9223 -1.60803
Vertex 207  -4.7141 -45.113 3.03504
Vertex 208  -7.67643 13.3366 -2.10941
Vertex 209  -3.01154 -3.63053 -4.18981
Vertex 210  -1.61328 -3.67005 4.45599
Vertex 211  7.80167 3.8649 -2.87842 {wid=553 normal=(-0.943211 -0.235423 0.234371)}
Vertex 212  -2.46078 23.434 -0.915151 {wid=554 normal=(-0.702746 0.672938 -0.230874)}
Vertex 213  -9.96955 -13.6985 0.0673184
Vertex 214  -11.4245 -13.4966 0.981417
Vertex 215  9.7391 -14.766 1.69886
Vertex 216  10.4198 -15.0698 0.800294
Vertex 217  -2.7417 20.51 2.12796
Vertex 218  -0.297685 22.9223 -3.22114
Vertex 219  -9.13924 -45.1543 3.89635
Vertex 220  0.788815 19.1476 3.47622 {wid=585 normal=(0.170396 0.230385 0.958065)}
Vertex 221  9.24968 -45.0265 3.91617
Vertex 222  -6.83743 -21.6209 1.48569
Vertex 223  -8.7786 -22.1165 -3.14273
Vertex 224  10.4885 -15.6505 -0.165509
Vertex 225  3.10144 17.7064 0.687963 {wid=600 normal=(0.7791 -0.452265 0.43412)}
Vertex 226  10.9385 -15.8433 1.10084
Vertex 227  5.76742 -23.8845 -6.51121
Vertex 228  7.96545 -24.0598 -5.19847
Vertex 229  -3.4344 -33.6756 -6.30944
Vertex 230  11.4452 -4.11524 -0.417455
Vertex 231  -9.86212 -14.7495 0.594899
Vertex 232  -2.42567 14.0404 -3.7514
Vertex 233  -2.42638 14.7589 -1.74606
Vertex 234  -12.5394 -15.943 -3.2349
Vertex 235  -3.20845 -41.3997 -2.19886
Vertex 236  -3.12005 18.2288 0.477592
Vertex 237  12.8682 -15.3864 -1.97822
Vertex 238  -5.54572 14.9932 -1.81168
Vertex 239  -5.28082 12.7677 1.23061
Vertex 240  -10.2534 -15.1959 1.54779
Vertex 241  -9.83152 7.47547 0.998434 {wid=2 normal=(-0.194839 -0.167363 0.966451)}
Vertex 242  9.6596 -15.2593 -0.377026
Vertex 243  -6.14921 6.34786 -3.32253
Vertex 244  10.0743 -15.45 -0.930346
Vertex 245  10.7828 -16.5664 -1.13941
Vertex 246  10.4032 -15.6136 -1.56439
Vertex 247  10.337 -16.5185 0.035071
Vertex 248  10.3911 -16.7625 -0.840373
Vertex 249  -9.67045 -15.2557 -0.381187
Vertex 250  -10.4667 -4.18221 -5.95056
Vertex 251  6.38373 -17.8161 3.2247
Vertex 252  6.83854 -21.6283 1.52196
Vertex 253  -8.79661 -4.34314 -3.10476
Vertex 254  6.47291 0.497568 -2.55739
Vertex 255  8.44782 -26.7392 -3.04318
Vertex 256  -0.805906 19.0986 3.54303 {wid=706 normal=(-0.27945 0.38993 0.877418)}
Vertex 257  -5.99592 14.9067 -1.78669
Vertex 258  1.03181 22.2243 -4.88045
Vertex 259  -1.24761 24.0838 -5.01933 {wid=712 normal=(-0.571362 0.785019 -0.239356)}
Vertex 260  0.497667 19.7347 3.87302
Vertex 261  6.75785 -41.313 -3.59836
Vertex 262  1.55865 15.2424 -3.07351
Vertex 263  -11.2668 -15.6924 -3.1959
Vertex 264  6.2067 11.8692 -5.23609
Vertex 265  5.90355 9.28167 -5.45022
Vertex 266  7.8395 7.9292 1.61577
Vertex 267  6.26645 5.84336 -2.28328
Vertex 268  7.72849 7.39629 0.492568
Vertex 269  8.15777 9.2822 1.27036
Vertex 270  -6.4042 0.518582 -2.52912
Vertex 271  -4.49816 0.56696 -3.76974
Vertex 272  9.86774 4.45845 0.378865 {wid=745 normal=(-0.0486965 -0.274045 0.960482)}
Vertex 273  2.61794 7.48456 5.33562
Vertex 274  4.75219 13.1103 1.32747
Vertex 275  5.76402 14.0761 0.388149
Vertex 276  -2.6385 -41.0544 -4.15349
Vertex 277  -10.8804 -15.8958 1.09368
Vertex 278  -10.4932 -16.7504 0.756744
Vertex 279  -6.10843 -17.9846 3.23821
Vertex 280  11.1671 -15.697 -3.29266
Vertex 281  10.6988 -16.7401 -2.51587
Vertex 282  11.0226 -15.7049 -2.09582
Vertex 283  -2.22753 0.58253 -4.67741
Vertex 284  4.45101 0.576486 -3.76615
Vertex 285  -1.53248 21.0373 3.94259
Vertex 286  3.14715 20.374 0.281674
Vertex 287  0.666898 -2.22909 -5.07337
Vertex 288  -3.20942 20.3826 -0.519061
Vertex 289  3.37912 19.3735 -1.38891 {wid=801 normal=(0.719157 0.0321009 -0.694105)}
Vertex 290  -9.15441 -22.1505 -4.96108
Vertex 291  -5.91452 0.583607 1.46832
Vertex 292  -4.75134 0.615275 2.8742
Vertex 293  -10.7998 -15.6223 -1.99221
Vertex 294  1.32789 17.2138 -2.3369
Vertex 295  1.35602 -24.0283 -3.27478
Vertex 296  2.73045 20.6664 2.21294
Vertex 297  2.89495 -45.1392 -3.34183
Vertex 298  4.76837e-007 -13.0514 -4.14164
Vertex 299  3.94848 -33.6744 -6.36867
Vertex 300  -3.8254 -25.857 -6.11806
Vertex 301  7.40407 -27.5338 -1.58272
Vertex 302  5.52771 -42.0502 1.69122
Vertex 303  1.60348 -22.2673 -3.26493
Vertex 304  2.00594 7.82099 4.60025
Vertex 305  -3.16275 -45.1691 -3.43199
Vertex 306  -2.87529 17.8751 -0.732915 {wid=853 normal=(-0.528729 -0.667326 -0.524521)}
Vertex 307  0.649269 17.2509 -2.68754
Vertex 308  1.94641 17.4604 -1.92872
Vertex 309  -2.4961 17.6403 -1.28536
Vertex 310  -10.8167 -15.6511 -1.151
Vertex 311  -6.57619 12.8345 -4.75827
Vertex 312  -5.99647 10.1211 -5.50901
Vertex 313  10.5233 -16.7412 0.743841
Vertex 314  12.686 -14.821 0.997522
Vertex 315  -0.369117 15.6815 -6.06674 {wid=876 normal=(-0.23267 -0.187831 -0.954244)}
Vertex 316  -0.998756 19.9313 3.97706
Vertex 317  -2.66303 18.5675 3.1131 {wid=881 normal=(-0.766587 0.135935 0.627587)}
Vertex 318  2.46237 16.3795 2.67145 {wid=882 normal=(0.921417 -0.227391 0.315095)}
Vertex 319  0.420899 13.3324 1.05624 {wid=883 normal=(0.103639 -0.45632 0.883759)}
Vertex 320  1.14255 16.559 -4.82995
Vertex 321  4.62733 -45.1553 3.0071
Vertex 322  6.125 6.82661 -3.18355
Vertex 323  6.75103 6.53033 -1.44494
Vertex 324  -1.52187 -27.5156 -3.29634
Vertex 325  -10.8549 -16.5556 -2.03259
Vertex 326  -0.314657 -21.5995 -3.73165
Vertex 327  -9.55496 -15.537 -1.5397
Vertex 328  4.79059 -39.7889 -0.900656
Vertex 329  -3.31456 19.0478 -1.00156 {wid=918 normal=(-0.979045 -0.179876 0.09548)}
Vertex 330  -4.62825 -39.8446 -1.20104
Vertex 331  12.8852 -11.833 -3.96571
Vertex 332  -0.679708 17.7741 4.07388 {wid=923 normal=(-0.50033 0.022997 0.86553)}
Vertex 333  -2.5112 0.545159 5.30526
Vertex 334  -0.870999 22.7244 -4.05673
Vertex 335  -9.46168 -15.8051 0.796728
Vertex 336  -12.7447 -10.7742 -0.305666
Vertex 337  8.18027 -42.5835 1.41097
Vertex 338  8.40012 -45.1573 0.373238
Vertex 339  -5.5639 9.99164 -3.63261 {wid=942 normal=(0.956928 -0.141918 -0.253274)}
Vertex 340  3.0336 12.9396 -4.38648
Vertex 341  12.4454 -12.9836 0.444387 {wid=35 normal=(0.646524 0.194492 0.737686)}
Vertex 342  11.7474 -13.5065 0.983589
Vertex 343  9.27921 -15.9483 -0.422304
Vertex 344  9.42178 -16.2864 0.169574
Vertex 345  8.76873 -15.6991 0.0715745
Vertex 346  0.897081 18.0401 3.84769 {wid=961 normal=(0.811938 0.269568 0.517773)}
Vertex 347  12.5588 -15.7014 -3.39348
Vertex 348  10.7175 -16.6802 -2.05073
Vertex 349  10.1002 -15.2172 -1.78344
Vertex 350  -4.3019 -3.70344 2.73797
Vertex 351  6.08431 -45.0643 -4.48447
Vertex 352  0.826881 -12.8119 2.05513
Vertex 353  -10.0599 -15.4023 -0.137505
Vertex 354  -10.873 -14.7914 0.357585
Vertex 355  -10.3545 -15.7175 0.788234
Vertex 356  -10.5049 -15.8896 0.150517
Vertex 357  -10.6144 -15.1098 -0.953431
Vertex 358  -6.24319 -44.9055 -4.42387
Vertex 359  -9.53459 -14.5261 1.48751
Vertex 360  -8.69963 -15.7938 0.041062
Vertex 361  9.5767 -15.6762 0.999151
Vertex 362  -10.3291 -16.5343 0.0133891
Vertex 363  -4.83232 -43.2689 2.92905
Vertex 364  -3.17283 -40.8785 -5.42335
Vertex 365  -0.0326753 23.0461 -2.76806
Vertex 366  -10.5548 -16.6295 -2.74489
Vertex 367  9.46939 -15.9416 0.248589
Vertex 368  10.8069 -14.8523 0.15662
Vertex 369  10.4491 -15.8623 0.433111
Vertex 370  -0.736323 -11.923 2.85594
Vertex 371  -0.0758101 -13.0023 0.423076
Vertex 372  0.85238 23.5635 -3.43904
Vertex 373  -1.74077 19.6832 3.1359 {wid=1046 normal=(-0.581902 -0.0223933 0.812953)}
Vertex 374  -3.29336 19.4324 -1.41036 {wid=1047 normal=(0.0584221 0.174898 -0.982852)}
Vertex 375  2.09948 19.3311 2.64264 {wid=1048 normal=(0.0210598 0.440985 0.897267)}
Vertex 376  -5.16687 4.55425 4.83498
Vertex 377  3.45873 -31.8071 -6.72568 {wid=1050 normal=(-0.511713 -0.142072 -0.847328)}
Vertex 378  4.75988 -43.2371 2.8958
Vertex 379  5.74669 8.44477 -3.06635 {wid=1055 normal=(-0.842099 -0.489372 -0.226681)}
Vertex 380  -4.16978 -0.819194 -4.36776
Vertex 381  -11.0278 -21.2912 -2.73216
Vertex 382  -8.37255 -26.837 -2.96613
Vertex 383  -4.4583 -40.9059 -6.16189
Vertex 384  0.688528 20.4019 4.21256
Vertex 385  4.44212 -40.9597 -5.99721
Vertex 386  2.82426 -40.7071 -5.11122
Vertex 387  4.195 -39.9232 -6.01059
Vertex 388  1.3914 19.1464 -4.53703 {wid=21 normal=(0.767251 0.0932487 -0.634532)}
Vertex 389  -7.66757 13.8088 -2.7484 {wid=1076 normal=(0.191004 0.978195 -0.0815549)}
Vertex 390  -2.15506 11.6116 0.0740766
Vertex 391  3.54141 19.9218 -0.391527 {wid=1078 normal=(0.992371 0.114488 0.0457449)}
Vertex 392  -8.38023 -45.1597 0.393699
Vertex 393  -3.24852 20.2247 -1.88136 {wid=1083 normal=(-0.946636 0.0242925 -0.321387)}
Vertex 394  10.9949 -21.0838 -3.49705
Vertex 395  -7.32166 -45.1748 5.91531
Vertex 396  2.83606 18.5675 1.9227 {wid=16 normal=(0.878035 -0.461044 -0.128422)}
Vertex 397  -1.79034 19.0641 3.53123 {wid=14 normal=(-0.333058 -0.0977444 0.937826)}
Vertex 398  10.0934 -15.2641 -2.65495
Vertex 399  2.88924 18.2704 -0.990787 {wid=1096 normal=(0.391379 -0.537666 -0.746819)}
Vertex 400  -8.10151 -22.0554 -5.57651
Vertex 401  1.37854 -9.09172 3.82407
Vertex 402  1.62025 -3.66876 4.42299
Vertex 403  3.0271 -3.66973 3.43257
Vertex 404  2.90024 -21.6697 -7.221
Vertex 405  0.560838 17.5063 4.33783 {wid=1109 normal=(0.362006 0.0207479 0.931945)}
Vertex 406  -10.4419 -15.642 -1.79093
Vertex 407  -10.621 -16.5456 -2.06651
Vertex 408  0 -0.833921 -4.72918
Vertex 409  9.8327 -19.6247 -6.22246
Vertex 410  -6.09235 -22.3913 -0.272462
Vertex 411  3.12272 -45.2782 -5.55673
Vertex 412  -7.8456 13.5431 -1.28205
Vertex 413  -0.885883 -12.5154 2.57181
Vertex 414  4.85203 4.4344 4.40576
Vertex 415  11.8558 6.32746 -1.46537 {wid=1142 normal=(0.863034 -0.15345 0.481273)}
Vertex 416  -3.10513 -45.279 -5.55937
Vertex 417  -1.7023 -33.3913 -3.33368
Vertex 418  -10.071 -15.1503 -1.86829
Vertex 419  -11.6852 -14.8569 -2.39004
Vertex 420  -9.73209 -19.6686 -6.22341
Vertex 421  -3.09014 -21.6247 -7.09353
Vertex 422  -1.77809 19.1789 2.77135 {wid=1163 normal=(0.143863 0.939333 0.311378)}
Vertex 423  -1.90761 -24.0693 -4.91285
Vertex 424  -2.0624 14.8835 2.5245 {wid=1166 normal=(-0.772944 -0.547581 0.320489)}
Vertex 425  3.14715 18.5633 -0.629971 {wid=1167 normal=(0.956454 -0.165272 0.240585)}
Vertex 426  4.27768 -3.65811 -3.69995
Vertex 427  -8.11148 -42.2545 1.44054
Vertex 428  -12.819 -4.03705 -5.8605
Vertex 429  1.73457 20.1469 3.72136
Vertex 430  2.07982 -32.4758 -3.03414
Vertex 431  1.58374 -3.66501 -4.38958
Vertex 432  2.35549 -3.67029 -4.60815
Vertex 433  -3.08527 -3.68338 -4.53036
Vertex 434  -5.92834 -3.66995 -2.37695
Vertex 435  -5.71109 -3.63324 -2.41677
Vertex 436  -4.76022 -2.25611 2.90123
Vertex 437  -1.29697 6.63658 4.84261
Vertex 438  -2.00594 7.82099 4.60024
Vertex 439  13.7017 -3.97233 -5.49777
Vertex 440  1.86509 16.865 3.16475
Vertex 441  -5.95337 6.29254 -3.33579
Vertex 442  -7.36906 7.13952 -0.0530487
Vertex 443  0.975867 19.2132 3.75327 {wid=18 normal=(0.023765 -0.106922 0.993983)}
Vertex 444  -3.20339 18.9612 -0.0699999 {wid=1206 normal=(-0.936532 -0.164206 0.309749)}
Vertex 445  -10.7479 -11.775 -0.201597
Vertex 446  11.7325 -14.8192 -2.2833
Vertex 447  -2.95964 0.682067 -5.12913
Vertex 448  9.51242 -14.5452 0.663688
Vertex 449  9.66232 -15.4943 -1.59704
Vertex 450  -10.0995 -15.2945 -2.61538
Vertex 451  2.12817 7.85028 4.98224
Vertex 452  0.185614 15.1996 4.34446 {wid=1233 normal=(0.100196 0.00373745 0.99496)}
Vertex 453  -0.550938 17.8907 4.57309 {wid=1234 normal=(-0.235999 -0.909195 0.343033)}
Vertex 454  -0.532349 16.6752 -4.61403
Vertex 455  0.0644774 -13.4405 -1.27604
Vertex 456  -0.0122783 -13.328 -1.96628
Vertex 457  -2.54326 15.4932 -2.39773
Vertex 458  -1.84796 19.462 2.4057 {wid=1245 normal=(0.061397 -0.505155 0.860844)}
Vertex 459  -12.3411 -15.996 -1.22073
Vertex 460  -10.7674 -16.5911 -1.15188
Vertex 461  -3.60535 -45.1077 -2.34667
Vertex 462  -11.2037 -14.624 -0.283627
Vertex 463  6.62741 -26.2697 -0.654005
Vertex 464  5.09683 0.767747 3.44614
Vertex 465  2.44924 11.6349 -0.149674
Vertex 466  -12.2974 -12.9983 0.408601
Vertex 467  -10.3696 -12.8888 1.07322
Vertex 468  3.70485 -45.164 -2.32336
Vertex 469  1.79834 23.4578 1.66485 {wid=1271 normal=(0.489434 0.784272 0.381277)}
Vertex 470  3.03262 19.7534 -2.32247 {wid=1272 normal=(0.940689 0.123313 -0.316066)}
Vertex 471  2.47135 19.0172 3.32158 {wid=1273 normal=(0.471113 0.584278 0.660812)}
Vertex 472  -3.39281 20.2955 -0.475583 {wid=1274 normal=(-0.713061 0.697301 0.0729059)}
Vertex 473  -5.16555 -31.9494 -7.51525 {wid=1275 normal=(-0.0853547 -0.202318 -0.975593)}
Vertex 474  5.0855 -0.854968 2.93104
Vertex 475  8.8179 -21.6007 -6.06545
Vertex 476  3.44543 0.822696 -4.44519
Vertex 477  0.988584 19.2259 3.30935 {wid=1284 normal=(0.64832 0.483339 0.588273)}
Vertex 478  -13.0011 -15.2128 0.188336
Vertex 479  -0.756925 19.5665 3.4105 {wid=1287 normal=(-0.239389 -0.338017 0.910186)}
Vertex 480  6.05225 -22.2642 -0.00249332
Vertex 481  4.77409 -44.9331 1.98304
Vertex 482  2.96342 0.798396 -4.86362
Vertex 483  3.08814 19.3017 0.0694577 {wid=1298 normal=(0.808416 -0.114617 0.577345)}
Vertex 484  -13.762 -3.86161 -3.6504
Vertex 485  -3.0478 21.2282 -1.45188
Vertex 486  -1.05943 16.4705 -2.69848
Vertex 487  -2.42576 13.2844 -3.40238
Vertex 488  8.83169 9.16849 1.79297 {wid=1313 normal=(-0.00794414 -0.0611907 0.998093)}
Vertex 489  8.61003 -4.34742 -4.403
Vertex 490  0.5127 13.7323 3.45682 {wid=1316 normal=(0.261864 -0.869857 0.418062)}
Vertex 491  3.4543 -24.0162 -0.461967
Vertex 492  0.462463 17.9246 4.35236 {wid=1319 normal=(0.354548 -0.81618 0.456231)}
Vertex 493  2.14619 -25.7474 -1.62407
Vertex 494  -1.82672 16.4913 2.79769
Vertex 495  9.47657 6.57277 -5.69194 {wid=1323 normal=(-0.21158 0.098494 -0.972385)}
Vertex 496  9.77556 -16.0658 -1.12065
Vertex 497  10.9797 -14.8563 -1.19923
Vertex 498  -1.71357 -25.7669 -3.74938
Vertex 499  1.19771 24.1053 -4.82298 {wid=1332 normal=(0.498938 0.824721 -0.266264)}
Vertex 500  -1.93894 16.6495 -3.93417 {wid=1333 normal=(-0.612985 -0.118062 -0.781224)}
Vertex 501  6.50885 -40.4057 -1.52082
Vertex 502  6.99561 -40.6767 -2.82018
Vertex 503  -11.4504 -4.11521 -0.375108
Vertex 504  0.987748 19.6746 3.234 {wid=1344 normal=(0.511862 -0.452178 0.730434)}
Vertex 505  -0.754679 -21.524 -3.04537
Vertex 506  -9.53379 -16.0122 -0.332581 {wid=1347 normal=(-0.513615 -0.625231 -0.587611)}
Vertex 507  11.1701 -14.6158 -0.236384
Vertex 508  5.50706 7.81729 -5.36651
Vertex 509  11.4575 -14.948 -0.521878
Vertex 510  11.0284 -14.7384 -0.823083
Vertex 511  11.3469 -15.4245 -0.168961
Vertex 512  -6.97535 6.25243 -1.62884 {wid=1369 normal=(0.828151 -0.495365 0.262257)}
Vertex 513  3.25664 20.3206 -0.701967
Face 1  54 251 132 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 2  62 253 159 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 3  470 158 388 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 4  13 397 20 {mat="nomaterial" groups="default eyer" rgb=(.5 .5 .5) matid=13}
Face 5  388 315 17 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 6  393 11 288 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 7  218 485 365 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 8  470 388 218 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 9  19 17 454 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 10  217 10 12 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 11  139 319 78 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 12  11 374 288 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 13  23 443 396 {mat="nomaterial" groups="default eyel" rgb=(.5 .5 .5) matid=1}
Face 14  439 34 35 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 15  331 32 30 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 16  439 331 30 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 17  31 489 30 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 18  32 31 30 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 19  35 230 31 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 20  32 347 280 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 21  59 33 147 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 22  159 253 503 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 23  234 459 478 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 24  428 166 57 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 25  338 75 119 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 26  24 328 60 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 27  84 338 119 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 28  337 129 29 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 29  103 461 72 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 30  105 5 6 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 31  6 330 52 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 32  6 5 7 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 33  401 180 194 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 34  38 116 350 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 35  114 264 85 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 36  117 251 54 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 37  455 37 63 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 38  186 37 455 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 39  154 48 87 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 40  26 42 426 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 41  298 15 201 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 42  283 284 91 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 43  447 133 39 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 44  160 76 239 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 45  161 141 376 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 46  414 178 376 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 47  56 266 47 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 48  38 381 222 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 49  209 431 42 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 50  65 43 44 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 51  116 38 279 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 52  200 74 101 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 53  200 45 138 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 54  15 45 201 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 55  15 109 505 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 56  26 174 152 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 57  132 251 113 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 58  275 114 205 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 59  273 56 47 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 60  36 49 50 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 61  36 87 48 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 62  48 49 36 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 63  48 377 49 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 64  154 301 48 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 65  154 153 301 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 66  101 435 200 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 67  38 350 51 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 68  107 52 330 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 69  104 6 52 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 70  107 53 52 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 71  107 5 229 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 72  28 54 132 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 73  28 172 54 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 74  149 441 76 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 75  9 86 55 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 76  91 474 172 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 77  199 115 56 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 78  512 131 241 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 79  339 250 57 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 80  202 226 314 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 81  202 32 58 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 82  489 211 30 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 83  415 33 59 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 84  27 183 328 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 85  255 430 60 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 86  24 61 25 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 87  387 188 120 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 88  250 62 64 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 89  250 253 62 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 90  295 303 187 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 91  88 455 63 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 92  503 336 159 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 93  2 1 336 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 94  67 65 44 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 95  66 43 65 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 96  498 324 300 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 97  164 43 66 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 98  324 67 300 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 99  94 108 93 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 100  163 290 189 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 101  44 43 170 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 102  27 69 183 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 103  27 299 69 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 104  111 480 184 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 105  111 193 480 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 106  96 238 145 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 107  9 311 71 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 108  81 72 235 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 109  106 103 392 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 110  26 73 174 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 111  26 28 73 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 112  68 138 45 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 113  122 101 420 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 114  25 302 84 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 115  25 61 75 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 116  196 291 195 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 117  196 92 121 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 118  286 77 225 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 119  212 10 217 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 120  137 78 95 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 121  137 157 289 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 122  193 113 480 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 123  46 227 79 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 124  72 392 103 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 125  207 363 128 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 126  106 81 8 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 127  427 128 363 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 128  189 423 163 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 129  182 83 82 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 130  165 83 170 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 131  165 82 83 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 132  502 84 119 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 133  501 25 84 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 134  9 85 264 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 135  96 179 144 {mat="nomaterial" groups="default neck3" rgb=(.6 .5 .4) matid=4}
Face 136  266 181 268 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 137  39 133 86 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 138  135 87 36 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 139  228 46 87 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 140  70 88 184 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 141  70 117 88 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 142  387 299 27 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 143  24 60 89 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 144  189 90 82 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 145  45 15 326 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 146  150 91 172 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 147  150 287 91 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 148  56 464 199 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 149  414 333 464 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 150  67 93 65 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 151  67 473 93 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 152  324 473 67 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 153  66 108 94 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 154  12 167 139 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 155  444 306 167 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 156  143 232 340 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 157  143 238 232 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 158  178 437 76 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 159  98 96 146 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 160  304 98 438 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 161  41 205 177 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 162  3 99 62 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 163  277 142 278 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 164  75 302 25 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 165  321 29 190 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 166  38 136 381 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 167  38 51 136 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 168  408 283 91 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 169  195 291 141 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 170  5 358 7 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 171  126 305 358 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 172  53 104 52 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 173  53 382 104 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 174  53 105 382 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 175  53 107 417 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 176  7 134 8 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 177  7 103 134 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 178  8 107 330 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 179  305 416 276 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 180  65 108 66 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 181  65 93 108 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 182  279 109 116 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 183  83 182 109 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 184  301 110 48 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 185  112 118 110 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 186  36 295 135 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 187  36 50 493 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 188  301 112 110 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 189  50 118 112 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 190  79 394 193 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 191  409 73 394 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 192  47 114 275 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 193  269 323 114 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 194  39 115 254 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 195  39 86 115 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 196  15 371 109 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 197  352 401 194 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 198  456 352 194 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 199  455 88 352 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 200  49 118 50 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 201  49 377 118 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 202  468 119 75 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 203  386 385 155 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 204  297 386 411 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 205  61 24 120 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 206  376 333 414 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 207  376 141 292 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 208  68 122 420 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 209  223 222 381 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 210  58 245 237 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 211  58 32 280 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 212  62 263 64 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 213  62 99 124 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 214  331 347 32 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 215  35 204 341 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 216  383 126 358 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 217  383 364 126 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 218  59 488 415 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 219  59 147 127 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 220  80 128 427 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 221  80 395 219 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 222  100 129 337 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 223  378 321 190 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 224  40 210 402 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 225  40 51 210 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 226  57 389 339 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 227  57 166 389 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 228  73 132 394 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 229  73 28 132 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 230  441 161 76 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 231  55 86 133 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 232  106 134 103 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 233  106 8 134 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 234  187 135 295 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 235  187 79 227 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 236  101 136 51 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 237  101 122 136 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 238  11 306 374 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 239  158 470 137 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 240  74 138 68 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 241  74 200 138 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 242  471 440 318 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 243  332 169 175 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 244  39 482 447 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 245  39 254 476 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 246  102 270 133 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 247  283 195 271 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 248  336 466 467 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 249  64 234 478 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 250  9 143 85 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 251  9 71 143 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 252  85 340 177 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 253  85 143 340 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 254  97 239 76 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 255  146 96 145 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 256  97 146 145 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 257  438 98 146 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 258  495 147 33 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 259  495 379 147 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 260  54 403 117 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 261  54 172 402 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 262  160 149 76 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 263  208 243 442 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 264  28 150 172 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 265  426 287 150 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 266  433 287 432 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 267  51 436 151 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 268  187 152 79 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 269  37 26 152 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 270  111 153 154 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 271  295 36 493 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 272  46 154 87 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 273  46 111 154 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 274  351 155 188 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 275  351 297 411 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 276  307 156 185 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 277  294 95 486 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 278  470 513 137 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 279  22 296 286 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 280  185 158 308 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 281  262 388 158 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 282  467 445 336 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 283  213 62 445 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 284  257 160 239 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 285  71 311 412 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 286  133 161 55 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 287  133 270 161 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 288  500 162 320 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 289  500 393 162 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 290  300 163 423 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 291  44 170 163 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 292  423 498 300 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 293  82 165 164 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 294  43 165 170 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 295  43 164 165 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 296  241 166 484 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 297  241 131 166 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 298  95 168 486 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 299  319 139 167 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 300  390 168 465 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 301  167 486 168 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 302  424 169 317 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 303  424 197 494 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 304  290 170 83 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 305  290 163 170 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 306  176 171 256 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 307  296 469 384 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 308  40 172 474 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 309  40 402 172 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 310  92 173 121 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 311  474 199 173 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 312  475 409 394 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 313  475 152 174 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 314  197 175 494 {mat="nomaterial" groups="default teeth" rgb=(1 1 1) matid=8}
Face 315  197 318 440 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 316  471 220 440 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 317  296 384 429 {mat="nomaterial" groups="default brows" rgb=(0 0 0) matid=2}
Face 318  179 206 144 {mat="nomaterial" groups="default neck3" rgb=(.6 .5 .4) matid=4}
Face 319  98 41 274 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 320  273 178 414 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 321  41 98 304 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 322  98 179 96 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 323  98 274 179 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 324  210 180 148 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 325  130 116 180 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 326  508 181 267 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 327  264 114 265 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 328  90 182 82 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 329  90 109 182 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 330  60 463 255 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 331  60 328 463 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 332  63 184 88 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 333  303 491 184 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 334  11 309 306 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 335  500 320 185 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 336  26 186 42 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 337  26 37 186 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 338  37 404 63 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 339  37 152 187 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 340  27 188 387 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 341  27 351 188 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 342  45 189 68 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 343  45 326 421 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 344  129 221 29 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 345  129 378 190 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 346  192 191 478 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 347  99 3 191 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 348  99 310 124 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 349  249 362 192 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 350  46 193 111 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 351  46 79 193 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 352  370 194 180 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 353  370 456 194 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 354  287 380 91 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 355  151 196 380 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 356  436 196 151 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 357  436 92 196 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 358  490 452 424 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 359  490 318 452 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 360  176 198 171 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 361  332 175 405 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 362  91 199 474 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 363  91 284 199 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 364  42 200 209 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 365  201 45 200 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 366  42 201 200 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 367  42 298 201 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 368  342 202 314 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 369  203 32 202 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 370  342 215 216 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 371  31 32 203 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 372  31 204 35 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 373  31 203 204 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 374  85 205 114 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 375  85 177 205 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 376  274 206 179 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 377  177 144 206 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 378  72 207 80 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 379  72 81 207 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 380  160 208 442 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 381  160 257 412 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 382  435 209 200 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 383  51 151 434 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 384  130 210 51 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 385  130 180 210 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 386  272 211 34 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 387  127 147 379 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 388  22 469 296 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 389  22 218 365 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 390  467 213 445 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 391  3 62 213 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 392  3 214 142 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 393  3 231 240 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 394  203 215 204 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 395  343 344 345 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 396  202 216 203 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 397  202 342 216 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 398  458 422 256 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 399  285 212 217 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 400  19 258 21 {mat="nomaterial" groups="default hairbob" rgb=(1 0 0) matid=10}
Face 401  393 485 218 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 402  128 219 395 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 403  128 80 219 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 404  198 346 171 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 405  405 175 346 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 406  190 221 129 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 407  190 29 221 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 408  410 222 223 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 409  279 38 222 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 410  68 223 122 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 411  290 83 223 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 412  58 511 202 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 413  248 125 247 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 414  78 225 77 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 415  399 137 289 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 416  511 226 202 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 417  369 367 368 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 418  135 228 87 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 419  135 187 227 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 420  227 228 135 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 421  227 46 228 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 422  105 229 5 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 423  105 53 417 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 424  34 230 35 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 425  34 211 230 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 426  213 231 3 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 427  359 240 360 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 428  96 233 238 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 429  96 144 487 {mat="nomaterial" groups="default neck3" rgb=(.6 .5 .4) matid=4}
Face 430  487 233 96 {mat="nomaterial" groups="default neck3" rgb=(.6 .5 .4) matid=4}
Face 431  232 238 233 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 432  263 234 64 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 433  407 460 234 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 434  8 235 107 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 435  8 81 235 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 436  12 236 167 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 437  12 10 236 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 438  341 237 35 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 439  125 58 237 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 440  71 238 143 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 441  257 145 238 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 442  145 239 97 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 443  145 257 239 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 444  214 240 359 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 445  214 3 240 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 446  2 241 484 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 447  2 4 241 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 448  224 247 125 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 449  244 248 242 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 450  55 243 312 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 451  55 161 441 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 452  224 507 242 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 453  224 248 244 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 454  123 246 58 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 455  348 237 245 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 456  496 449 348 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 457  245 58 246 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 458  242 247 224 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 459  242 248 247 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 460  58 248 224 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 461  58 125 248 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 462  357 249 192 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 463  462 362 249 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 464  428 250 64 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 465  428 57 250 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 466  70 251 117 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 467  252 113 251 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 468  70 252 251 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 469  480 113 252 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 470  4 253 250 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 471  4 2 253 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 472  199 254 115 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 473  199 284 254 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 474  69 255 183 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 475  69 430 255 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 476  169 256 317 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 477  169 176 256 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 478  71 257 238 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 479  71 412 257 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 480  259 258 334 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 481  372 21 258 {mat="nomaterial" groups="default hairbob" rgb=(1 0 0) matid=10}
Face 482  372 259 334 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 483  372 258 499 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 484  220 260 171 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 485  477 471 375 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 486  27 261 351 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 487  27 328 261 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 488  185 262 158 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 489  185 388 262 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 490  124 263 62 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 491  124 234 293 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 492  508 264 265 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 493  86 9 264 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 494  322 265 114 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 495  181 508 265 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 496  115 266 56 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 497  115 508 267 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 498  266 267 181 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 499  266 115 267 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 500  269 268 323 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 501  269 266 268 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 502  47 269 114 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 503  47 266 269 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 504  141 271 195 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 505  141 161 270 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 506  270 271 141 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 507  270 102 271 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 508  127 488 59 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 509  127 379 488 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 510  275 273 47 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 511  41 304 451 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 512  177 274 41 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 513  177 206 274 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 514  41 275 205 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 515  41 451 275 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 516  107 276 383 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 517  107 235 276 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 518  3 277 356 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 519  3 142 277 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 520  191 278 142 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 521  353 354 335 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 522  410 279 222 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 523  83 109 279 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 524  281 280 347 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 525  123 58 280 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 526  123 281 347 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 527  123 280 282 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 528  281 349 398 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 529  281 123 282 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 530  102 283 271 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 531  447 140 283 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 532  140 284 283 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 533  476 254 284 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 534  171 316 256 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 535  384 469 285 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 536  157 286 391 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 537  513 22 286 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 538  151 287 433 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 539  151 380 287 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 540  10 288 236 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 541  485 393 288 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 542  391 289 157 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 543  225 399 425 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 544  68 400 223 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 545  68 189 400 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 546  121 291 196 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 547  333 376 292 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 548  291 292 141 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 549  291 121 292 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 550  366 325 234 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 551  263 124 293 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 552  137 308 158 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 553  137 95 294 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 554  491 295 493 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 555  491 303 295 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 556  77 296 375 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 557  77 286 296 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 558  468 297 119 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 559  468 120 297 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 560  186 298 42 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 561  186 455 298 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 562  89 299 387 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 563  430 69 299 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 564  44 300 67 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 565  44 163 300 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 566  50 301 153 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 567  50 112 301 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 568  100 302 481 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 569  100 84 302 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 570  63 303 184 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 571  63 187 303 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 572  178 304 437 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 573  178 451 304 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 574  235 305 276 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 575  461 103 305 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 576  156 306 309 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 577  156 167 306 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 578  294 307 185 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 579  294 486 307 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 580  294 308 137 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 581  294 185 308 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 582  185 457 500 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 583  185 156 309 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 584  192 310 99 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 585  460 407 327 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 586  55 311 9 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 587  55 312 311 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 588  208 312 243 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 589  208 311 312 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 590  125 313 511 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 591  314 226 313 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 592  125 314 313 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 593  125 237 341 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 594  454 315 320 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 595  454 17 315 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 596  285 316 384 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 597  285 217 316 {mat="nomaterial" groups="default brows" rgb=(0 0 0) matid=2}
Face 598  217 317 373 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 599  217 12 317 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 600  78 318 490 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 601  78 77 318 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 602  95 465 168 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 603  95 78 319 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 604  388 320 315 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 605  388 185 320 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 606  481 321 100 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 607  481 29 321 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 608  323 322 114 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 609  181 265 322 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 610  181 323 268 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 611  181 322 323 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 612  66 324 164 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 613  66 94 324 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 614  419 418 450 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 615  293 234 325 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 616  505 326 15 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 617  90 189 326 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 618  406 327 407 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 619  310 460 327 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 620  25 328 24 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 621  25 501 328 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 622  444 329 306 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 623  444 472 329 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 624  7 330 6 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 625  7 8 330 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 626  35 331 439 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 627  35 237 331 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 628  176 453 198 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 629  176 169 332 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 630  121 333 292 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 631  121 173 333 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 632  19 334 258 {mat="nomaterial" groups="default hairbob" rgb=(1 0 0) matid=10}
Face 633  19 218 334 {mat="nomaterial" groups="default hairbob" rgb=(1 0 0) matid=10}
Face 634  278 335 277 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 635  278 353 335 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 636  64 336 1 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 637  64 466 336 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 638  84 337 29 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 639  84 100 337 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 640  29 338 84 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 641  29 481 338 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 642  512 339 131 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 643  512 250 339 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 644  144 340 232 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 645  144 177 340 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 646  314 341 342 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 647  314 125 341 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 648  204 342 341 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 649  204 215 342 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 650  448 343 345 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 651  448 216 343 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 652  216 344 343 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 653  216 215 344 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 654  215 345 344 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 655  215 448 345 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 656  220 346 440 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 657  220 171 346 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 658  237 347 331 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 659  237 123 347 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 660  123 348 246 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 661  123 237 348 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 662  282 349 281 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 663  446 398 349 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 664  130 350 116 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 665  130 51 350 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 666  119 351 261 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 667  119 297 351 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 668  117 352 88 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 669  117 401 352 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 670  356 353 278 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 671  356 354 353 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 672  277 355 356 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 673  277 335 355 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 674  354 355 335 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 675  354 356 355 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 676  191 356 278 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 677  191 3 356 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 678  462 357 192 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 679  462 249 357 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 680  103 358 305 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 681  103 7 358 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 682  213 359 231 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 683  213 467 359 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 684  231 506 240 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 685  231 359 360 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 686  226 361 313 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 687  226 369 361 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 688  191 362 462 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 689  191 192 362 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 690  81 363 207 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 691  81 106 363 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 692  276 364 383 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 693  276 416 364 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 694  212 365 485 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 695  212 22 365 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 696  263 366 234 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 697  263 293 366 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 698  313 367 369 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 699  313 361 367 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 700  361 368 367 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 701  361 369 368 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 702  511 369 226 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 703  511 313 369 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 704  413 370 180 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 705  116 109 371 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 706  370 371 456 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 707  370 413 371 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 708  218 372 334 {mat="nomaterial" groups="default hairbob" rgb=(1 0 0) matid=10}
Face 709  218 21 372 {mat="nomaterial" groups="default hairbob" rgb=(1 0 0) matid=10}
Face 710  479 458 256 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 711  316 217 373 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 712  329 374 306 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 713  329 472 374 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 714  429 375 296 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 715  504 477 375 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 716  76 376 178 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 717  76 161 376 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 718  110 377 48 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 719  110 118 377 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 720  100 378 129 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 721  100 321 378 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 722  211 379 495 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 723  211 272 379 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 724  195 380 196 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 725  408 91 380 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 726  122 381 136 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 727  122 223 381 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 728  6 382 105 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 729  6 104 382 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 730  5 383 358 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 731  5 107 383 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 732  171 384 316 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 733  171 260 384 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 734  188 385 386 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 735  188 155 385 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 736  120 386 297 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 737  120 188 386 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 738  24 387 120 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 739  24 89 387 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 740  21 388 17 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 741  21 218 388 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 742  131 389 166 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 743  131 339 389 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 744  167 390 319 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 745  167 168 390 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 746  483 391 286 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 747  483 425 391 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 748  80 392 72 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 749  80 427 392 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 750  19 393 218 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 751  19 162 393 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 752  113 394 132 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 753  113 193 394 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 754  207 395 80 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 755  207 128 395 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 756  16 396 443 {mat="nomaterial" groups="default eyel" rgb=(.5 .5 .5) matid=1}
Face 757  14 397 13 {mat="nomaterial" groups="default eyer" rgb=(.5 .5 .5) matid=13}
Face 758  14 20 397 {mat="nomaterial" groups="default eyer" rgb=(.5 .5 .5) matid=13}
Face 759  280 398 282 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 760  280 281 398 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 761  78 399 225 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 762  78 137 399 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 763  290 400 189 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 764  290 223 400 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 765  148 401 117 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 766  148 180 401 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 767  148 402 210 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 768  148 54 402 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 769  148 403 54 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 770  148 117 403 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 771  187 404 37 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 772  187 63 404 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 773  198 492 346 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 774  198 453 492 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 775  310 406 407 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 776  310 327 406 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 777  124 407 234 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 778  124 310 407 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 779  195 408 380 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 780  195 283 408 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 781  174 409 475 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 782  174 73 409 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 783  83 410 223 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 784  83 279 410 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 785  155 411 386 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 786  155 351 411 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 787  208 412 311 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 788  208 160 412 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 789  116 413 180 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 790  116 371 413 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 791  56 414 464 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 792  56 273 414 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 793  34 415 272 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 794  34 33 415 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 795  126 416 305 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 796  126 364 416 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 797  229 417 107 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 798  229 105 417 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 799  325 418 293 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 800  325 450 418 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 801  293 419 450 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 802  293 418 419 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 803  74 420 101 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 804  74 68 420 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 805  189 421 326 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 806  189 45 421 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 807  317 422 373 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 808  317 256 422 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 809  82 423 189 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 810  82 498 423 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 811  12 424 317 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 812  12 139 424 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 813  289 425 399 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 814  289 391 425 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 815  28 426 150 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 816  28 26 426 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 817  106 427 363 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 818  106 392 427 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 819  1 428 64 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 820  484 166 428 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 821  260 429 384 {mat="nomaterial" groups="default brows" rgb=(0 0 0) matid=2}
Face 822  504 375 429 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 823  89 430 299 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 824  89 60 430 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 825  426 432 287 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 826  426 42 431 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 827  431 432 426 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 828  431 209 432 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 829  209 433 432 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 830  209 435 433 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 831  433 434 151 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 832  433 435 434 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 833  51 435 101 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 834  51 434 435 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 835  40 436 51 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 836  40 92 436 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 837  438 437 304 {mat="nomaterial" groups="default chest2" rgb=(.6 .5 .3) matid=7}
Face 838  97 76 437 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 839  97 438 146 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 840  97 437 438 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 841  33 439 495 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 842  33 34 439 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 843  175 440 346 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 844  175 197 440 {mat="nomaterial" groups="default teeth" rgb=(1 1 1) matid=8}
Face 845  243 441 149 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 846  243 55 441 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 847  149 442 243 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 848  149 160 442 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 849  18 443 23 {mat="nomaterial" groups="default eyel" rgb=(.5 .5 .5) matid=1}
Face 850  18 16 443 {mat="nomaterial" groups="default eyel" rgb=(.5 .5 .5) matid=1}
Face 851  236 444 167 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 852  236 288 444 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 853  159 445 62 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 854  159 336 445 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 855  282 446 349 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 856  282 398 446 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 857  102 447 283 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 858  102 133 447 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 859  203 448 215 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 860  203 216 448 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 861  497 449 496 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 862  246 348 449 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 863  366 450 325 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 864  366 293 450 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 865  273 451 178 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 866  273 275 451 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 867  197 452 318 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 868  197 424 452 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 869  332 453 176 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 870  332 405 453 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 871  162 454 320 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 872  162 19 454 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 873  456 455 352 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 874  456 298 455 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 875  15 456 371 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 876  15 298 456 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 877  309 457 185 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 878  309 11 457 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 879  373 458 479 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 880  373 422 458 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 881  192 459 310 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 882  192 478 459 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 883  459 460 310 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 884  459 234 460 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 885  235 461 305 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 886  235 72 461 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 887  99 462 192 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 888  99 191 462 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 889  183 463 328 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 890  183 255 463 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 891  173 464 333 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 892  173 199 464 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 893  319 465 95 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 894  319 390 465 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 895  142 466 64 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 896  142 214 466 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 897  214 467 466 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 898  214 359 467 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 899  61 468 75 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 900  61 120 468 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 901  212 469 22 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 902  212 285 469 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 903  22 470 218 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 904  22 513 470 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 905  77 471 318 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 906  77 375 471 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 907  288 472 444 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 908  288 374 472 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 909  94 473 324 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 910  94 93 473 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 911  92 474 173 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 912  92 40 474 {mat="nomaterial" groups="default belt" rgb=(.3 .2 .3) matid=5}
Face 913  79 475 394 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 914  79 152 475 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 915  140 476 284 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 916  140 39 476 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 917  220 477 260 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 918  220 471 477 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 919  142 478 191 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 920  142 64 478 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 921  316 479 256 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 922  316 373 479 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 923  70 480 252 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 924  70 184 480 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 925  75 481 302 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 926  75 338 481 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 927  140 482 39 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 928  140 447 482 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 929  225 483 286 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 930  225 425 483 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 931  1 484 428 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 932  1 2 484 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 933  10 485 288 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 934  10 212 485 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 935  156 486 167 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 936  156 307 486 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 937  232 487 144 {mat="nomaterial" groups="default neck3" rgb=(.6 .5 .4) matid=4}
Face 938  232 233 487 {mat="nomaterial" groups="default neck3" rgb=(.6 .5 .4) matid=4}
Face 939  272 488 379 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 940  272 415 488 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 941  230 489 31 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 942  230 211 489 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 943  139 490 424 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 944  139 78 490 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 945  111 491 153 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 946  111 184 491 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 947  405 492 453 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 948  405 346 492 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 949  153 493 50 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 950  153 491 493 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 951  169 494 175 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 952  169 424 494 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 953  30 495 439 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 954  30 211 495 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 955  245 496 348 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 956  245 246 496 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 957  246 497 496 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 958  246 449 497 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 959  164 498 82 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 960  164 324 498 {mat="nomaterial" groups="default wrap" rgb=(.5 .4 .2) matid=3}
Face 961  259 499 258 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 962  259 372 499 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 963  11 500 457 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 964  11 393 500 {mat="nomaterial" groups="default hair" rgb=(0 .2 .2) matid=14}
Face 965  502 501 84 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 966  261 328 501 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 967  261 502 119 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 968  261 501 502 {mat="nomaterial" groups="default boot" rgb=(.2 .2 .2) matid=17}
Face 969  2 503 253 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 970  2 336 503 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 971  260 504 429 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 972  260 477 504 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 973  90 505 109 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 974  90 326 505 {mat="nomaterial" groups="default cloth" rgb=(.7 .7 .8) matid=11}
Face 975  360 506 231 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 976  360 240 506 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 977  509 507 224 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 978  510 242 507 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 979  86 508 115 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 980  86 264 508 {mat="nomaterial" groups="default chest" rgb=(.7 .6 .4) matid=6}
Face 981  244 509 224 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 982  510 507 509 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 983  244 510 509 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 984  244 242 510 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 985  224 511 58 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 986  224 125 511 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 987  4 512 241 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 988  4 250 512 {mat="nomaterial" groups="default arm" rgb=(.6 .4 .4) matid=15}
Face 989  157 513 286 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Face 990  157 137 513 {mat="nomaterial" groups="default skin" rgb=(.7 .4 .4) matid=16}
Corner 54 1 {wid=128 normal=(0.258422 0.118779 0.958702)}
Corner 251 1 {wid=52 normal=(0.460284 -0.059013 0.885808)}
Corner 132 1 {wid=367 normal=(0.978102 0.204744 -0.0373693)}
Corner 62 2 {wid=37 normal=(0.371459 -0.255684 -0.892549)}
Corner 253 2 {wid=41 normal=(0.974606 -0.220042 -0.0415301)}
Corner 159 2 {wid=40 normal=(0.695748 -8.50411e-005 0.718286)}
Corner 158 3 {wid=428 normal=(0.863874 -0.497627 0.0780372)}
Corner 11 6 {wid=50 normal=(-0.828352 -0.0345488 0.559142)}
Corner 288 6 {wid=799 normal=(-0.69883 -0.707966 -0.102083)}
Corner 218 7 {wid=579 normal=(-0.0709034 0.671173 -0.737902)}
Corner 485 7 {wid=1303 normal=(-0.534979 0.834261 0.133437)}
Corner 365 7 {wid=555 normal=(0 0.999995 -0.00325909)}
Corner 218 8 {wid=579 normal=(-0.0709034 0.671173 -0.737902)}
Corner 19 9 {wid=19 normal=(-0.151259 0.959982 -0.235702)}
Corner 454 9 {wid=1235 normal=(-0.273945 -0.383981 0.881766)}
Corner 217 10 {wid=578 normal=(-0.96545 0.188575 0.179844)}
Corner 10 10 {wid=48 normal=(-0.683589 0.238787 0.6897)}
Corner 11 12 {wid=11 normal=(-0.828352 -0.0345488 0.559142)}
Corner 288 12 {wid=10 normal=(-0.69883 -0.707966 -0.102083)}
Corner 439 14 {wid=69 normal=(0.662237 -0.194709 -0.723554)}
Corner 34 14 {wid=70 normal=(0.648159 0.0211272 0.761212)}
Corner 35 14 {wid=71 normal=(0.373135 0.0229888 0.927492)}
Corner 331 15 {wid=921 normal=(0.7667 -0.171988 -0.61854)}
Corner 32 15 {wid=68 normal=(-0.540482 -0.26169 -0.799623)}
Corner 30 15 {wid=66 normal=(-0.379854 -0.255921 -0.888941)}
Corner 439 16 {wid=69 normal=(0.662237 -0.194709 -0.723554)}
Corner 331 16 {wid=921 normal=(0.7667 -0.171988 -0.61854)}
Corner 30 16 {wid=66 normal=(-0.379854 -0.255921 -0.888941)}
Corner 31 17 {wid=67 normal=(-0.695748 -8.50387e-005 0.718286)}
Corner 489 17 {wid=1314 normal=(-0.892668 -0.251227 -0.374204)}
Corner 30 17 {wid=66 normal=(-0.379854 -0.255921 -0.888941)}
Corner 32 18 {wid=68 normal=(-0.540482 -0.26169 -0.799623)}
Corner 31 18 {wid=67 normal=(-0.695748 -8.50387e-005 0.718286)}
Corner 30 18 {wid=66 normal=(-0.379854 -0.255921 -0.888941)}
Corner 35 19 {wid=71 normal=(0.373135 0.0229888 0.927492)}
Corner 230 19 {wid=615 normal=(-0.0296346 0.0852488 0.995919)}
Corner 31 19 {wid=67 normal=(-0.695748 -8.50387e-005 0.718286)}
Corner 32 20 {wid=32 normal=(-0.23044 0.156806 -0.960369)}
Corner 347 20 {wid=962 normal=(0.647487 0.021701 -0.761767)}
Corner 280 20 {wid=31 normal=(-0.610713 -0.106723 -0.784627)}
Corner 159 22 {wid=40 normal=(0.695748 -8.50411e-005 0.718286)}
Corner 253 22 {wid=41 normal=(0.974606 -0.220042 -0.0415301)}
Corner 503 22 {wid=1340 normal=(0.0296358 0.0852481 0.99592)}
Corner 234 23 {wid=36 normal=(-0.401139 -0.87131 -0.282678)}
Corner 459 23 {wid=1246 normal=(-0.437007 -0.898389 -0.0438495)}
Corner 478 23 {wid=38 normal=(-0.520127 -0.61836 0.589152)}
Corner 428 24 {wid=1173 normal=(-0.550002 -0.0093556 -0.835111)}
Corner 338 25 {wid=65 normal=(0 -1 0)}
Corner 75 25 {wid=57 normal=(0 -1 0)}
Corner 119 25 {wid=55 normal=(0 -1 0)}
Corner 24 26 {wid=54 normal=(-0.962513 0.0685396 0.262437)}
Corner 328 26 {wid=56 normal=(0.0988593 0.0704348 0.992606)}
Corner 60 26 {wid=61 normal=(-0.479476 -0.00956728 0.877503)}
Corner 84 27 {wid=60 normal=(0.894103 0.425578 -0.139507)}
Corner 338 27 {wid=64 normal=(0.930445 -0.0305283 -0.365158)}
Corner 119 27 {wid=24 normal=(0.908819 -0.00467443 -0.417165)}
Corner 337 28 {wid=27 normal=(0.788446 0.539029 -0.29631)}
Corner 129 28 {wid=25 normal=(0.954018 0.297262 -0.0385421)}
Corner 29 28 {wid=29 normal=(0.946831 0.0160895 -0.321329)}
Corner 103 29 {wid=42 normal=(0 -1 0)}
Corner 461 29 {wid=45 normal=(0 -1 0)}
Corner 72 29 {wid=43 normal=(0 -1 0)}
Corner 105 30 {wid=286 normal=(-0.606138 -0.509583 -0.610673)}
Corner 5 30 {wid=5 normal=(-0.015093 0.0262476 -0.999542)}
Corner 6 30 {wid=6 normal=(-0.865239 -0.0778686 0.495276)}
Corner 6 31 {wid=6 normal=(-0.865239 -0.0778686 0.495276)}
Corner 330 31 {wid=919 normal=(-0.0988593 0.0704348 0.992606)}
Corner 52 31 {wid=8 normal=(-0.0654443 0.149197 0.986639)}
Corner 6 32 {wid=6 normal=(-0.865239 -0.0778686 0.495276)}
Corner 5 32 {wid=5 normal=(-0.015093 0.0262476 -0.999542)}
Corner 7 32 {wid=7 normal=(-0.824241 0.178461 -0.537381)}
Corner 401 33 {wid=62 normal=(0.283469 -0.26181 0.922551)}
Corner 180 33 {wid=47 normal=(0.0247551 0.0123975 0.999617)}
Corner 194 33 {wid=51 normal=(2.09548e-009 -0.395188 0.9186)}
Corner 116 34 {wid=317 normal=(0.662786 0.0799745 0.744525)}
Corner 350 34 {wid=46 normal=(-0.47972 0.0996945 0.87174)}
Corner 114 35 {wid=309 normal=(0.16498 0.98619 0.014546)}
Corner 264 35 {wid=726 normal=(-0.190205 0.546764 -0.815397)}
Corner 85 35 {wid=224 normal=(0.689266 0.238421 -0.684155)}
Corner 117 36 {wid=319 normal=(-0.213802 -0.0586599 0.975114)}
Corner 251 36 {wid=693 normal=(-0.159337 -0.206901 0.9653)}
Corner 54 36 {wid=76 normal=(0.479719 0.0996946 0.87174)}
Corner 455 37 {wid=75 normal=(-0.943824 0.128633 -0.304383)}
Corner 37 37 {wid=77 normal=(-0.762401 -0.0852374 -0.641467)}
Corner 63 37 {wid=73 normal=(-0.929039 -0.251419 -0.27143)}
Corner 186 38 {wid=79 normal=(-0.928126 -0.0819367 -0.363137)}
Corner 37 38 {wid=77 normal=(-0.762401 -0.0852374 -0.641467)}
Corner 455 38 {wid=75 normal=(-0.943824 0.128633 -0.304383)}
Corner 154 39 {wid=80 normal=(0.97635 -0.190004 0.103147)}
Corner 48 39 {wid=81 normal=(0.531962 -0.173805 -0.828739)}
Corner 87 39 {wid=78 normal=(0.11546 -0.133125 -0.984351)}
Corner 26 40 {wid=59 normal=(0.32379 0.188469 -0.927168)}
Corner 42 40 {wid=82 normal=(0 -0.139361 -0.990242)}
Corner 426 40 {wid=1169 normal=(0.561629 0.298281 -0.771752)}
Corner 298 41 {wid=84 normal=(0.24585 -0.951927 -0.182738)}
Corner 15 41 {wid=85 normal=(0.343435 -0.934565 -0.0929585)}
Corner 201 41 {wid=83 normal=(0.175924 -0.953989 -0.242808)}
Corner 283 42 {wid=88 normal=(-0.225944 1.37548e-005 -0.97414)}
Corner 284 42 {wid=86 normal=(0.521469 1.20539e-005 -0.85327)}
Corner 91 42 {wid=90 normal=(0.850008 7.48799e-006 -0.52677)}
Corner 447 43 {wid=89 normal=(-0.434047 -0.393368 -0.810472)}
Corner 133 43 {wid=91 normal=(-0.362049 0.0782298 -0.928871)}
Corner 39 43 {wid=87 normal=(0.362049 0.0782295 -0.928871)}
Corner 160 44 {wid=94 normal=(-0.353175 0.319994 0.879131)}
Corner 239 44 {wid=393 normal=(-0.352004 0.565395 0.745939)}
Corner 161 45 {wid=95 normal=(-0.984651 0.0846602 -0.152628)}
Corner 141 45 {wid=96 normal=(-0.993202 0.0549633 -0.102614)}
Corner 376 45 {wid=93 normal=(-0.388515 -0.192575 0.901094)}
Corner 414 46 {wid=1140 normal=(0.206474 -0.819079 0.535236)}
Corner 178 46 {wid=469 normal=(-0.058053 0.0128031 0.998232)}
Corner 376 46 {wid=1049 normal=(-0.206474 -0.819079 0.535236)}
Corner 56 47 {wid=97 normal=(0.547319 -0.831191 0.097798)}
Corner 266 47 {wid=98 normal=(0.227239 -0.435966 0.870802)}
Corner 47 47 {wid=115 normal=(0.353176 0.319994 0.879131)}
Corner 381 48 {wid=99 normal=(-0.906912 -0.338567 0.250765)}
Corner 222 48 {wid=590 normal=(-0.386485 -0.511135 0.767704)}
Corner 209 49 {wid=549 normal=(-0.335349 0.342609 -0.877588)}
Corner 431 49 {wid=1181 normal=(0.13043 0.357426 -0.924789)}
Corner 42 49 {wid=82 normal=(0 -0.139361 -0.990242)}
Corner 65 50 {wid=102 normal=(-0.974624 -0.189857 0.118585)}
Corner 43 50 {wid=101 normal=(-0.680891 -0.174538 0.711283)}
Corner 44 50 {wid=103 normal=(-0.758315 -0.224429 -0.612039)}
Corner 116 51 {wid=317 normal=(0.662786 0.0799745 0.744525)}
Corner 279 51 {wid=766 normal=(-0.169868 -0.137751 0.975792)}
Corner 200 52 {wid=517 normal=(-0.323791 0.18847 -0.927167)}
Corner 74 52 {wid=104 normal=(-0.708389 0.30408 -0.636962)}
Corner 101 52 {wid=275 normal=(-0.736123 0.398544 -0.547068)}
Corner 200 53 {wid=106 normal=(0.613884 0.105292 -0.782343)}
Corner 45 53 {wid=107 normal=(0.326962 0.230981 -0.916375)}
Corner 138 53 {wid=105 normal=(0.326963 0.230981 -0.916375)}
Corner 15 54 {wid=110 normal=(0.943824 0.128633 -0.304383)}
Corner 45 54 {wid=108 normal=(0.762402 -0.0852369 -0.641466)}
Corner 201 54 {wid=111 normal=(0.928126 -0.0819367 -0.363137)}
Corner 15 55 {wid=15 normal=(0.947637 -0.304113 0.0974711)}
Corner 505 55 {wid=1345 normal=(0.758099 -0.608837 0.233671)}
Corner 26 56 {wid=59 normal=(0.32379 0.188469 -0.927168)}
Corner 174 56 {wid=112 normal=(0.708388 0.30408 -0.636963)}
Corner 152 56 {wid=114 normal=(0.345105 0.279656 -0.895933)}
Corner 132 57 {wid=367 normal=(0.978102 0.204744 -0.0373693)}
Corner 251 57 {wid=52 normal=(0.460284 -0.059013 0.885808)}
Corner 113 57 {wid=113 normal=(0.906912 -0.338567 0.250765)}
Corner 275 58 {wid=28 normal=(0.34656 0.750953 0.562108)}
Corner 114 58 {wid=309 normal=(0.16498 0.98619 0.014546)}
Corner 205 58 {wid=535 normal=(0.860041 0.200645 -0.469117)}
Corner 273 59 {wid=746 normal=(-0.0385036 0.23259 0.971813)}
Corner 56 59 {wid=97 normal=(0.547319 -0.831191 0.097798)}
Corner 47 59 {wid=115 normal=(0.353176 0.319994 0.879131)}
Corner 36 60 {wid=116 normal=(-0.990214 -0.0617282 -0.125162)}
Corner 49 60 {wid=118 normal=(-0.796625 -0.109466 -0.59448)}
Corner 50 60 {wid=117 normal=(-0.638923 -0.0807716 0.765018)}
Corner 36 61 {wid=116 normal=(-0.990214 -0.0617282 -0.125162)}
Corner 87 61 {wid=78 normal=(0.11546 -0.133125 -0.984351)}
Corner 48 61 {wid=81 normal=(0.531962 -0.173805 -0.828739)}
Corner 48 62 {wid=81 normal=(0.531962 -0.173805 -0.828739)}
Corner 49 62 {wid=118 normal=(-0.796625 -0.109466 -0.59448)}
Corner 36 62 {wid=116 normal=(-0.990214 -0.0617282 -0.125162)}
Corner 48 63 {wid=120 normal=(0.53755 0.292608 -0.790835)}
Corner 49 63 {wid=119 normal=(-0.812633 0.230291 -0.535343)}
Corner 154 64 {wid=80 normal=(0.97635 -0.190004 0.103147)}
Corner 301 64 {wid=835 normal=(0.699632 -0.208878 0.683289)}
Corner 48 64 {wid=81 normal=(0.531962 -0.173805 -0.828739)}
Corner 154 65 {wid=80 normal=(0.97635 -0.190004 0.103147)}
Corner 153 65 {wid=300 normal=(0.162149 -0.146138 0.975885)}
Corner 301 65 {wid=835 normal=(0.699632 -0.208878 0.683289)}
Corner 101 66 {wid=275 normal=(-0.736123 0.398544 -0.547068)}
Corner 435 66 {wid=1190 normal=(-0.844464 0.274691 -0.459812)}
Corner 200 66 {wid=517 normal=(-0.323791 0.18847 -0.927167)}
Corner 350 67 {wid=123 normal=(-0.258422 0.118779 0.958702)}
Corner 51 67 {wid=122 normal=(-0.878715 0.225038 0.420973)}
Corner 107 68 {wid=125 normal=(0.984446 -0.0348826 -0.172193)}
Corner 52 68 {wid=8 normal=(-0.0654443 0.149197 0.986639)}
Corner 330 68 {wid=919 normal=(-0.0988593 0.0704348 0.992606)}
Corner 104 69 {wid=126 normal=(0.268312 0.89905 0.346002)}
Corner 6 69 {wid=127 normal=(-0.65579 0.646986 -0.389035)}
Corner 52 69 {wid=124 normal=(0.182916 0.911737 0.367802)}
Corner 107 70 {wid=125 normal=(0.984446 -0.0348826 -0.172193)}
Corner 53 70 {wid=44 normal=(0.484084 -0.0675311 0.872412)}
Corner 52 70 {wid=8 normal=(-0.0654443 0.149197 0.986639)}
Corner 107 71 {wid=125 normal=(0.984446 -0.0348826 -0.172193)}
Corner 5 71 {wid=5 normal=(-0.015093 0.0262476 -0.999542)}
Corner 229 71 {wid=613 normal=(0.285196 -0.349738 -0.892383)}
Corner 28 72 {wid=63 normal=(0.844464 0.27469 -0.459812)}
Corner 54 72 {wid=128 normal=(0.258422 0.118779 0.958702)}
Corner 132 72 {wid=367 normal=(0.978102 0.204744 -0.0373693)}
Corner 28 73 {wid=130 normal=(0.857805 7.30082e-006 -0.513976)}
Corner 172 73 {wid=449 normal=(0.824361 -7.99856e-006 0.566065)}
Corner 54 73 {wid=129 normal=(0.687627 -1.0239e-005 0.726063)}
Corner 149 74 {wid=402 normal=(-0.129889 -0.693318 0.708829)}
Corner 441 74 {wid=657 normal=(0.254437 -0.916983 -0.307251)}
Corner 9 75 {wid=9 normal=(-0.203103 0.248811 -0.947017)}
Corner 55 75 {wid=132 normal=(0.353376 -0.327211 -0.876389)}
Corner 91 76 {wid=135 normal=(0.852678 7.3782e-006 -0.522437)}
Corner 474 76 {wid=1277 normal=(0.690295 -9.26699e-006 0.723528)}
Corner 172 76 {wid=137 normal=(0.824134 -6.81426e-006 0.566395)}
Corner 199 77 {wid=136 normal=(0.993201 0.0549632 -0.102614)}
Corner 115 77 {wid=138 normal=(0.984651 0.0846602 -0.152628)}
Corner 56 77 {wid=134 normal=(0.948439 0.0166693 0.316522)}
Corner 250 79 {wid=692 normal=(0.244695 -0.097176 -0.964718)}
Corner 202 80 {wid=142 normal=(-0.428192 0.447876 0.784894)}
Corner 226 80 {wid=140 normal=(-0.580706 0.285838 0.762284)}
Corner 314 80 {wid=144 normal=(-0.201106 0.336165 0.920081)}
Corner 202 81 {wid=143 normal=(-0.951888 0.223843 0.209292)}
Corner 32 81 {wid=145 normal=(-0.816215 0.268904 -0.511355)}
Corner 58 81 {wid=141 normal=(-0.981522 0.182192 0.0584899)}
Corner 489 82 {wid=1315 normal=(-0.900996 -0.0910117 -0.424173)}
Corner 30 82 {wid=30 normal=(-0.438481 -0.0943603 -0.893773)}
Corner 27 84 {wid=148 normal=(0.824242 0.178461 -0.537381)}
Corner 183 84 {wid=483 normal=(0.903737 -0.139763 0.404631)}
Corner 328 84 {wid=56 normal=(0.0988593 0.0704348 0.992606)}
Corner 255 85 {wid=149 normal=(-0.336806 0.574854 -0.745724)}
Corner 430 85 {wid=150 normal=(-0.277194 0.756013 -0.592965)}
Corner 60 85 {wid=147 normal=(-0.312981 0.618961 -0.720368)}
Corner 24 86 {wid=152 normal=(-0.957923 0.0920842 0.27185)}
Corner 61 86 {wid=151 normal=(-0.93671 0.042744 0.347486)}
Corner 25 86 {wid=153 normal=(0.0189398 0.74245 0.669634)}
Corner 387 87 {wid=1073 normal=(-0.105432 0.131005 -0.985759)}
Corner 188 87 {wid=154 normal=(0.642382 0.0601608 -0.76402)}
Corner 120 87 {wid=325 normal=(-0.729423 0.184251 -0.658782)}
Corner 250 88 {wid=691 normal=(0.379854 -0.255921 -0.888941)}
Corner 62 88 {wid=37 normal=(0.371459 -0.255684 -0.892549)}
Corner 64 88 {wid=156 normal=(-0.482358 -0.205572 -0.851511)}
Corner 250 89 {wid=691 normal=(0.379854 -0.255921 -0.888941)}
Corner 253 89 {wid=41 normal=(0.974606 -0.220042 -0.0415301)}
Corner 62 89 {wid=37 normal=(0.371459 -0.255684 -0.892549)}
Corner 295 90 {wid=821 normal=(-0.997054 -0.0676643 0.0361118)}
Corner 303 90 {wid=157 normal=(-0.996647 -0.0664181 0.0477801)}
Corner 187 90 {wid=160 normal=(-0.425673 -0.201149 -0.882237)}
Corner 455 91 {wid=1239 normal=(-0.947636 -0.304113 0.0974719)}
Corner 63 91 {wid=158 normal=(-0.7581 -0.608838 0.23367)}
Corner 503 92 {wid=1340 normal=(0.0296358 0.0852481 0.99592)}
Corner 336 92 {wid=936 normal=(-0.863052 -0.0451684 0.503092)}
Corner 159 92 {wid=40 normal=(0.695748 -8.50411e-005 0.718286)}
Corner 2 93 {wid=39 normal=(-0.648158 0.0211275 0.761213)}
Corner 1 93 {wid=155 normal=(-0.992525 -0.117469 0.0330816)}
Corner 336 93 {wid=936 normal=(-0.863052 -0.0451684 0.503092)}
Corner 67 94 {wid=163 normal=(-0.0655602 -0.158371 -0.985201)}
Corner 65 94 {wid=102 normal=(-0.974624 -0.189857 0.118585)}
Corner 44 94 {wid=103 normal=(-0.758315 -0.224429 -0.612039)}
Corner 66 95 {wid=161 normal=(0.353673 -0.100818 0.92992)}
Corner 43 95 {wid=101 normal=(-0.680891 -0.174538 0.711283)}
Corner 65 95 {wid=102 normal=(-0.974624 -0.189857 0.118585)}
Corner 498 96 {wid=1331 normal=(0.990214 -0.0617275 -0.125162)}
Corner 324 96 {wid=898 normal=(0.987937 -0.0634772 -0.141247)}
Corner 300 96 {wid=833 normal=(0.407364 -0.12871 -0.904151)}
Corner 164 97 {wid=162 normal=(0.614169 -0.0831513 0.784781)}
Corner 43 97 {wid=101 normal=(-0.680891 -0.174538 0.711283)}
Corner 66 97 {wid=161 normal=(0.353673 -0.100818 0.92992)}
Corner 324 98 {wid=898 normal=(0.987937 -0.0634772 -0.141247)}
Corner 67 98 {wid=163 normal=(-0.0655602 -0.158371 -0.985201)}
Corner 300 98 {wid=833 normal=(0.407364 -0.12871 -0.904151)}
Corner 94 99 {wid=165 normal=(-0.0015627 -0.999938 0.0110636)}
Corner 108 99 {wid=166 normal=(-0.0111583 -0.999906 -0.0080223)}
Corner 93 99 {wid=164 normal=(-0.0496144 -0.99851 -0.0227029)}
Corner 163 100 {wid=169 normal=(-0.0877167 -0.238441 -0.967188)}
Corner 290 100 {wid=167 normal=(-0.952866 -0.213026 -0.216022)}
Corner 189 100 {wid=171 normal=(0.425673 -0.201149 -0.882236)}
Corner 44 101 {wid=170 normal=(-0.749024 -0.226827 -0.622504)}
Corner 43 101 {wid=172 normal=(-0.669396 -0.174188 0.722197)}
Corner 170 101 {wid=168 normal=(-0.97761 -0.190335 0.0897288)}
Corner 27 102 {wid=148 normal=(0.824242 0.178461 -0.537381)}
Corner 69 102 {wid=173 normal=(0.606139 -0.509583 -0.610673)}
Corner 183 102 {wid=483 normal=(0.903737 -0.139763 0.404631)}
Corner 27 103 {wid=148 normal=(0.824242 0.178461 -0.537381)}
Corner 299 103 {wid=831 normal=(-0.21561 -0.352229 -0.91074)}
Corner 69 103 {wid=173 normal=(0.606139 -0.509583 -0.610673)}
Corner 111 104 {wid=159 normal=(0.420084 -0.164547 0.892442)}
Corner 480 104 {wid=175 normal=(0.158136 -0.146102 0.976549)}
Corner 184 104 {wid=487 normal=(-0.804192 -0.0531573 0.591987)}
Corner 111 105 {wid=159 normal=(0.420084 -0.164547 0.892442)}
Corner 193 105 {wid=176 normal=(0.976651 -0.190122 0.100034)}
Corner 480 105 {wid=175 normal=(0.158136 -0.146102 0.976549)}
Corner 96 106 {wid=179 normal=(0 0.493971 0.869479)}
Corner 238 106 {wid=177 normal=(0 0.935108 0.354362)}
Corner 145 106 {wid=394 normal=(0 0.855328 0.518087)}
Corner 9 107 {wid=9 normal=(-0.203103 0.248811 -0.947017)}
Corner 311 107 {wid=866 normal=(0.103675 0.746416 -0.657354)}
Corner 71 107 {wid=178 normal=(-0.689265 0.238422 -0.684155)}
Corner 81 108 {wid=183 normal=(0.955532 0.205096 -0.211883)}
Corner 72 108 {wid=181 normal=(0.973367 0.0443024 -0.22493)}
Corner 235 108 {wid=631 normal=(0.879032 0.0281601 0.475931)}
Corner 106 109 {wid=184 normal=(-0.894104 0.425578 -0.139507)}
Corner 103 109 {wid=186 normal=(-0.908819 -0.00467442 -0.417165)}
Corner 392 109 {wid=182 normal=(-0.930445 -0.0305283 -0.365158)}
Corner 26 110 {wid=59 normal=(0.32379 0.188469 -0.927168)}
Corner 73 110 {wid=187 normal=(0.736123 0.398545 -0.547069)}
Corner 174 110 {wid=112 normal=(0.708388 0.30408 -0.636963)}
Corner 26 111 {wid=59 normal=(0.32379 0.188469 -0.927168)}
Corner 28 111 {wid=63 normal=(0.844464 0.27469 -0.459812)}
Corner 73 111 {wid=187 normal=(0.736123 0.398545 -0.547069)}
Corner 68 112 {wid=190 normal=(-0.483984 -0.841711 -0.239337)}
Corner 138 112 {wid=188 normal=(0.228757 -0.450348 -0.863051)}
Corner 45 112 {wid=192 normal=(0.228757 -0.450348 -0.863051)}
Corner 122 113 {wid=191 normal=(-0.8867 -0.301003 -0.350942)}
Corner 101 113 {wid=275 normal=(-0.736123 0.398544 -0.547068)}
Corner 420 113 {wid=189 normal=(-0.93082 -0.0244507 -0.36466)}
Corner 25 114 {wid=194 normal=(-0.00671065 0.738814 0.673876)}
Corner 302 114 {wid=271 normal=(-0.305963 0.863737 0.400432)}
Corner 84 114 {wid=195 normal=(0.504899 0.759721 0.409758)}
Corner 25 115 {wid=194 normal=(-0.00671065 0.738814 0.673876)}
Corner 61 115 {wid=196 normal=(-0.876826 -0.0381892 0.479289)}
Corner 75 115 {wid=193 normal=(-0.973367 0.044302 -0.22493)}
Corner 196 116 {wid=198 normal=(-0.687546 -1.02436e-005 0.726141)}
Corner 291 116 {wid=804 normal=(-0.922822 -5.45893e-006 0.385228)}
Corner 195 116 {wid=199 normal=(-0.879861 6.70713e-006 -0.47523)}
Corner 196 117 {wid=198 normal=(-0.687546 -1.02436e-005 0.726141)}
Corner 92 117 {wid=200 normal=(0.142648 -1.39781e-005 0.989775)}
Corner 121 117 {wid=197 normal=(-0.142646 -1.39781e-005 0.989774)}
Corner 286 118 {wid=426 normal=(0.677438 0.517632 0.522623)}
Corner 10 119 {wid=48 normal=(-0.683589 0.238787 0.6897)}
Corner 217 119 {wid=578 normal=(-0.96545 0.188575 0.179844)}
Corner 137 120 {wid=372 normal=(0.537093 -0.226403 0.812572)}
Corner 95 120 {wid=252 normal=(0.686827 0.296644 -0.663529)}
Corner 137 121 {wid=372 normal=(0.537093 -0.226403 0.812572)}
Corner 193 122 {wid=206 normal=(0.399457 -0.914021 0.0707083)}
Corner 113 122 {wid=204 normal=(0.443806 -0.893067 -0.0739522)}
Corner 480 122 {wid=208 normal=(0.200618 -0.886834 0.416266)}
Corner 46 123 {wid=207 normal=(0.973771 -0.189492 0.125949)}
Corner 227 123 {wid=606 normal=(0.0877167 -0.238441 -0.967188)}
Corner 79 123 {wid=205 normal=(0.83286 -0.214419 -0.510263)}
Corner 72 124 {wid=43 normal=(0 -1 0)}
Corner 392 124 {wid=210 normal=(0 -1 0)}
Corner 103 124 {wid=42 normal=(0 -1 0)}
Corner 207 125 {wid=212 normal=(0.954761 0.0258756 0.296246)}
Corner 363 125 {wid=213 normal=(0.957075 -0.00105636 0.28984)}
Corner 128 125 {wid=211 normal=(-0.847783 0.183224 0.497687)}
Corner 106 126 {wid=215 normal=(-0.504899 0.759723 0.409758)}
Corner 81 126 {wid=183 normal=(0.955532 0.205096 -0.211883)}
Corner 8 126 {wid=185 normal=(0.00671065 0.738814 0.673876)}
Corner 427 127 {wid=216 normal=(-0.272574 0.961589 -0.0324126)}
Corner 128 127 {wid=217 normal=(-0.534997 0.764104 0.360448)}
Corner 363 127 {wid=214 normal=(0.765794 0.604494 0.219425)}
Corner 189 128 {wid=171 normal=(0.425673 -0.201149 -0.882236)}
Corner 423 128 {wid=1164 normal=(0.855577 -0.132652 -0.500392)}
Corner 163 128 {wid=169 normal=(-0.0877167 -0.238441 -0.967188)}
Corner 182 129 {wid=481 normal=(0.804192 -0.0531578 0.591987)}
Corner 83 129 {wid=219 normal=(-0.158136 -0.146102 0.976549)}
Corner 82 129 {wid=218 normal=(0.821084 -0.0516671 0.568465)}
Corner 165 130 {wid=220 normal=(-0.143713 -0.145342 0.978888)}
Corner 83 130 {wid=219 normal=(-0.158136 -0.146102 0.976549)}
Corner 170 130 {wid=221 normal=(-0.973771 -0.189491 0.125948)}
Corner 165 131 {wid=220 normal=(-0.143713 -0.145342 0.978888)}
Corner 82 131 {wid=218 normal=(0.821084 -0.0516671 0.568465)}
Corner 83 131 {wid=219 normal=(-0.158136 -0.146102 0.976549)}
Corner 502 132 {wid=222 normal=(0.98103 0.0389605 -0.189902)}
Corner 84 132 {wid=60 normal=(0.894103 0.425578 -0.139507)}
Corner 119 132 {wid=24 normal=(0.908819 -0.00467443 -0.417165)}
Corner 501 133 {wid=223 normal=(0.628226 0.6916 0.356401)}
Corner 25 133 {wid=194 normal=(-0.00671065 0.738814 0.673876)}
Corner 84 133 {wid=195 normal=(0.504899 0.759721 0.409758)}
Corner 9 134 {wid=9 normal=(-0.203103 0.248811 -0.947017)}
Corner 85 134 {wid=224 normal=(0.689266 0.238421 -0.684155)}
Corner 264 134 {wid=726 normal=(-0.190205 0.546764 -0.815397)}
Corner 96 135 {wid=226 normal=(-4.02751e-006 0.943551 0.331227)}
Corner 179 135 {wid=227 normal=(4.02871e-006 0.943551 0.331227)}
Corner 144 135 {wid=225 normal=(4.0136e-006 0.946042 0.324043)}
Corner 266 136 {wid=229 normal=(0.802927 -0.420439 0.422538)}
Corner 181 136 {wid=228 normal=(0.660614 -0.615839 -0.429338)}
Corner 268 136 {wid=231 normal=(0.860323 -0.496588 0.115089)}
Corner 39 137 {wid=230 normal=(0.340102 -0.668111 -0.661784)}
Corner 133 137 {wid=368 normal=(-0.340102 -0.668111 -0.661784)}
Corner 135 138 {wid=233 normal=(-0.410626 -0.129138 -0.902613)}
Corner 87 138 {wid=232 normal=(0.0876081 -0.131964 -0.987375)}
Corner 36 138 {wid=234 normal=(-0.997081 -0.0668073 -0.0369678)}
Corner 228 139 {wid=605 normal=(0.852114 -0.176284 -0.492774)}
Corner 46 139 {wid=235 normal=(0.97761 -0.190335 0.0897288)}
Corner 87 139 {wid=232 normal=(0.0876081 -0.131964 -0.987375)}
Corner 70 140 {wid=72 normal=(-0.121938 -0.561137 0.818692)}
Corner 184 140 {wid=237 normal=(-0.331964 -0.857713 0.392592)}
Corner 70 141 {wid=72 normal=(-0.121938 -0.561137 0.818692)}
Corner 117 141 {wid=319 normal=(-0.213802 -0.0586599 0.975114)}
Corner 387 142 {wid=1074 normal=(0.0150934 0.0262485 -0.999542)}
Corner 299 142 {wid=831 normal=(-0.21561 -0.352229 -0.91074)}
Corner 27 142 {wid=148 normal=(0.824242 0.178461 -0.537381)}
Corner 24 143 {wid=54 normal=(-0.962513 0.0685396 0.262437)}
Corner 60 143 {wid=61 normal=(-0.479476 -0.00956728 0.877503)}
Corner 89 143 {wid=174 normal=(-0.769754 -0.211784 0.602185)}
Corner 189 144 {wid=171 normal=(0.425673 -0.201149 -0.882236)}
Corner 90 144 {wid=238 normal=(0.996647 -0.0664186 0.0477804)}
Corner 82 144 {wid=218 normal=(0.821084 -0.0516671 0.568465)}
Corner 45 145 {wid=108 normal=(0.762402 -0.0852369 -0.641466)}
Corner 15 145 {wid=110 normal=(0.943824 0.128633 -0.304383)}
Corner 326 145 {wid=239 normal=(0.929039 -0.251419 -0.27143)}
Corner 150 146 {wid=240 normal=(0.852677 7.37821e-006 -0.522438)}
Corner 91 146 {wid=135 normal=(0.852678 7.3782e-006 -0.522437)}
Corner 172 146 {wid=137 normal=(0.824134 -6.81426e-006 0.566395)}
Corner 150 147 {wid=240 normal=(0.852677 7.37821e-006 -0.522438)}
Corner 287 147 {wid=798 normal=(0.0409818 1.41132e-005 -0.99916)}
Corner 91 147 {wid=135 normal=(0.852678 7.3782e-006 -0.522437)}
Corner 56 148 {wid=134 normal=(0.948439 0.0166693 0.316522)}
Corner 464 148 {wid=242 normal=(0.395789 -0.238275 0.886891)}
Corner 199 148 {wid=136 normal=(0.993201 0.0549632 -0.102614)}
Corner 414 149 {wid=244 normal=(0.466976 -0.0365867 0.883513)}
Corner 333 149 {wid=245 normal=(-0.231565 -0.428902 0.873167)}
Corner 464 149 {wid=243 normal=(0.899131 0.00922871 0.437583)}
Corner 67 150 {wid=247 normal=(-0.0563933 0.313278 -0.947986)}
Corner 93 150 {wid=246 normal=(-0.439854 -0.793636 -0.420323)}
Corner 65 150 {wid=248 normal=(-0.982786 0.122871 0.137968)}
Corner 67 151 {wid=247 normal=(-0.0563933 0.313278 -0.947986)}
Corner 93 151 {wid=246 normal=(-0.439854 -0.793636 -0.420323)}
Corner 324 152 {wid=899 normal=(0.985658 0.150248 -0.0768383)}
Corner 67 152 {wid=247 normal=(-0.0563933 0.313278 -0.947986)}
Corner 66 153 {wid=250 normal=(0.331068 -0.0360768 0.942917)}
Corner 108 153 {wid=251 normal=(-0.218175 -0.605207 0.765588)}
Corner 94 153 {wid=249 normal=(0.522959 -0.815795 -0.246966)}
Corner 143 156 {wid=254 normal=(0.0107234 0.499778 -0.866087)}
Corner 232 156 {wid=253 normal=(0.00520121 0.69086 -0.72297)}
Corner 340 156 {wid=255 normal=(-0.0184147 0.468522 -0.88326)}
Corner 143 157 {wid=254 normal=(0.0107234 0.499778 -0.866087)}
Corner 238 157 {wid=256 normal=(0 0.941437 -0.337188)}
Corner 232 157 {wid=253 normal=(0.00520121 0.69086 -0.72297)}
Corner 178 158 {wid=469 normal=(-0.058053 0.0128031 0.998232)}
Corner 437 158 {wid=1194 normal=(0.0580514 0.0128031 0.998232)}
Corner 98 159 {wid=258 normal=(0 0.433755 0.901031)}
Corner 96 159 {wid=179 normal=(0 0.493971 0.869479)}
Corner 146 159 {wid=180 normal=(0 0.433755 0.901031)}
Corner 304 160 {wid=261 normal=(0 0.524018 0.851707)}
Corner 98 160 {wid=259 normal=(0 0.524018 0.851707)}
Corner 438 160 {wid=263 normal=(0 0.524018 0.851707)}
Corner 41 161 {wid=262 normal=(-0.880324 0.460965 0.111988)}
Corner 205 161 {wid=536 normal=(-0.193883 0.953745 -0.22974)}
Corner 177 161 {wid=260 normal=(-0.867446 0.465311 0.176136)}
Corner 3 162 {wid=267 normal=(0.951888 0.223843 0.209292)}
Corner 99 162 {wid=265 normal=(0.708086 -0.416778 -0.570009)}
Corner 62 162 {wid=269 normal=(0.816214 0.268905 -0.511356)}
Corner 277 163 {wid=268 normal=(0.580706 0.285838 0.762284)}
Corner 142 163 {wid=270 normal=(0.201106 0.336165 0.920081)}
Corner 278 163 {wid=266 normal=(0.580706 0.285838 0.762284)}
Corner 75 164 {wid=193 normal=(-0.973367 0.044302 -0.22493)}
Corner 302 164 {wid=271 normal=(-0.305963 0.863737 0.400432)}
Corner 25 164 {wid=194 normal=(-0.00671065 0.738814 0.673876)}
Corner 321 165 {wid=273 normal=(0 -1 0)}
Corner 29 165 {wid=274 normal=(0 -1 0)}
Corner 190 165 {wid=272 normal=(0 -1 0)}
Corner 136 166 {wid=371 normal=(-0.978102 0.204743 -0.0373688)}
Corner 381 166 {wid=99 normal=(-0.906912 -0.338567 0.250765)}
Corner 51 167 {wid=122 normal=(-0.878715 0.225038 0.420973)}
Corner 136 167 {wid=371 normal=(-0.978102 0.204743 -0.0373688)}
Corner 408 168 {wid=1121 normal=(0 1.41228e-005 -1)}
Corner 283 168 {wid=88 normal=(-0.225944 1.37548e-005 -0.97414)}
Corner 91 168 {wid=90 normal=(0.850008 7.48799e-006 -0.52677)}
Corner 195 169 {wid=199 normal=(-0.879861 6.70713e-006 -0.47523)}
Corner 291 169 {wid=804 normal=(-0.922822 -5.45893e-006 0.385228)}
Corner 141 169 {wid=381 normal=(-0.999937 1.70911e-007 -0.011248)}
Corner 5 170 {wid=278 normal=(0.105432 0.131005 -0.985759)}
Corner 358 170 {wid=1002 normal=(-0.860201 0.00831142 -0.509888)}
Corner 7 170 {wid=280 normal=(-0.836927 0.0674514 -0.543142)}
Corner 126 171 {wid=279 normal=(-0.00230553 -0.999998 0.000255022)}
Corner 305 171 {wid=281 normal=(-0.00373078 -0.999993 0.000396875)}
Corner 358 171 {wid=277 normal=(2.27678e-005 -1 2.32865e-005)}
Corner 53 172 {wid=283 normal=(0.916883 0.394348 0.0617615)}
Corner 104 172 {wid=126 normal=(0.268312 0.89905 0.346002)}
Corner 52 172 {wid=124 normal=(0.182916 0.911737 0.367802)}
Corner 53 173 {wid=284 normal=(0.365021 0.395132 -0.842989)}
Corner 382 173 {wid=285 normal=(0.325833 0.579534 -0.746976)}
Corner 104 173 {wid=282 normal=(0.261087 0.820211 -0.509007)}
Corner 53 174 {wid=284 normal=(0.365021 0.395132 -0.842989)}
Corner 105 174 {wid=287 normal=(0.284235 0.762056 -0.581792)}
Corner 382 174 {wid=285 normal=(0.325833 0.579534 -0.746976)}
Corner 53 175 {wid=44 normal=(0.484084 -0.0675311 0.872412)}
Corner 107 175 {wid=125 normal=(0.984446 -0.0348826 -0.172193)}
Corner 417 175 {wid=1145 normal=(0.906052 -0.272825 0.323476)}
Corner 7 176 {wid=280 normal=(-0.836927 0.0674514 -0.543142)}
Corner 134 176 {wid=288 normal=(-0.91253 0.395356 -0.104799)}
Corner 8 176 {wid=289 normal=(-0.0189398 0.74245 0.669634)}
Corner 7 177 {wid=280 normal=(-0.836927 0.0674514 -0.543142)}
Corner 103 177 {wid=276 normal=(-0.860201 0.00831142 -0.509888)}
Corner 134 177 {wid=288 normal=(-0.91253 0.395356 -0.104799)}
Corner 8 178 {wid=289 normal=(-0.0189398 0.74245 0.669634)}
Corner 107 178 {wid=290 normal=(0.983031 0.12505 0.134214)}
Corner 330 178 {wid=920 normal=(-0.0395833 0.744261 0.666715)}
Corner 305 179 {wid=292 normal=(0.78331 -0.612992 0.103274)}
Corner 416 179 {wid=293 normal=(0.759173 -0.532975 -0.373624)}
Corner 276 179 {wid=291 normal=(0.851956 0.284125 -0.439822)}
Corner 65 180 {wid=248 normal=(-0.982786 0.122871 0.137968)}
Corner 108 180 {wid=251 normal=(-0.218175 -0.605207 0.765588)}
Corner 66 180 {wid=250 normal=(0.331068 -0.0360768 0.942917)}
Corner 65 181 {wid=248 normal=(-0.982786 0.122871 0.137968)}
Corner 93 181 {wid=246 normal=(-0.439854 -0.793636 -0.420323)}
Corner 108 181 {wid=251 normal=(-0.218175 -0.605207 0.765588)}
Corner 279 182 {wid=766 normal=(-0.169868 -0.137751 0.975792)}
Corner 116 182 {wid=317 normal=(0.662786 0.0799745 0.744525)}
Corner 83 183 {wid=100 normal=(0.0640179 -0.877756 0.474812)}
Corner 182 183 {wid=295 normal=(0.331964 -0.857713 0.392592)}
Corner 301 184 {wid=836 normal=(0.715968 0.0696846 0.694645)}
Corner 110 184 {wid=121 normal=(0.879339 -0.474861 0.0356342)}
Corner 48 184 {wid=120 normal=(0.53755 0.292608 -0.790835)}
Corner 112 185 {wid=298 normal=(-0.00632668 -0.998353 -0.0570122)}
Corner 118 185 {wid=299 normal=(0.0205935 -0.999773 -0.00552606)}
Corner 110 185 {wid=296 normal=(0.0209979 -0.999646 -0.0163451)}
Corner 36 186 {wid=234 normal=(-0.997081 -0.0668073 -0.0369678)}
Corner 295 186 {wid=820 normal=(-0.997572 -0.0654858 -0.0237164)}
Corner 135 186 {wid=233 normal=(-0.410626 -0.129138 -0.902613)}
Corner 36 187 {wid=116 normal=(-0.990214 -0.0617282 -0.125162)}
Corner 50 187 {wid=117 normal=(-0.638923 -0.0807716 0.765018)}
Corner 493 187 {wid=1320 normal=(-0.833485 -0.0539916 0.549898)}
Corner 301 188 {wid=836 normal=(0.715968 0.0696846 0.694645)}
Corner 112 188 {wid=302 normal=(0.194745 -0.474158 0.858632)}
Corner 110 188 {wid=121 normal=(0.879339 -0.474861 0.0356342)}
Corner 50 189 {wid=297 normal=(-0.577613 -0.0155202 0.816162)}
Corner 118 189 {wid=303 normal=(-0.606342 -0.750993 0.261453)}
Corner 112 189 {wid=302 normal=(0.194745 -0.474158 0.858632)}
Corner 79 190 {wid=306 normal=(0.302597 -0.835833 -0.458058)}
Corner 394 190 {wid=304 normal=(0.483685 -0.874025 0.0461481)}
Corner 193 190 {wid=308 normal=(0.472213 -0.872108 -0.128232)}
Corner 409 191 {wid=307 normal=(0.93082 -0.0244507 -0.36466)}
Corner 73 191 {wid=187 normal=(0.736123 0.398545 -0.547069)}
Corner 394 191 {wid=305 normal=(0.8867 -0.301003 -0.350942)}
Corner 47 192 {wid=115 normal=(0.353176 0.319994 0.879131)}
Corner 114 192 {wid=309 normal=(0.16498 0.98619 0.014546)}
Corner 275 192 {wid=28 normal=(0.34656 0.750953 0.562108)}
Corner 269 193 {wid=311 normal=(0.935065 -0.152129 -0.320172)}
Corner 323 193 {wid=312 normal=(0.935015 -0.152194 -0.320288)}
Corner 114 193 {wid=310 normal=(0.935042 -0.152173 -0.320219)}
Corner 39 194 {wid=315 normal=(0.565194 0.0500575 -0.823438)}
Corner 115 194 {wid=313 normal=(0.697214 0.191199 -0.690895)}
Corner 254 194 {wid=316 normal=(0.696765 -0.303158 -0.650088)}
Corner 39 195 {wid=230 normal=(0.340102 -0.668111 -0.661784)}
Corner 115 195 {wid=314 normal=(0.829604 -0.447757 -0.333573)}
Corner 15 196 {wid=15 normal=(0.947637 -0.304113 0.0974711)}
Corner 371 196 {wid=1044 normal=(0.89887 -0.350427 0.263121)}
Corner 352 197 {wid=318 normal=(0.00730276 -0.485786 0.874047)}
Corner 401 197 {wid=62 normal=(0.283469 -0.26181 0.922551)}
Corner 194 197 {wid=51 normal=(2.09548e-009 -0.395188 0.9186)}
Corner 456 198 {wid=74 normal=(-0.901057 -0.428475 0.0671155)}
Corner 352 198 {wid=976 normal=(-0.384018 -0.8482 0.364811)}
Corner 194 198 {wid=320 normal=(-0.468409 -0.591226 0.65654)}
Corner 455 199 {wid=1239 normal=(-0.947636 -0.304113 0.0974719)}
Corner 352 199 {wid=976 normal=(-0.384018 -0.8482 0.364811)}
Corner 49 200 {wid=119 normal=(-0.812633 0.230291 -0.535343)}
Corner 118 200 {wid=303 normal=(-0.606342 -0.750993 0.261453)}
Corner 50 200 {wid=297 normal=(-0.577613 -0.0155202 0.816162)}
Corner 49 201 {wid=119 normal=(-0.812633 0.230291 -0.535343)}
Corner 118 201 {wid=303 normal=(-0.606342 -0.750993 0.261453)}
Corner 468 202 {wid=322 normal=(0 -1 0)}
Corner 119 202 {wid=55 normal=(0 -1 0)}
Corner 75 202 {wid=57 normal=(0 -1 0)}
Corner 386 203 {wid=323 normal=(-0.451303 0.221246 -0.864509)}
Corner 385 203 {wid=324 normal=(-0.451303 0.221246 -0.864509)}
Corner 155 203 {wid=321 normal=(-0.371525 -0.377398 -0.848257)}
Corner 297 204 {wid=327 normal=(-0.78331 -0.612992 0.103274)}
Corner 386 204 {wid=326 normal=(-0.851956 0.284125 -0.439822)}
Corner 411 204 {wid=328 normal=(-0.759173 -0.532975 -0.373624)}
Corner 61 205 {wid=151 normal=(-0.93671 0.042744 0.347486)}
Corner 24 205 {wid=152 normal=(-0.957923 0.0920842 0.27185)}
Corner 120 205 {wid=325 normal=(-0.729423 0.184251 -0.658782)}
Corner 376 206 {wid=330 normal=(-0.466977 -0.0365867 0.883513)}
Corner 333 206 {wid=245 normal=(-0.231565 -0.428902 0.873167)}
Corner 414 206 {wid=244 normal=(0.466976 -0.0365867 0.883513)}
Corner 376 207 {wid=93 normal=(-0.388515 -0.192575 0.901094)}
Corner 141 207 {wid=96 normal=(-0.993202 0.0549633 -0.102614)}
Corner 292 207 {wid=329 normal=(-0.395789 -0.238275 0.886891)}
Corner 68 208 {wid=332 normal=(-0.8867 -0.301003 -0.350942)}
Corner 122 208 {wid=191 normal=(-0.8867 -0.301003 -0.350942)}
Corner 420 208 {wid=189 normal=(-0.93082 -0.0244507 -0.36466)}
Corner 223 209 {wid=333 normal=(-0.399457 -0.914021 0.0707083)}
Corner 222 209 {wid=334 normal=(-0.200618 -0.886834 0.416266)}
Corner 381 209 {wid=331 normal=(-0.443806 -0.893066 -0.0739529)}
Corner 58 210 {wid=337 normal=(0.437007 -0.898389 -0.0438496)}
Corner 245 210 {wid=335 normal=(0.443909 -0.539081 0.715776)}
Corner 237 210 {wid=635 normal=(0.544284 -0.838716 -0.0176263)}
Corner 58 211 {wid=141 normal=(-0.981522 0.182192 0.0584899)}
Corner 32 211 {wid=145 normal=(-0.816215 0.268904 -0.511355)}
Corner 280 211 {wid=336 normal=(-0.991112 0.125768 0.0433507)}
Corner 62 212 {wid=341 normal=(0.23044 0.156806 -0.960369)}
Corner 263 212 {wid=339 normal=(0.610714 -0.106722 -0.784627)}
Corner 64 212 {wid=342 normal=(-0.574638 0.117965 -0.809862)}
Corner 62 213 {wid=269 normal=(0.816214 0.268905 -0.511356)}
Corner 99 213 {wid=265 normal=(0.708086 -0.416778 -0.570009)}
Corner 124 213 {wid=340 normal=(0.991112 0.125768 0.0433507)}
Corner 331 214 {wid=922 normal=(0.732505 0.0983596 -0.673618)}
Corner 347 214 {wid=962 normal=(0.647487 0.021701 -0.761767)}
Corner 32 214 {wid=32 normal=(-0.23044 0.156806 -0.960369)}
Corner 35 215 {wid=343 normal=(0.849738 0.18401 0.494051)}
Corner 204 215 {wid=344 normal=(0.27705 0.461878 0.842563)}
Corner 383 216 {wid=347 normal=(-0.389073 0.0869761 -0.917092)}
Corner 126 216 {wid=345 normal=(-0.396052 0.0261731 -0.917855)}
Corner 358 216 {wid=349 normal=(-0.813757 0.000301535 -0.581206)}
Corner 383 217 {wid=348 normal=(0.451303 0.221246 -0.864509)}
Corner 364 217 {wid=350 normal=(0.451303 0.221246 -0.864509)}
Corner 126 217 {wid=346 normal=(0.345151 -0.49242 -0.798995)}
Corner 80 220 {wid=354 normal=(-0.946831 0.0160895 -0.321329)}
Corner 128 220 {wid=352 normal=(-0.954017 0.297262 -0.0385421)}
Corner 427 220 {wid=356 normal=(-0.788446 0.539029 -0.29631)}
Corner 80 221 {wid=355 normal=(0 -1 0)}
Corner 395 221 {wid=357 normal=(0 -1 0)}
Corner 219 221 {wid=353 normal=(0 -1 0)}
Corner 100 222 {wid=360 normal=(-0.355815 0.917834 0.176005)}
Corner 129 222 {wid=358 normal=(0.534997 0.764104 0.360448)}
Corner 337 222 {wid=362 normal=(0.272574 0.961589 -0.0324126)}
Corner 378 223 {wid=361 normal=(-0.957075 -0.00105637 0.28984)}
Corner 321 223 {wid=363 normal=(-0.954761 0.0258756 0.296246)}
Corner 190 223 {wid=359 normal=(0.0677854 -0.0181222 0.997535)}
Corner 40 224 {wid=131 normal=(0.134376 -1.39895e-005 0.99093)}
Corner 210 224 {wid=364 normal=(-0.134377 -1.39962e-005 0.99093)}
Corner 402 224 {wid=400 normal=(0.134377 -1.39895e-005 0.99093)}
Corner 40 225 {wid=131 normal=(0.134376 -1.39895e-005 0.99093)}
Corner 51 225 {wid=365 normal=(-0.981946 -2.67981e-006 0.189162)}
Corner 210 225 {wid=364 normal=(-0.134377 -1.39962e-005 0.99093)}
Corner 73 228 {wid=187 normal=(0.736123 0.398545 -0.547069)}
Corner 132 228 {wid=367 normal=(0.978102 0.204744 -0.0373693)}
Corner 394 228 {wid=305 normal=(0.8867 -0.301003 -0.350942)}
Corner 73 229 {wid=187 normal=(0.736123 0.398545 -0.547069)}
Corner 28 229 {wid=63 normal=(0.844464 0.27469 -0.459812)}
Corner 132 229 {wid=367 normal=(0.978102 0.204744 -0.0373693)}
Corner 441 230 {wid=657 normal=(0.254437 -0.916983 -0.307251)}
Corner 161 230 {wid=434 normal=(-0.829604 -0.447757 -0.333573)}
Corner 55 231 {wid=132 normal=(0.353376 -0.327211 -0.876389)}
Corner 133 231 {wid=368 normal=(-0.340102 -0.668111 -0.661784)}
Corner 106 232 {wid=184 normal=(-0.894104 0.425578 -0.139507)}
Corner 134 232 {wid=369 normal=(-0.98103 0.0389605 -0.189902)}
Corner 103 232 {wid=186 normal=(-0.908819 -0.00467442 -0.417165)}
Corner 106 233 {wid=215 normal=(-0.504899 0.759723 0.409758)}
Corner 8 233 {wid=185 normal=(0.00671065 0.738814 0.673876)}
Corner 134 233 {wid=370 normal=(-0.818872 0.539947 0.194697)}
Corner 187 234 {wid=160 normal=(-0.425673 -0.201149 -0.882237)}
Corner 135 234 {wid=209 normal=(-0.439117 -0.199548 -0.875989)}
Corner 295 234 {wid=821 normal=(-0.997054 -0.0676643 0.0361118)}
Corner 187 235 {wid=160 normal=(-0.425673 -0.201149 -0.882237)}
Corner 79 235 {wid=205 normal=(0.83286 -0.214419 -0.510263)}
Corner 227 235 {wid=606 normal=(0.0877167 -0.238441 -0.967188)}
Corner 101 236 {wid=275 normal=(-0.736123 0.398544 -0.547068)}
Corner 136 236 {wid=371 normal=(-0.978102 0.204743 -0.0373688)}
Corner 51 236 {wid=122 normal=(-0.878715 0.225038 0.420973)}
Corner 101 237 {wid=275 normal=(-0.736123 0.398544 -0.547068)}
Corner 122 237 {wid=191 normal=(-0.8867 -0.301003 -0.350942)}
Corner 136 237 {wid=371 normal=(-0.978102 0.204743 -0.0373688)}
Corner 11 238 {wid=11 normal=(-0.828352 -0.0345488 0.559142)}
Corner 158 239 {wid=428 normal=(0.863874 -0.497627 0.0780372)}
Corner 137 239 {wid=373 normal=(0.537093 -0.226403 0.812572)}
Corner 74 240 {wid=376 normal=(-0.64344 -0.40071 -0.65224)}
Corner 138 240 {wid=374 normal=(-0.346636 -0.459137 -0.817947)}
Corner 68 240 {wid=377 normal=(-0.64344 -0.400709 -0.65224)}
Corner 74 241 {wid=104 normal=(-0.708389 0.30408 -0.636962)}
Corner 200 241 {wid=517 normal=(-0.323791 0.18847 -0.927167)}
Corner 138 241 {wid=375 normal=(-0.345105 0.279656 -0.895933)}
Corner 440 242 {wid=1199 normal=(0.0639027 -0.274665 0.959414)}
Corner 175 243 {wid=457 normal=(0.0769674 -0.843962 0.530852)}
Corner 39 244 {wid=87 normal=(0.362049 0.0782295 -0.928871)}
Corner 482 244 {wid=379 normal=(0.434047 -0.393368 -0.810472)}
Corner 447 244 {wid=89 normal=(-0.434047 -0.393368 -0.810472)}
Corner 39 245 {wid=315 normal=(0.565194 0.0500575 -0.823438)}
Corner 254 245 {wid=316 normal=(0.696765 -0.303158 -0.650088)}
Corner 476 245 {wid=380 normal=(0.325796 -0.164946 -0.93094)}
Corner 102 246 {wid=383 normal=(-0.325796 -0.164946 -0.93094)}
Corner 270 246 {wid=382 normal=(-0.696765 -0.303158 -0.650088)}
Corner 133 246 {wid=384 normal=(-0.565194 0.0500577 -0.823438)}
Corner 283 247 {wid=88 normal=(-0.225944 1.37548e-005 -0.97414)}
Corner 195 247 {wid=199 normal=(-0.879861 6.70713e-006 -0.47523)}
Corner 271 247 {wid=739 normal=(-0.521469 1.20464e-005 -0.85327)}
Corner 336 248 {wid=937 normal=(-0.849738 0.184009 0.494051)}
Corner 466 248 {wid=1263 normal=(-0.646524 0.194492 0.737686)}
Corner 467 248 {wid=386 normal=(-0.248883 0.548747 0.798081)}
Corner 64 249 {wid=342 normal=(-0.574638 0.117965 -0.809862)}
Corner 234 249 {wid=629 normal=(-0.935322 -0.188589 -0.299344)}
Corner 478 249 {wid=1285 normal=(-0.998142 0.0581908 0.0180403)}
Corner 9 250 {wid=388 normal=(0.0202698 0.67308 -0.739292)}
Corner 143 250 {wid=387 normal=(0.0215079 0.708354 -0.70553)}
Corner 85 250 {wid=389 normal=(0.232514 0.712305 -0.662238)}
Corner 9 251 {wid=388 normal=(0.0202698 0.67308 -0.739292)}
Corner 71 251 {wid=390 normal=(-0.221294 0.707756 -0.670903)}
Corner 143 251 {wid=387 normal=(0.0215079 0.708354 -0.70553)}
Corner 85 252 {wid=264 normal=(-0.454583 0.854963 -0.249784)}
Corner 340 252 {wid=391 normal=(-0.453887 0.843881 0.286096)}
Corner 177 252 {wid=260 normal=(-0.867446 0.465311 0.176136)}
Corner 85 253 {wid=264 normal=(-0.454583 0.854963 -0.249784)}
Corner 143 253 {wid=392 normal=(0.453887 0.843881 0.286096)}
Corner 340 253 {wid=391 normal=(-0.453887 0.843881 0.286096)}
Corner 97 254 {wid=257 normal=(0.038502 0.23259 0.971813)}
Corner 239 254 {wid=393 normal=(-0.352004 0.565395 0.745939)}
Corner 146 255 {wid=180 normal=(0 0.433755 0.901031)}
Corner 96 255 {wid=179 normal=(0 0.493971 0.869479)}
Corner 145 255 {wid=394 normal=(0 0.855328 0.518087)}
Corner 97 256 {wid=397 normal=(0.823243 0.566297 0.0397297)}
Corner 146 256 {wid=395 normal=(0.8313 0.554691 -0.0354683)}
Corner 145 256 {wid=398 normal=(0.873469 0.477051 0.0973334)}
Corner 438 257 {wid=263 normal=(0 0.524018 0.851707)}
Corner 98 257 {wid=259 normal=(0 0.524018 0.851707)}
Corner 146 257 {wid=396 normal=(0 0.524018 0.851707)}
Corner 54 260 {wid=76 normal=(0.479719 0.0996946 0.87174)}
Corner 403 260 {wid=401 normal=(-0.161808 0.0720115 0.984191)}
Corner 117 260 {wid=319 normal=(-0.213802 -0.0586599 0.975114)}
Corner 54 261 {wid=129 normal=(0.687627 -1.0239e-005 0.726063)}
Corner 172 261 {wid=449 normal=(0.824361 -7.99856e-006 0.566065)}
Corner 402 261 {wid=400 normal=(0.134377 -1.39895e-005 0.99093)}
Corner 160 262 {wid=94 normal=(-0.353175 0.319994 0.879131)}
Corner 149 262 {wid=402 normal=(-0.129889 -0.693318 0.708829)}
Corner 208 263 {wid=404 normal=(-0.935042 -0.152174 -0.320216)}
Corner 243 263 {wid=405 normal=(-0.935041 -0.152173 -0.320221)}
Corner 442 263 {wid=403 normal=(-0.935039 -0.152138 -0.320243)}
Corner 28 264 {wid=130 normal=(0.857805 7.30082e-006 -0.513976)}
Corner 150 264 {wid=406 normal=(0.857806 7.3008e-006 -0.513974)}
Corner 172 264 {wid=449 normal=(0.824361 -7.99856e-006 0.566065)}
Corner 426 265 {wid=1168 normal=(0.526783 1.20048e-005 -0.85)}
Corner 287 265 {wid=797 normal=(0.102579 1.40492e-005 -0.994725)}
Corner 150 265 {wid=406 normal=(0.857806 7.3008e-006 -0.513974)}
Corner 433 266 {wid=550 normal=(-0.342231 1.32704e-005 -0.939615)}
Corner 287 266 {wid=797 normal=(0.102579 1.40492e-005 -0.994725)}
Corner 432 266 {wid=1180 normal=(0.22411 1.3766e-005 -0.974564)}
Corner 51 267 {wid=365 normal=(-0.981946 -2.67981e-006 0.189162)}
Corner 436 267 {wid=1192 normal=(-0.687629 -1.0239e-005 0.726063)}
Corner 151 267 {wid=407 normal=(-0.857805 7.30093e-006 -0.513975)}
Corner 187 268 {wid=410 normal=(-0.0839995 -0.832451 -0.547694)}
Corner 152 268 {wid=408 normal=(-0.228757 -0.450348 -0.863051)}
Corner 79 268 {wid=412 normal=(0.585519 -0.805486 -0.0914339)}
Corner 37 269 {wid=411 normal=(-0.326962 0.230981 -0.916375)}
Corner 26 269 {wid=413 normal=(-0.613884 0.105292 -0.782343)}
Corner 152 269 {wid=409 normal=(-0.326963 0.230981 -0.916375)}
Corner 111 270 {wid=301 normal=(0.439072 -0.16797 0.882611)}
Corner 153 270 {wid=414 normal=(0.139682 -0.145153 0.979499)}
Corner 154 270 {wid=415 normal=(0.976305 -0.19022 0.103172)}
Corner 295 271 {wid=820 normal=(-0.997572 -0.0654858 -0.0237164)}
Corner 36 271 {wid=234 normal=(-0.997081 -0.0668073 -0.0369678)}
Corner 493 271 {wid=1321 normal=(-0.825323 -0.052926 0.562174)}
Corner 46 272 {wid=235 normal=(0.97761 -0.190335 0.0897288)}
Corner 154 272 {wid=415 normal=(0.976305 -0.19022 0.103172)}
Corner 87 272 {wid=232 normal=(0.0876081 -0.131964 -0.987375)}
Corner 46 273 {wid=235 normal=(0.97761 -0.190335 0.0897288)}
Corner 111 273 {wid=301 normal=(0.439072 -0.16797 0.882611)}
Corner 154 273 {wid=415 normal=(0.976305 -0.19022 0.103172)}
Corner 351 274 {wid=418 normal=(0.813757 0.000301535 -0.581206)}
Corner 155 274 {wid=416 normal=(0.396052 0.0261731 -0.917855)}
Corner 188 274 {wid=420 normal=(0.553129 0.00661669 -0.83307)}
Corner 351 275 {wid=419 normal=(0.00198237 -0.999998 0.000241191)}
Corner 297 275 {wid=421 normal=(0.00371279 -0.999993 0.000356575)}
Corner 411 275 {wid=417 normal=(0.00254064 -0.999997 0.000278416)}
Corner 307 276 {wid=854 normal=(-0.297729 -0.393513 0.869773)}
Corner 156 276 {wid=423 normal=(0.27638 -0.639914 0.717025)}
Corner 185 276 {wid=425 normal=(0 -0.544973 0.838454)}
Corner 294 277 {wid=818 normal=(0.578853 0.0194597 -0.815199)}
Corner 95 277 {wid=252 normal=(0.686827 0.296644 -0.663529)}
Corner 486 277 {wid=1305 normal=(-0.419169 0.132876 -0.898132)}
Corner 513 278 {wid=427 normal=(0.765972 -0.625534 0.148303)}
Corner 137 278 {wid=373 normal=(0.537093 -0.226403 0.812572)}
Corner 22 279 {wid=201 normal=(0.633129 0.771813 0.0587491)}
Corner 296 279 {wid=822 normal=(0.933305 0.342152 0.108973)}
Corner 286 279 {wid=426 normal=(0.677438 0.517632 0.522623)}
Corner 185 280 {wid=425 normal=(0 -0.544973 0.838454)}
Corner 158 280 {wid=429 normal=(-0.433532 -0.517833 0.737496)}
Corner 308 280 {wid=856 normal=(-0.491351 -0.317371 0.811079)}
Corner 262 281 {wid=719 normal=(0.430916 -0.720868 -0.542826)}
Corner 158 281 {wid=428 normal=(0.863874 -0.497627 0.0780372)}
Corner 467 282 {wid=432 normal=(0.532707 0.611883 0.584656)}
Corner 445 282 {wid=430 normal=(0.351847 0.673001 0.650594)}
Corner 336 282 {wid=433 normal=(0.130865 0.713508 0.688317)}
Corner 213 283 {wid=556 normal=(0.445816 -0.244315 -0.861138)}
Corner 62 283 {wid=269 normal=(0.816214 0.268905 -0.511356)}
Corner 445 283 {wid=431 normal=(0.964442 -0.0385043 -0.261475)}
Corner 257 284 {wid=707 normal=(-0.860041 0.200646 -0.469117)}
Corner 160 284 {wid=94 normal=(-0.353175 0.319994 0.879131)}
Corner 239 284 {wid=393 normal=(-0.352004 0.565395 0.745939)}
Corner 71 285 {wid=178 normal=(-0.689265 0.238422 -0.684155)}
Corner 311 285 {wid=866 normal=(0.103675 0.746416 -0.657354)}
Corner 412 285 {wid=547 normal=(-0.223275 0.954009 0.200038)}
Corner 133 286 {wid=368 normal=(-0.340102 -0.668111 -0.661784)}
Corner 161 286 {wid=434 normal=(-0.829604 -0.447757 -0.333573)}
Corner 55 286 {wid=132 normal=(0.353376 -0.327211 -0.876389)}
Corner 133 287 {wid=384 normal=(-0.565194 0.0500577 -0.823438)}
Corner 270 287 {wid=382 normal=(-0.696765 -0.303158 -0.650088)}
Corner 161 287 {wid=435 normal=(-0.697214 0.191199 -0.690895)}
Corner 162 288 {wid=436 normal=(-0.501228 -0.441033 -0.744487)}
Corner 320 288 {wid=885 normal=(0.582796 -0.404103 0.705018)}
Corner 162 289 {wid=436 normal=(-0.501228 -0.441033 -0.744487)}
Corner 300 290 {wid=834 normal=(0.414419 -0.129161 -0.900874)}
Corner 163 290 {wid=437 normal=(-0.110531 -0.132589 -0.984989)}
Corner 423 290 {wid=1165 normal=(0.827383 -0.112459 -0.550264)}
Corner 44 291 {wid=170 normal=(-0.749024 -0.226827 -0.622504)}
Corner 170 291 {wid=168 normal=(-0.97761 -0.190335 0.0897288)}
Corner 163 291 {wid=437 normal=(-0.110531 -0.132589 -0.984989)}
Corner 423 292 {wid=1165 normal=(0.827383 -0.112459 -0.550264)}
Corner 498 292 {wid=1330 normal=(0.9456 -0.0937641 -0.311527)}
Corner 300 292 {wid=834 normal=(0.414419 -0.129161 -0.900874)}
Corner 82 293 {wid=438 normal=(0.806427 -0.0546584 0.588802)}
Corner 165 293 {wid=440 normal=(-0.154454 -0.145935 0.977163)}
Corner 164 293 {wid=439 normal=(0.623812 -0.0797057 0.7775)}
Corner 43 294 {wid=172 normal=(-0.669396 -0.174188 0.722197)}
Corner 165 294 {wid=440 normal=(-0.154454 -0.145935 0.977163)}
Corner 170 294 {wid=168 normal=(-0.97761 -0.190335 0.0897288)}
Corner 43 295 {wid=172 normal=(-0.669396 -0.174188 0.722197)}
Corner 164 295 {wid=439 normal=(0.623812 -0.0797057 0.7775)}
Corner 165 295 {wid=440 normal=(-0.154454 -0.145935 0.977163)}
Corner 484 296 {wid=1 normal=(-0.962462 0.261098 -0.0741227)}
Corner 95 298 {wid=252 normal=(0.686827 0.296644 -0.663529)}
Corner 168 298 {wid=443 normal=(-0.474002 0.372686 -0.797764)}
Corner 486 298 {wid=1305 normal=(-0.419169 0.132876 -0.898132)}
Corner 390 300 {wid=445 normal=(0.0249524 -0.920545 -0.389838)}
Corner 168 300 {wid=444 normal=(0.015772 -0.822228 -0.56894)}
Corner 465 300 {wid=446 normal=(-0.0248163 -0.920525 -0.389895)}
Corner 486 301 {wid=1305 normal=(-0.419169 0.132876 -0.898132)}
Corner 168 301 {wid=443 normal=(-0.474002 0.372686 -0.797764)}
Corner 197 303 {wid=515 normal=(-0.0923451 0.7469 0.658492)}
Corner 494 303 {wid=1322 normal=(-0.122348 0.0806769 0.989203)}
Corner 290 304 {wid=167 normal=(-0.952866 -0.213026 -0.216022)}
Corner 170 304 {wid=221 normal=(-0.973771 -0.189491 0.125948)}
Corner 83 304 {wid=219 normal=(-0.158136 -0.146102 0.976549)}
Corner 290 305 {wid=167 normal=(-0.952866 -0.213026 -0.216022)}
Corner 163 305 {wid=169 normal=(-0.0877167 -0.238441 -0.967188)}
Corner 170 305 {wid=221 normal=(-0.973771 -0.189491 0.125948)}
Corner 296 307 {wid=822 normal=(0.933305 0.342152 0.108973)}
Corner 384 307 {wid=1066 normal=(-0.212633 0.429771 0.877545)}
Corner 40 308 {wid=450 normal=(0.137465 -1.39866e-005 0.990507)}
Corner 172 308 {wid=137 normal=(0.824134 -6.81426e-006 0.566395)}
Corner 474 308 {wid=1277 normal=(0.690295 -9.26699e-006 0.723528)}
Corner 40 309 {wid=131 normal=(0.134376 -1.39895e-005 0.99093)}
Corner 402 309 {wid=400 normal=(0.134377 -1.39895e-005 0.99093)}
Corner 172 309 {wid=449 normal=(0.824361 -7.99856e-006 0.566065)}
Corner 92 310 {wid=200 normal=(0.142648 -1.39781e-005 0.989775)}
Corner 173 310 {wid=451 normal=(0.687547 -1.02545e-005 0.72614)}
Corner 121 310 {wid=197 normal=(-0.142646 -1.39781e-005 0.989774)}
Corner 474 311 {wid=1276 normal=(0.687548 -1.02546e-005 0.726141)}
Corner 199 311 {wid=452 normal=(0.999937 1.70911e-007 -0.011248)}
Corner 173 311 {wid=451 normal=(0.687547 -1.02545e-005 0.72614)}
Corner 475 312 {wid=454 normal=(0.8867 -0.301003 -0.350943)}
Corner 409 312 {wid=307 normal=(0.93082 -0.0244507 -0.36466)}
Corner 394 312 {wid=305 normal=(0.8867 -0.301003 -0.350942)}
Corner 475 313 {wid=455 normal=(0.64344 -0.400709 -0.65224)}
Corner 152 313 {wid=456 normal=(0.346636 -0.459137 -0.817947)}
Corner 174 313 {wid=453 normal=(0.64344 -0.40071 -0.65224)}
Corner 197 314 {wid=459 normal=(-0.0923452 0.7469 0.658493)}
Corner 175 314 {wid=458 normal=(0.0769674 -0.843962 0.530852)}
Corner 494 314 {wid=460 normal=(-0.122348 0.0806769 0.989203)}
Corner 197 315 {wid=515 normal=(-0.0923451 0.7469 0.658492)}
Corner 440 315 {wid=1199 normal=(0.0639027 -0.274665 0.959414)}
Corner 440 316 {wid=1199 normal=(0.0639027 -0.274665 0.959414)}
Corner 296 317 {wid=463 normal=(0.933304 0.342152 0.108973)}
Corner 384 317 {wid=464 normal=(-0.212634 0.429772 0.877544)}
Corner 429 317 {wid=462 normal=(0.617079 -0.547383 0.565319)}
Corner 179 318 {wid=466 normal=(-1 9.86183e-005 -0.000206575)}
Corner 206 318 {wid=465 normal=(-1 1.82505e-006 0.000121235)}
Corner 144 318 {wid=468 normal=(-1 1.49578e-005 0.000330856)}
Corner 98 319 {wid=467 normal=(-0.8313 0.554691 -0.0354682)}
Corner 41 319 {wid=262 normal=(-0.880324 0.460965 0.111988)}
Corner 274 319 {wid=748 normal=(-0.88147 0.462314 0.0963107)}
Corner 273 320 {wid=746 normal=(-0.0385036 0.23259 0.971813)}
Corner 178 320 {wid=469 normal=(-0.058053 0.0128031 0.998232)}
Corner 414 320 {wid=1140 normal=(0.206474 -0.819079 0.535236)}
Corner 41 321 {wid=262 normal=(-0.880324 0.460965 0.111988)}
Corner 98 321 {wid=467 normal=(-0.8313 0.554691 -0.0354682)}
Corner 304 321 {wid=470 normal=(-0.820134 0.570936 0.037586)}
Corner 98 322 {wid=258 normal=(0 0.433755 0.901031)}
Corner 179 322 {wid=471 normal=(0 0.493971 0.869479)}
Corner 96 322 {wid=179 normal=(0 0.493971 0.869479)}
Corner 98 323 {wid=258 normal=(0 0.433755 0.901031)}
Corner 274 323 {wid=472 normal=(0 0.717336 0.696728)}
Corner 179 323 {wid=471 normal=(0 0.493971 0.869479)}
Corner 210 324 {wid=475 normal=(-0.000284401 -0.999998 0.00199279)}
Corner 180 324 {wid=473 normal=(-0.0002943 -0.999998 0.00206073)}
Corner 148 324 {wid=477 normal=(0.0002943 -0.999998 0.00206073)}
Corner 130 325 {wid=476 normal=(-0.676588 0.0929373 0.730473)}
Corner 116 325 {wid=478 normal=(-0.196305 -0.727873 0.657012)}
Corner 180 325 {wid=474 normal=(-0.281157 0.0446223 0.958624)}
Corner 508 326 {wid=479 normal=(0.39285 -0.471953 -0.789259)}
Corner 181 326 {wid=228 normal=(0.660614 -0.615839 -0.429338)}
Corner 267 326 {wid=729 normal=(0.507567 -0.817401 -0.272452)}
Corner 264 327 {wid=725 normal=(0.496832 0.29331 -0.816778)}
Corner 114 327 {wid=480 normal=(0.746108 0.633005 -0.206462)}
Corner 265 327 {wid=727 normal=(0.628745 -0.192601 -0.753382)}
Corner 90 328 {wid=238 normal=(0.996647 -0.0664186 0.0477804)}
Corner 182 328 {wid=481 normal=(0.804192 -0.0531578 0.591987)}
Corner 82 328 {wid=218 normal=(0.821084 -0.0516671 0.568465)}
Corner 90 329 {wid=109 normal=(0.52363 -0.834479 0.171631)}
Corner 182 329 {wid=482 normal=(0.52363 -0.834479 0.171631)}
Corner 60 330 {wid=485 normal=(-0.725011 0.65665 0.207773)}
Corner 463 330 {wid=1257 normal=(0.110271 0.958584 0.262595)}
Corner 255 330 {wid=486 normal=(0.663897 0.64944 -0.370767)}
Corner 60 331 {wid=61 normal=(-0.479476 -0.00956728 0.877503)}
Corner 328 331 {wid=56 normal=(0.0988593 0.0704348 0.992606)}
Corner 463 331 {wid=1256 normal=(0.406227 0.128465 0.904697)}
Corner 63 332 {wid=158 normal=(-0.7581 -0.608838 0.23367)}
Corner 184 332 {wid=488 normal=(-0.52363 -0.834479 0.171631)}
Corner 303 333 {wid=157 normal=(-0.996647 -0.0664181 0.0477801)}
Corner 491 333 {wid=1318 normal=(-0.381745 -0.0985827 0.918994)}
Corner 184 333 {wid=487 normal=(-0.804192 -0.0531573 0.591987)}
Corner 11 334 {wid=11 normal=(-0.828352 -0.0345488 0.559142)}
Corner 309 334 {wid=490 normal=(0.133989 -0.267693 0.954142)}
Corner 320 335 {wid=885 normal=(0.582796 -0.404103 0.705018)}
Corner 185 335 {wid=489 normal=(-3.57628e-007 -0.610405 -0.792089)}
Corner 26 336 {wid=493 normal=(-0.282464 -0.586945 -0.758755)}
Corner 186 336 {wid=491 normal=(-0.31112 -0.619302 -0.720881)}
Corner 42 336 {wid=494 normal=(-0.32368 -0.633194 -0.703062)}
Corner 26 337 {wid=413 normal=(-0.613884 0.105292 -0.782343)}
Corner 37 337 {wid=411 normal=(-0.326962 0.230981 -0.916375)}
Corner 186 337 {wid=492 normal=(-0.613884 0.105292 -0.782343)}
Corner 37 338 {wid=77 normal=(-0.762401 -0.0852374 -0.641467)}
Corner 404 338 {wid=495 normal=(-0.707487 -0.329744 -0.625085)}
Corner 63 338 {wid=73 normal=(-0.929039 -0.251419 -0.27143)}
Corner 37 339 {wid=496 normal=(-0.228756 -0.450348 -0.863051)}
Corner 152 339 {wid=408 normal=(-0.228757 -0.450348 -0.863051)}
Corner 187 339 {wid=410 normal=(-0.0839995 -0.832451 -0.547694)}
Corner 27 340 {wid=497 normal=(0.836927 0.0674515 -0.543142)}
Corner 188 340 {wid=154 normal=(0.642382 0.0601608 -0.76402)}
Corner 387 340 {wid=1073 normal=(-0.105432 0.131005 -0.985759)}
Corner 27 341 {wid=497 normal=(0.836927 0.0674515 -0.543142)}
Corner 351 341 {wid=498 normal=(0.860201 0.00831142 -0.509888)}
Corner 188 341 {wid=154 normal=(0.642382 0.0601608 -0.76402)}
Corner 45 342 {wid=192 normal=(0.228757 -0.450348 -0.863051)}
Corner 189 342 {wid=499 normal=(0.0839995 -0.832451 -0.547694)}
Corner 68 342 {wid=190 normal=(-0.483984 -0.841711 -0.239337)}
Corner 45 343 {wid=108 normal=(0.762402 -0.0852369 -0.641466)}
Corner 326 343 {wid=239 normal=(0.929039 -0.251419 -0.27143)}
Corner 421 343 {wid=500 normal=(0.707488 -0.329743 -0.625084)}
Corner 129 344 {wid=25 normal=(0.954018 0.297262 -0.0385421)}
Corner 221 344 {wid=501 normal=(0.998175 0.0237139 -0.0555331)}
Corner 29 344 {wid=29 normal=(0.946831 0.0160895 -0.321329)}
Corner 129 345 {wid=502 normal=(0.847783 0.183224 0.497687)}
Corner 378 345 {wid=361 normal=(-0.957075 -0.00105637 0.28984)}
Corner 190 345 {wid=359 normal=(0.0677854 -0.0181222 0.997535)}
Corner 192 346 {wid=3 normal=(0.159692 -0.670057 -0.724929)}
Corner 191 346 {wid=503 normal=(-0.40538 -0.633565 0.658985)}
Corner 478 346 {wid=38 normal=(-0.520127 -0.61836 0.589152)}
Corner 99 347 {wid=265 normal=(0.708086 -0.416778 -0.570009)}
Corner 3 347 {wid=267 normal=(0.951888 0.223843 0.209292)}
Corner 191 347 {wid=504 normal=(0.85741 0.17342 -0.484535)}
Corner 99 348 {wid=507 normal=(0.399374 0.907661 -0.129046)}
Corner 310 348 {wid=505 normal=(0.466623 0.88074 -0.0809999)}
Corner 124 348 {wid=509 normal=(0.474383 0.858881 0.19309)}
Corner 249 349 {wid=508 normal=(0.978851 -0.180923 0.0954862)}
Corner 362 349 {wid=510 normal=(0.520022 -0.841048 0.149051)}
Corner 192 349 {wid=506 normal=(0.563944 -0.814594 0.135661)}
Corner 46 350 {wid=207 normal=(0.973771 -0.189492 0.125949)}
Corner 193 350 {wid=176 normal=(0.976651 -0.190122 0.100034)}
Corner 111 350 {wid=159 normal=(0.420084 -0.164547 0.892442)}
Corner 46 351 {wid=207 normal=(0.973771 -0.189492 0.125949)}
Corner 79 351 {wid=205 normal=(0.83286 -0.214419 -0.510263)}
Corner 193 351 {wid=176 normal=(0.976651 -0.190122 0.100034)}
Corner 370 352 {wid=512 normal=(-0.0525061 -0.448979 0.891998)}
Corner 194 352 {wid=51 normal=(2.09548e-009 -0.395188 0.9186)}
Corner 180 352 {wid=47 normal=(0.0247551 0.0123975 0.999617)}
Corner 370 353 {wid=1042 normal=(0.507817 -0.651272 0.563885)}
Corner 456 353 {wid=1241 normal=(0.901058 -0.428474 0.0671149)}
Corner 194 353 {wid=511 normal=(0.468409 -0.591225 0.656539)}
Corner 287 354 {wid=798 normal=(0.0409818 1.41132e-005 -0.99916)}
Corner 380 354 {wid=513 normal=(-0.518116 1.20806e-005 -0.85531)}
Corner 91 354 {wid=135 normal=(0.852678 7.3782e-006 -0.522437)}
Corner 151 355 {wid=241 normal=(-0.852678 7.38484e-006 -0.522438)}
Corner 196 355 {wid=514 normal=(-0.690295 -9.25497e-006 0.723528)}
Corner 380 355 {wid=513 normal=(-0.518116 1.20806e-005 -0.85531)}
Corner 436 356 {wid=1193 normal=(-0.690295 -9.25497e-006 0.723528)}
Corner 196 356 {wid=514 normal=(-0.690295 -9.25497e-006 0.723528)}
Corner 151 356 {wid=241 normal=(-0.852678 7.38484e-006 -0.522438)}
Corner 436 357 {wid=1193 normal=(-0.690295 -9.25497e-006 0.723528)}
Corner 92 357 {wid=133 normal=(0.137464 -1.39866e-005 0.990507)}
Corner 196 357 {wid=514 normal=(-0.690295 -9.25497e-006 0.723528)}
Corner 175 361 {wid=457 normal=(0.0769674 -0.843962 0.530852)}
Corner 91 362 {wid=90 normal=(0.850008 7.48799e-006 -0.52677)}
Corner 199 362 {wid=452 normal=(0.999937 1.70911e-007 -0.011248)}
Corner 474 362 {wid=1276 normal=(0.687548 -1.02546e-005 0.726141)}
Corner 91 363 {wid=90 normal=(0.850008 7.48799e-006 -0.52677)}
Corner 284 363 {wid=86 normal=(0.521469 1.20539e-005 -0.85327)}
Corner 199 363 {wid=452 normal=(0.999937 1.70911e-007 -0.011248)}
Corner 42 364 {wid=82 normal=(0 -0.139361 -0.990242)}
Corner 200 364 {wid=517 normal=(-0.323791 0.18847 -0.927167)}
Corner 209 364 {wid=549 normal=(-0.335349 0.342609 -0.877588)}
Corner 201 365 {wid=518 normal=(0.613884 0.105292 -0.782343)}
Corner 45 365 {wid=107 normal=(0.326962 0.230981 -0.916375)}
Corner 200 365 {wid=106 normal=(0.613884 0.105292 -0.782343)}
Corner 42 366 {wid=520 normal=(0.32368 -0.633194 -0.703062)}
Corner 201 366 {wid=519 normal=(0.31112 -0.619302 -0.720881)}
Corner 200 366 {wid=521 normal=(0.282464 -0.586945 -0.758755)}
Corner 42 367 {wid=520 normal=(0.32368 -0.633194 -0.703062)}
Corner 298 367 {wid=522 normal=(0.32368 -0.633194 -0.703062)}
Corner 201 367 {wid=519 normal=(0.31112 -0.619302 -0.720881)}
Corner 342 368 {wid=523 normal=(-0.428192 0.447876 0.784894)}
Corner 202 368 {wid=142 normal=(-0.428192 0.447876 0.784894)}
Corner 314 368 {wid=144 normal=(-0.201106 0.336165 0.920081)}
Corner 203 369 {wid=524 normal=(-0.651974 0.083435 -0.753637)}
Corner 32 369 {wid=145 normal=(-0.816215 0.268904 -0.511355)}
Corner 202 369 {wid=143 normal=(-0.951888 0.223843 0.209292)}
Corner 342 370 {wid=526 normal=(0.581295 -0.283795 0.762598)}
Corner 215 370 {wid=525 normal=(0.670781 -0.324256 0.667016)}
Corner 216 370 {wid=528 normal=(0.670781 -0.324256 0.667016)}
Corner 31 371 {wid=527 normal=(-0.982907 0.148424 0.108925)}
Corner 32 371 {wid=145 normal=(-0.816215 0.268904 -0.511355)}
Corner 203 371 {wid=524 normal=(-0.651974 0.083435 -0.753637)}
Corner 31 372 {wid=531 normal=(-0.242937 0.697796 0.673841)}
Corner 204 372 {wid=529 normal=(-0.532707 0.611883 0.584656)}
Corner 35 372 {wid=533 normal=(-0.130865 0.713508 0.688317)}
Corner 31 373 {wid=532 normal=(-0.848266 0.441294 -0.292753)}
Corner 203 373 {wid=534 normal=(-0.830442 0.545321 -0.113979)}
Corner 204 373 {wid=530 normal=(-0.701842 0.706779 0.0887772)}
Corner 85 374 {wid=224 normal=(0.689266 0.238421 -0.684155)}
Corner 205 374 {wid=535 normal=(0.860041 0.200645 -0.469117)}
Corner 114 374 {wid=309 normal=(0.16498 0.98619 0.014546)}
Corner 85 375 {wid=264 normal=(-0.454583 0.854963 -0.249784)}
Corner 177 375 {wid=260 normal=(-0.867446 0.465311 0.176136)}
Corner 205 375 {wid=536 normal=(-0.193883 0.953745 -0.22974)}
Corner 274 376 {wid=472 normal=(0 0.717336 0.696728)}
Corner 206 376 {wid=537 normal=(0 0.935108 0.354362)}
Corner 179 376 {wid=471 normal=(0 0.493971 0.869479)}
Corner 177 377 {wid=539 normal=(0 0.941437 -0.337188)}
Corner 144 377 {wid=540 normal=(0 0.702883 -0.711305)}
Corner 206 377 {wid=538 normal=(0 0.941437 -0.337188)}
Corner 72 378 {wid=543 normal=(0 -1 0)}
Corner 207 378 {wid=541 normal=(0 -1 0)}
Corner 80 378 {wid=545 normal=(0 -1 0)}
Corner 72 379 {wid=544 normal=(0.926478 0.0317794 0.375004)}
Corner 81 379 {wid=546 normal=(0.936621 -0.000655751 0.350343)}
Corner 207 379 {wid=542 normal=(0.926478 0.0317794 0.375004)}
Corner 160 380 {wid=548 normal=(-0.93504 -0.152175 -0.320222)}
Corner 208 380 {wid=404 normal=(-0.935042 -0.152174 -0.320216)}
Corner 442 380 {wid=403 normal=(-0.935039 -0.152138 -0.320243)}
Corner 160 381 {wid=94 normal=(-0.353175 0.319994 0.879131)}
Corner 257 381 {wid=707 normal=(-0.860041 0.200646 -0.469117)}
Corner 412 381 {wid=547 normal=(-0.223275 0.954009 0.200038)}
Corner 435 382 {wid=1190 normal=(-0.844464 0.274691 -0.459812)}
Corner 209 382 {wid=549 normal=(-0.335349 0.342609 -0.877588)}
Corner 200 382 {wid=517 normal=(-0.323791 0.18847 -0.927167)}
Corner 51 383 {wid=365 normal=(-0.981946 -2.67981e-006 0.189162)}
Corner 151 383 {wid=407 normal=(-0.857805 7.30093e-006 -0.513975)}
Corner 434 383 {wid=1188 normal=(-0.857805 7.30072e-006 -0.513975)}
Corner 130 384 {wid=551 normal=(-0.00712216 -0.999973 0.00188856)}
Corner 210 384 {wid=475 normal=(-0.000284401 -0.999998 0.00199279)}
Corner 51 384 {wid=552 normal=(-4.99408e-006 -1 -1.61264e-005)}
Corner 130 385 {wid=551 normal=(-0.00712216 -0.999973 0.00188856)}
Corner 180 385 {wid=473 normal=(-0.0002943 -0.999998 0.00206073)}
Corner 210 385 {wid=475 normal=(-0.000284401 -0.999998 0.00199279)}
Corner 34 386 {wid=146 normal=(0.68621 0.250027 0.683082)}
Corner 22 388 {wid=201 normal=(0.633129 0.771813 0.0587491)}
Corner 296 388 {wid=822 normal=(0.933305 0.342152 0.108973)}
Corner 22 389 {wid=53 normal=(0.633129 0.771813 0.0587491)}
Corner 218 389 {wid=579 normal=(-0.0709034 0.671173 -0.737902)}
Corner 365 389 {wid=555 normal=(0 0.999995 -0.00325909)}
Corner 467 390 {wid=558 normal=(0.701841 0.706779 0.0887774)}
Corner 213 390 {wid=557 normal=(0.830752 0.546999 -0.103166)}
Corner 445 390 {wid=559 normal=(0.848266 0.441294 -0.292753)}
Corner 3 391 {wid=267 normal=(0.951888 0.223843 0.209292)}
Corner 62 391 {wid=269 normal=(0.816214 0.268905 -0.511356)}
Corner 213 391 {wid=556 normal=(0.445816 -0.244315 -0.861138)}
Corner 3 392 {wid=562 normal=(0.321811 -0.586166 0.743537)}
Corner 214 392 {wid=560 normal=(0.321811 -0.586166 0.743537)}
Corner 142 392 {wid=564 normal=(0.321811 -0.586166 0.743537)}
Corner 3 393 {wid=563 normal=(-0.573438 -0.818795 0.0272617)}
Corner 231 393 {wid=565 normal=(-0.901492 -0.432667 -0.0105772)}
Corner 240 393 {wid=561 normal=(-0.886219 -0.463015 -0.0152685)}
Corner 203 394 {wid=568 normal=(-0.801792 0.35065 0.483916)}
Corner 215 394 {wid=566 normal=(-0.782873 0.498596 0.372174)}
Corner 204 394 {wid=570 normal=(-0.801792 0.35065 0.483916)}
Corner 343 395 {wid=569 normal=(0.250449 -0.594698 -0.763944)}
Corner 344 395 {wid=571 normal=(0.385009 -0.918713 -0.0879471)}
Corner 345 395 {wid=567 normal=(-0.960975 0.122341 -0.248112)}
Corner 202 396 {wid=574 normal=(0.00877815 -0.60464 -0.79645)}
Corner 216 396 {wid=572 normal=(-0.0992823 -0.821214 -0.561916)}
Corner 203 396 {wid=576 normal=(-0.331197 -0.369194 -0.868334)}
Corner 202 397 {wid=575 normal=(0.573438 -0.818795 0.0272617)}
Corner 342 397 {wid=577 normal=(0.642186 -0.765877 -0.0320897)}
Corner 216 397 {wid=573 normal=(0.901492 -0.432667 -0.0105772)}
Corner 285 399 {wid=794 normal=(-0.12469 0.675132 0.727083)}
Corner 217 399 {wid=578 normal=(-0.96545 0.188575 0.179844)}
Corner 19 400 {wid=581 normal=(-0.00198819 -0.392589 -0.919711)}
Corner 258 400 {wid=580 normal=(0.311888 -0.943783 0.109541)}
Corner 21 400 {wid=582 normal=(-0.0213408 -0.365928 -0.930398)}
Corner 485 401 {wid=1303 normal=(-0.534979 0.834261 0.133437)}
Corner 218 401 {wid=579 normal=(-0.0709034 0.671173 -0.737902)}
Corner 128 402 {wid=211 normal=(-0.847783 0.183224 0.497687)}
Corner 219 402 {wid=583 normal=(-0.852291 -0.0100937 0.52297)}
Corner 395 402 {wid=1088 normal=(-0.0677854 -0.0181222 0.997535)}
Corner 128 403 {wid=352 normal=(-0.954017 0.297262 -0.0385421)}
Corner 80 403 {wid=354 normal=(-0.946831 0.0160895 -0.321329)}
Corner 219 403 {wid=584 normal=(-0.998175 0.0237139 -0.0555331)}
Corner 175 405 {wid=457 normal=(0.0769674 -0.843962 0.530852)}
Corner 190 406 {wid=359 normal=(0.0677854 -0.0181222 0.997535)}
Corner 221 406 {wid=586 normal=(0.852291 -0.0100937 0.52297)}
Corner 129 406 {wid=502 normal=(0.847783 0.183224 0.497687)}
Corner 190 407 {wid=588 normal=(0.0729118 -0.686081 0.723862)}
Corner 29 407 {wid=589 normal=(0.660158 -0.718095 -0.2203)}
Corner 221 407 {wid=587 normal=(0.717408 -0.674257 0.175226)}
Corner 410 408 {wid=591 normal=(-0.200618 -0.886834 0.416266)}
Corner 222 408 {wid=334 normal=(-0.200618 -0.886834 0.416266)}
Corner 223 408 {wid=333 normal=(-0.399457 -0.914021 0.0707083)}
Corner 279 409 {wid=766 normal=(-0.169868 -0.137751 0.975792)}
Corner 222 409 {wid=590 normal=(-0.386485 -0.511135 0.767704)}
Corner 68 410 {wid=594 normal=(-0.350995 -0.854014 -0.384008)}
Corner 223 410 {wid=592 normal=(-0.472212 -0.872108 -0.128232)}
Corner 122 410 {wid=596 normal=(-0.482825 -0.858965 0.170465)}
Corner 290 411 {wid=595 normal=(-0.161351 0.986814 -0.0127871)}
Corner 83 411 {wid=597 normal=(0.00884043 0.99186 0.127024)}
Corner 223 411 {wid=593 normal=(-0.169808 0.984837 0.0355105)}
Corner 58 412 {wid=141 normal=(-0.981522 0.182192 0.0584899)}
Corner 511 412 {wid=598 normal=(-0.822572 -0.12787 -0.554098)}
Corner 202 412 {wid=143 normal=(-0.951888 0.223843 0.209292)}
Corner 248 413 {wid=683 normal=(-0.159692 -0.670057 -0.724929)}
Corner 125 413 {wid=338 normal=(0.520127 -0.61836 0.589152)}
Corner 247 413 {wid=599 normal=(-0.0238278 -0.515418 0.856607)}
Corner 137 415 {wid=372 normal=(0.537093 -0.226403 0.812572)}
Corner 511 416 {wid=598 normal=(-0.822572 -0.12787 -0.554098)}
Corner 226 416 {wid=601 normal=(-0.943845 0.310279 0.113502)}
Corner 202 416 {wid=143 normal=(-0.951888 0.223843 0.209292)}
Corner 369 417 {wid=1040 normal=(0.0900393 -0.0543206 -0.994456)}
Corner 367 417 {wid=1030 normal=(0.113809 -0.135757 -0.984184)}
Corner 368 417 {wid=602 normal=(0.603033 0.389804 -0.695991)}
Corner 135 418 {wid=233 normal=(-0.410626 -0.129138 -0.902613)}
Corner 228 418 {wid=605 normal=(0.852114 -0.176284 -0.492774)}
Corner 87 418 {wid=232 normal=(0.0876081 -0.131964 -0.987375)}
Corner 135 419 {wid=209 normal=(-0.439117 -0.199548 -0.875989)}
Corner 187 419 {wid=160 normal=(-0.425673 -0.201149 -0.882237)}
Corner 227 419 {wid=606 normal=(0.0877167 -0.238441 -0.967188)}
Corner 227 420 {wid=609 normal=(0.00852037 0.924622 -0.380791)}
Corner 228 420 {wid=607 normal=(0.369067 0.904873 -0.212117)}
Corner 135 420 {wid=611 normal=(-0.168681 0.926568 -0.336182)}
Corner 227 421 {wid=610 normal=(0.121172 -0.133162 -0.983659)}
Corner 46 421 {wid=612 normal=(0.976188 -0.190797 0.103213)}
Corner 228 421 {wid=608 normal=(0.83913 -0.175972 -0.514679)}
Corner 105 422 {wid=286 normal=(-0.606138 -0.509583 -0.610673)}
Corner 229 422 {wid=613 normal=(0.285196 -0.349738 -0.892383)}
Corner 5 422 {wid=5 normal=(-0.015093 0.0262476 -0.999542)}
Corner 105 423 {wid=287 normal=(0.284235 0.762056 -0.581792)}
Corner 53 423 {wid=284 normal=(0.365021 0.395132 -0.842989)}
Corner 417 423 {wid=614 normal=(0.239118 0.841127 -0.485106)}
Corner 34 424 {wid=70 normal=(0.648159 0.0211272 0.761212)}
Corner 230 424 {wid=615 normal=(-0.0296346 0.0852488 0.995919)}
Corner 35 424 {wid=71 normal=(0.373135 0.0229888 0.927492)}
Corner 34 425 {wid=146 normal=(0.68621 0.250027 0.683082)}
Corner 230 425 {wid=616 normal=(-0.134954 0.152573 0.979035)}
Corner 213 426 {wid=619 normal=(0.289116 0.0549553 -0.955715)}
Corner 231 426 {wid=617 normal=(0.449911 -0.353984 -0.819924)}
Corner 3 426 {wid=621 normal=(0.289116 0.0549553 -0.955715)}
Corner 359 427 {wid=620 normal=(0.494566 -0.301434 0.815194)}
Corner 240 427 {wid=622 normal=(0.362274 -0.435406 0.824123)}
Corner 360 427 {wid=618 normal=(0.804729 -0.141515 0.576529)}
Corner 96 428 {wid=179 normal=(0 0.493971 0.869479)}
Corner 233 428 {wid=623 normal=(0 0.935108 0.354362)}
Corner 238 428 {wid=177 normal=(0 0.935108 0.354362)}
Corner 96 429 {wid=226 normal=(-4.02751e-006 0.943551 0.331227)}
Corner 144 429 {wid=225 normal=(4.0136e-006 0.946042 0.324043)}
Corner 487 429 {wid=624 normal=(-4.0136e-006 0.946042 0.324043)}
Corner 487 430 {wid=627 normal=(1 1.49578e-005 0.000330856)}
Corner 233 430 {wid=625 normal=(1 1.82504e-006 0.000121235)}
Corner 96 430 {wid=628 normal=(1 9.86184e-005 -0.000206575)}
Corner 232 431 {wid=253 normal=(0.00520121 0.69086 -0.72297)}
Corner 238 431 {wid=256 normal=(0 0.941437 -0.337188)}
Corner 233 431 {wid=626 normal=(0 0.941437 -0.337188)}
Corner 263 432 {wid=339 normal=(0.610714 -0.106722 -0.784627)}
Corner 234 432 {wid=629 normal=(-0.935322 -0.188589 -0.299344)}
Corner 64 432 {wid=342 normal=(-0.574638 0.117965 -0.809862)}
Corner 407 433 {wid=630 normal=(-0.304781 -0.563127 -0.768113)}
Corner 460 433 {wid=1250 normal=(-0.443909 -0.539081 0.715776)}
Corner 234 433 {wid=36 normal=(-0.401139 -0.87131 -0.282678)}
Corner 8 434 {wid=289 normal=(-0.0189398 0.74245 0.669634)}
Corner 235 434 {wid=632 normal=(0.93671 0.042744 0.347486)}
Corner 107 434 {wid=290 normal=(0.983031 0.12505 0.134214)}
Corner 8 435 {wid=185 normal=(0.00671065 0.738814 0.673876)}
Corner 81 435 {wid=183 normal=(0.955532 0.205096 -0.211883)}
Corner 235 435 {wid=631 normal=(0.879032 0.0281601 0.475931)}
Corner 236 436 {wid=633 normal=(-0.90941 -0.340812 -0.238371)}
Corner 10 437 {wid=48 normal=(-0.683589 0.238787 0.6897)}
Corner 236 437 {wid=633 normal=(-0.90941 -0.340812 -0.238371)}
Corner 237 438 {wid=634 normal=(0.988649 -0.149506 -0.0148549)}
Corner 35 438 {wid=343 normal=(0.849738 0.18401 0.494051)}
Corner 125 439 {wid=338 normal=(0.520127 -0.61836 0.589152)}
Corner 58 439 {wid=337 normal=(0.437007 -0.898389 -0.0438496)}
Corner 237 439 {wid=635 normal=(0.544284 -0.838716 -0.0176263)}
Corner 71 440 {wid=638 normal=(0.454583 0.854963 -0.249784)}
Corner 238 440 {wid=636 normal=(0.598656 0.800436 -0.030236)}
Corner 143 440 {wid=640 normal=(0.453887 0.843881 0.286096)}
Corner 257 441 {wid=639 normal=(-0.757738 0.5458 0.357681)}
Corner 145 441 {wid=641 normal=(-0.802688 0.393751 0.447942)}
Corner 238 441 {wid=637 normal=(-0.757738 0.5458 0.357681)}
Corner 145 442 {wid=643 normal=(-0.970526 -0.219695 0.0990595)}
Corner 239 442 {wid=642 normal=(-0.958965 -0.276973 0.060602)}
Corner 97 442 {wid=644 normal=(-0.689567 -0.31317 0.653009)}
Corner 145 443 {wid=643 normal=(-0.970526 -0.219695 0.0990595)}
Corner 257 443 {wid=645 normal=(-0.979642 -0.130303 0.152716)}
Corner 239 443 {wid=642 normal=(-0.958965 -0.276973 0.060602)}
Corner 214 444 {wid=647 normal=(0.0875935 0.128379 0.987849)}
Corner 240 444 {wid=646 normal=(-0.104646 0.139044 0.984742)}
Corner 359 444 {wid=649 normal=(0.204073 0.368481 0.90696)}
Corner 214 445 {wid=648 normal=(-0.642186 -0.765877 -0.0320897)}
Corner 3 445 {wid=563 normal=(-0.573438 -0.818795 0.0272617)}
Corner 240 445 {wid=561 normal=(-0.886219 -0.463015 -0.0152685)}
Corner 2 446 {wid=650 normal=(-0.686211 0.250027 0.683082)}
Corner 484 446 {wid=1 normal=(-0.962462 0.261098 -0.0741227)}
Corner 2 447 {wid=650 normal=(-0.686211 0.250027 0.683082)}
Corner 224 448 {wid=653 normal=(0.183264 0.245187 0.951997)}
Corner 247 448 {wid=651 normal=(0.195269 0.281412 0.939509)}
Corner 125 448 {wid=655 normal=(-0.016731 0.394151 0.918893)}
Corner 244 449 {wid=654 normal=(-0.580177 -0.232197 -0.780692)}
Corner 248 449 {wid=656 normal=(-0.677485 -0.310431 -0.666818)}
Corner 242 449 {wid=652 normal=(-0.580177 -0.232197 -0.780692)}
Corner 55 450 {wid=659 normal=(-0.383541 -0.342221 -0.857777)}
Corner 243 450 {wid=658 normal=(-0.660614 -0.615839 -0.429339)}
Corner 312 450 {wid=660 normal=(-0.63609 -0.0819 -0.767256)}
Corner 55 451 {wid=132 normal=(0.353376 -0.327211 -0.876389)}
Corner 161 451 {wid=434 normal=(-0.829604 -0.447757 -0.333573)}
Corner 441 451 {wid=657 normal=(0.254437 -0.916983 -0.307251)}
Corner 224 452 {wid=663 normal=(-0.264371 0.444318 0.855973)}
Corner 507 452 {wid=661 normal=(-0.154442 0.499096 0.852673)}
Corner 242 452 {wid=665 normal=(-0.264371 0.444318 0.855973)}
Corner 224 453 {wid=664 normal=(0.0919248 0.913597 -0.396094)}
Corner 248 453 {wid=666 normal=(0.028191 0.116077 -0.99284)}
Corner 244 453 {wid=662 normal=(0.168281 0.0162169 -0.985606)}
Corner 123 454 {wid=668 normal=(-0.673642 0.67002 -0.311897)}
Corner 246 454 {wid=667 normal=(-0.549976 0.817384 0.171494)}
Corner 58 454 {wid=670 normal=(-0.671737 0.735454 -0.088754)}
Corner 348 455 {wid=964 normal=(0.316301 -0.702564 -0.637462)}
Corner 237 455 {wid=635 normal=(0.544284 -0.838716 -0.0176263)}
Corner 245 455 {wid=335 normal=(0.443909 -0.539081 0.715776)}
Corner 496 456 {wid=673 normal=(-0.722548 -0.689809 0.0456897)}
Corner 449 456 {wid=671 normal=(-0.742335 -0.669847 0.0156202)}
Corner 348 456 {wid=675 normal=(-0.506678 -0.84641 0.163914)}
Corner 245 457 {wid=674 normal=(0.12264 0.298573 0.946474)}
Corner 58 457 {wid=676 normal=(-0.0889453 0.0858136 0.992333)}
Corner 246 457 {wid=672 normal=(0.183393 0.167208 0.968715)}
Corner 242 458 {wid=679 normal=(-0.430787 -0.164163 0.887397)}
Corner 247 458 {wid=677 normal=(-0.494583 -0.253615 0.831305)}
Corner 224 458 {wid=681 normal=(-0.458266 -0.15373 0.87542)}
Corner 242 459 {wid=680 normal=(-0.978851 -0.180923 0.0954862)}
Corner 248 459 {wid=682 normal=(-0.563944 -0.814594 0.135661)}
Corner 247 459 {wid=678 normal=(-0.520022 -0.841048 0.149051)}
Corner 58 460 {wid=684 normal=(-0.225738 -0.320443 -0.919977)}
Corner 248 460 {wid=666 normal=(0.028191 0.116077 -0.99284)}
Corner 224 460 {wid=664 normal=(0.0919248 0.913597 -0.396094)}
Corner 58 461 {wid=337 normal=(0.437007 -0.898389 -0.0438496)}
Corner 125 461 {wid=338 normal=(0.520127 -0.61836 0.589152)}
Corner 248 461 {wid=683 normal=(-0.159692 -0.670057 -0.724929)}
Corner 357 462 {wid=687 normal=(0.580177 -0.232197 -0.780692)}
Corner 249 462 {wid=685 normal=(0.580177 -0.232197 -0.780692)}
Corner 192 462 {wid=689 normal=(0.677485 -0.310431 -0.666818)}
Corner 462 463 {wid=688 normal=(0.485283 -0.143142 0.862561)}
Corner 362 463 {wid=690 normal=(0.494583 -0.253615 0.831305)}
Corner 249 463 {wid=686 normal=(0.430787 -0.164163 0.887397)}
Corner 428 464 {wid=1172 normal=(-0.424149 -0.208663 -0.881225)}
Corner 250 464 {wid=691 normal=(0.379854 -0.255921 -0.888941)}
Corner 64 464 {wid=156 normal=(-0.482358 -0.205572 -0.851511)}
Corner 428 465 {wid=1173 normal=(-0.550002 -0.0093556 -0.835111)}
Corner 250 465 {wid=692 normal=(0.244695 -0.097176 -0.964718)}
Corner 70 466 {wid=72 normal=(-0.121938 -0.561137 0.818692)}
Corner 251 466 {wid=693 normal=(-0.159337 -0.206901 0.9653)}
Corner 117 466 {wid=319 normal=(-0.213802 -0.0586599 0.975114)}
Corner 252 467 {wid=694 normal=(0.386485 -0.511135 0.767704)}
Corner 113 467 {wid=113 normal=(0.906912 -0.338567 0.250765)}
Corner 251 467 {wid=52 normal=(0.460284 -0.059013 0.885808)}
Corner 70 468 {wid=697 normal=(-0.315277 -0.54924 0.773909)}
Corner 252 468 {wid=695 normal=(-0.373527 -0.649391 0.662397)}
Corner 251 468 {wid=698 normal=(-0.230853 -0.390393 0.891235)}
Corner 480 469 {wid=208 normal=(0.200618 -0.886834 0.416266)}
Corner 113 469 {wid=204 normal=(0.443806 -0.893067 -0.0739522)}
Corner 252 469 {wid=696 normal=(0.200618 -0.886834 0.416266)}
Corner 253 470 {wid=699 normal=(0.990644 -0.0880863 0.104235)}
Corner 250 470 {wid=692 normal=(0.244695 -0.097176 -0.964718)}
Corner 2 471 {wid=650 normal=(-0.686211 0.250027 0.683082)}
Corner 253 471 {wid=699 normal=(0.990644 -0.0880863 0.104235)}
Corner 199 472 {wid=136 normal=(0.993201 0.0549632 -0.102614)}
Corner 254 472 {wid=700 normal=(0.998137 -0.0548471 -0.0267104)}
Corner 115 472 {wid=138 normal=(0.984651 0.0846602 -0.152628)}
Corner 199 473 {wid=702 normal=(0.201293 -0.978403 0.0470054)}
Corner 284 473 {wid=703 normal=(0.00114083 -0.985566 -0.16929)}
Corner 254 473 {wid=701 normal=(0.0969369 -0.994701 0.0342567)}
Corner 69 474 {wid=704 normal=(0.246541 0.288326 -0.925249)}
Corner 255 474 {wid=486 normal=(0.663897 0.64944 -0.370767)}
Corner 183 474 {wid=484 normal=(0.685062 0.46838 -0.557951)}
Corner 69 475 {wid=705 normal=(-0.284235 0.762055 -0.581793)}
Corner 430 475 {wid=150 normal=(-0.277194 0.756013 -0.592965)}
Corner 255 475 {wid=149 normal=(-0.336806 0.574854 -0.745724)}
Corner 71 478 {wid=709 normal=(-0.221294 0.707756 -0.670903)}
Corner 257 478 {wid=708 normal=(-0.439471 0.76863 -0.464837)}
Corner 238 478 {wid=710 normal=(-0.439471 0.76863 -0.464837)}
Corner 71 479 {wid=178 normal=(-0.689265 0.238422 -0.684155)}
Corner 412 479 {wid=547 normal=(-0.223275 0.954009 0.200038)}
Corner 257 479 {wid=707 normal=(-0.860041 0.200646 -0.469117)}
Corner 258 480 {wid=711 normal=(0.311888 -0.943783 0.109541)}
Corner 334 480 {wid=714 normal=(-0.475024 -0.827081 0.300481)}
Corner 372 481 {wid=713 normal=(0.411303 0.189226 0.891641)}
Corner 21 481 {wid=582 normal=(-0.0213408 -0.365928 -0.930398)}
Corner 258 481 {wid=580 normal=(0.311888 -0.943783 0.109541)}
Corner 372 482 {wid=715 normal=(0.411303 0.189226 0.891641)}
Corner 334 482 {wid=714 normal=(-0.475024 -0.827081 0.300481)}
Corner 372 483 {wid=715 normal=(0.411303 0.189226 0.891641)}
Corner 258 483 {wid=711 normal=(0.311888 -0.943783 0.109541)}
Corner 260 484 {wid=716 normal=(0.00429493 -0.830333 0.557252)}
Corner 27 486 {wid=497 normal=(0.836927 0.0674515 -0.543142)}
Corner 261 486 {wid=717 normal=(0.876333 0.118797 -0.466828)}
Corner 351 486 {wid=498 normal=(0.860201 0.00831142 -0.509888)}
Corner 27 487 {wid=497 normal=(0.836927 0.0674515 -0.543142)}
Corner 328 487 {wid=718 normal=(0.0395833 0.744261 0.666715)}
Corner 261 487 {wid=717 normal=(0.876333 0.118797 -0.466828)}
Corner 185 488 {wid=425 normal=(0 -0.544973 0.838454)}
Corner 262 488 {wid=720 normal=(-0.36581 -0.537275 0.759947)}
Corner 158 488 {wid=429 normal=(-0.433532 -0.517833 0.737496)}
Corner 185 489 {wid=489 normal=(-3.57628e-007 -0.610405 -0.792089)}
Corner 262 489 {wid=719 normal=(0.430916 -0.720868 -0.542826)}
Corner 124 490 {wid=340 normal=(0.991112 0.125768 0.0433507)}
Corner 263 490 {wid=721 normal=(0.991112 0.125768 0.0433507)}
Corner 62 490 {wid=269 normal=(0.816214 0.268905 -0.511356)}
Corner 124 491 {wid=723 normal=(0.499556 -0.378578 -0.77918)}
Corner 234 491 {wid=724 normal=(0.499556 -0.378578 -0.77918)}
Corner 293 491 {wid=722 normal=(0.499556 -0.378578 -0.77918)}
Corner 508 492 {wid=479 normal=(0.39285 -0.471953 -0.789259)}
Corner 264 492 {wid=725 normal=(0.496832 0.29331 -0.816778)}
Corner 265 492 {wid=727 normal=(0.628745 -0.192601 -0.753382)}
Corner 9 493 {wid=9 normal=(-0.203103 0.248811 -0.947017)}
Corner 264 493 {wid=726 normal=(-0.190205 0.546764 -0.815397)}
Corner 322 494 {wid=890 normal=(0.935023 -0.152186 -0.320266)}
Corner 265 494 {wid=728 normal=(0.935039 -0.152174 -0.320228)}
Corner 114 494 {wid=310 normal=(0.935042 -0.152173 -0.320219)}
Corner 181 495 {wid=228 normal=(0.660614 -0.615839 -0.429338)}
Corner 508 495 {wid=479 normal=(0.39285 -0.471953 -0.789259)}
Corner 265 495 {wid=727 normal=(0.628745 -0.192601 -0.753382)}
Corner 115 496 {wid=314 normal=(0.829604 -0.447757 -0.333573)}
Corner 266 496 {wid=98 normal=(0.227239 -0.435966 0.870802)}
Corner 56 496 {wid=97 normal=(0.547319 -0.831191 0.097798)}
Corner 115 497 {wid=314 normal=(0.829604 -0.447757 -0.333573)}
Corner 508 497 {wid=1354 normal=(-0.351874 -0.508599 -0.785819)}
Corner 267 497 {wid=730 normal=(-0.183368 -0.980586 -0.0694755)}
Corner 266 498 {wid=229 normal=(0.802927 -0.420439 0.422538)}
Corner 267 498 {wid=729 normal=(0.507567 -0.817401 -0.272452)}
Corner 181 498 {wid=228 normal=(0.660614 -0.615839 -0.429338)}
Corner 266 499 {wid=98 normal=(0.227239 -0.435966 0.870802)}
Corner 115 499 {wid=314 normal=(0.829604 -0.447757 -0.333573)}
Corner 267 499 {wid=730 normal=(-0.183368 -0.980586 -0.0694755)}
Corner 269 500 {wid=732 normal=(0.179861 0.0640434 -0.981605)}
Corner 268 500 {wid=731 normal=(0.334954 0.521678 -0.784638)}
Corner 323 500 {wid=734 normal=(0.541818 0.784052 -0.302812)}
Corner 269 501 {wid=733 normal=(0.944116 -0.212438 0.252021)}
Corner 266 501 {wid=229 normal=(0.802927 -0.420439 0.422538)}
Corner 268 501 {wid=231 normal=(0.860323 -0.496588 0.115089)}
Corner 47 502 {wid=736 normal=(0.143243 -0.35411 -0.924169)}
Corner 269 502 {wid=735 normal=(0.179861 0.0640434 -0.981605)}
Corner 114 502 {wid=738 normal=(0.306994 -0.936807 -0.167775)}
Corner 47 503 {wid=737 normal=(0.941043 0.0913111 0.325732)}
Corner 266 503 {wid=229 normal=(0.802927 -0.420439 0.422538)}
Corner 269 503 {wid=733 normal=(0.944116 -0.212438 0.252021)}
Corner 141 504 {wid=381 normal=(-0.999937 1.70911e-007 -0.011248)}
Corner 271 504 {wid=739 normal=(-0.521469 1.20464e-005 -0.85327)}
Corner 195 504 {wid=199 normal=(-0.879861 6.70713e-006 -0.47523)}
Corner 141 505 {wid=96 normal=(-0.993202 0.0549633 -0.102614)}
Corner 161 505 {wid=95 normal=(-0.984651 0.0846602 -0.152628)}
Corner 270 505 {wid=740 normal=(-0.998137 -0.0548471 -0.0267104)}
Corner 270 506 {wid=742 normal=(-0.0969369 -0.994701 0.0342567)}
Corner 271 506 {wid=741 normal=(-0.00114084 -0.985566 -0.16929)}
Corner 141 506 {wid=743 normal=(-0.201293 -0.978403 0.0470054)}
Corner 270 507 {wid=742 normal=(-0.0969369 -0.994701 0.0342567)}
Corner 102 507 {wid=744 normal=(-0.0219785 -0.962802 -0.269314)}
Corner 271 507 {wid=741 normal=(-0.00114084 -0.985566 -0.16929)}
Corner 275 510 {wid=28 normal=(0.34656 0.750953 0.562108)}
Corner 273 510 {wid=746 normal=(-0.0385036 0.23259 0.971813)}
Corner 47 510 {wid=115 normal=(0.353176 0.319994 0.879131)}
Corner 41 511 {wid=262 normal=(-0.880324 0.460965 0.111988)}
Corner 304 511 {wid=470 normal=(-0.820134 0.570936 0.037586)}
Corner 451 511 {wid=747 normal=(-0.823243 0.566297 0.0397297)}
Corner 177 512 {wid=260 normal=(-0.867446 0.465311 0.176136)}
Corner 274 512 {wid=748 normal=(-0.88147 0.462314 0.0963107)}
Corner 41 512 {wid=262 normal=(-0.880324 0.460965 0.111988)}
Corner 177 513 {wid=749 normal=(0 0.935108 0.354362)}
Corner 206 513 {wid=537 normal=(0 0.935108 0.354362)}
Corner 274 513 {wid=472 normal=(0 0.717336 0.696728)}
Corner 41 514 {wid=751 normal=(0.117949 0.709169 0.695102)}
Corner 275 514 {wid=750 normal=(0.272579 0.779267 0.564309)}
Corner 205 514 {wid=752 normal=(0.285218 0.878497 0.383268)}
Corner 41 515 {wid=751 normal=(0.117949 0.709169 0.695102)}
Corner 451 515 {wid=753 normal=(-0.506792 0.563462 0.652436)}
Corner 275 515 {wid=750 normal=(0.272579 0.779267 0.564309)}
Corner 107 516 {wid=756 normal=(0.88708 0.201574 -0.415279)}
Corner 276 516 {wid=754 normal=(0.88708 0.201574 -0.415279)}
Corner 383 516 {wid=757 normal=(0.0218794 0.124831 -0.991937)}
Corner 107 517 {wid=290 normal=(0.983031 0.12505 0.134214)}
Corner 235 517 {wid=632 normal=(0.93671 0.042744 0.347486)}
Corner 276 517 {wid=755 normal=(0.983031 0.12505 0.134214)}
Corner 3 518 {wid=267 normal=(0.951888 0.223843 0.209292)}
Corner 277 518 {wid=758 normal=(0.943845 0.310279 0.113502)}
Corner 356 518 {wid=994 normal=(0.95293 0.267271 0.143147)}
Corner 3 519 {wid=759 normal=(0.428192 0.447876 0.784894)}
Corner 142 519 {wid=270 normal=(0.201106 0.336165 0.920081)}
Corner 277 519 {wid=268 normal=(0.580706 0.285838 0.762284)}
Corner 191 520 {wid=762 normal=(-0.205656 -0.975747 0.074986)}
Corner 278 520 {wid=760 normal=(-0.584368 -0.811434 -0.00938159)}
Corner 142 520 {wid=764 normal=(-0.672534 -0.615184 0.411396)}
Corner 353 521 {wid=763 normal=(0.6071 0.792395 -0.0594915)}
Corner 354 521 {wid=765 normal=(-0.154651 0.986112 -0.0605445)}
Corner 335 521 {wid=761 normal=(0.903478 0.426576 -0.0419504)}
Corner 410 522 {wid=768 normal=(0.450216 -0.762915 0.463968)}
Corner 279 522 {wid=767 normal=(0.230853 -0.390393 0.891235)}
Corner 222 522 {wid=769 normal=(0.373527 -0.649391 0.662397)}
Corner 83 523 {wid=100 normal=(0.0640179 -0.877756 0.474812)}
Corner 279 523 {wid=766 normal=(-0.169868 -0.137751 0.975792)}
Corner 281 524 {wid=770 normal=(-0.259452 -0.51857 -0.814721)}
Corner 280 524 {wid=31 normal=(-0.610713 -0.106723 -0.784627)}
Corner 347 524 {wid=962 normal=(0.647487 0.021701 -0.761767)}
Corner 123 525 {wid=771 normal=(-0.991112 0.125768 0.0433507)}
Corner 58 525 {wid=141 normal=(-0.981522 0.182192 0.0584899)}
Corner 280 525 {wid=336 normal=(-0.991112 0.125768 0.0433507)}
Corner 123 526 {wid=774 normal=(0.599243 -0.625457 0.499711)}
Corner 281 526 {wid=772 normal=(0.265128 -0.943324 0.199618)}
Corner 347 526 {wid=776 normal=(0.652241 -0.756102 -0.0537736)}
Corner 123 527 {wid=775 normal=(-0.317975 0.792042 0.521115)}
Corner 280 527 {wid=777 normal=(-0.639075 0.768756 -0.0244405)}
Corner 282 527 {wid=773 normal=(-0.489975 0.744847 0.452911)}
Corner 281 528 {wid=780 normal=(-0.711218 -0.647359 0.274035)}
Corner 349 528 {wid=778 normal=(-0.883645 -0.42114 0.204483)}
Corner 398 528 {wid=782 normal=(-0.961738 -0.272502 -0.0283278)}
Corner 281 529 {wid=781 normal=(0.43054 0.198616 0.880447)}
Corner 123 529 {wid=783 normal=(0.392182 0.238146 0.888527)}
Corner 282 529 {wid=779 normal=(0.43039 0.199548 0.88031)}
Corner 102 530 {wid=786 normal=(1.493e-006 1 1.40857e-005)}
Corner 283 530 {wid=784 normal=(2.84446e-006 1 1.36241e-005)}
Corner 271 530 {wid=788 normal=(-2.05145e-006 1 1.57985e-005)}
Corner 447 531 {wid=787 normal=(-0.115738 -0.983081 -0.141976)}
Corner 140 531 {wid=789 normal=(0.115738 -0.983081 -0.141976)}
Corner 283 531 {wid=785 normal=(-0.0422059 -0.99194 -0.119473)}
Corner 140 532 {wid=791 normal=(-1.493e-006 1 1.40857e-005)}
Corner 284 532 {wid=790 normal=(2.05145e-006 1 1.57985e-005)}
Corner 283 532 {wid=793 normal=(2.84446e-006 1 1.36241e-005)}
Corner 476 533 {wid=792 normal=(0.0219785 -0.962802 -0.269314)}
Corner 254 533 {wid=701 normal=(0.0969369 -0.994701 0.0342567)}
Corner 284 533 {wid=703 normal=(0.00114083 -0.985566 -0.16929)}
Corner 316 534 {wid=877 normal=(-0.347808 -0.759033 0.550364)}
Corner 384 535 {wid=1066 normal=(-0.212633 0.429771 0.877545)}
Corner 285 535 {wid=794 normal=(-0.12469 0.675132 0.727083)}
Corner 286 536 {wid=795 normal=(0.538335 -0.409545 -0.736524)}
Corner 513 537 {wid=427 normal=(0.765972 -0.625534 0.148303)}
Corner 22 537 {wid=53 normal=(0.633129 0.771813 0.0587491)}
Corner 286 537 {wid=796 normal=(0.981119 0.0872253 -0.172617)}
Corner 151 538 {wid=407 normal=(-0.857805 7.30093e-006 -0.513975)}
Corner 287 538 {wid=797 normal=(0.102579 1.40492e-005 -0.994725)}
Corner 433 538 {wid=550 normal=(-0.342231 1.32704e-005 -0.939615)}
Corner 151 539 {wid=241 normal=(-0.852678 7.38484e-006 -0.522438)}
Corner 380 539 {wid=513 normal=(-0.518116 1.20806e-005 -0.85531)}
Corner 287 539 {wid=798 normal=(0.0409818 1.41132e-005 -0.99916)}
Corner 10 540 {wid=49 normal=(-0.683589 0.238787 0.6897)}
Corner 288 540 {wid=799 normal=(-0.69883 -0.707966 -0.102083)}
Corner 236 540 {wid=800 normal=(-0.90941 -0.340812 -0.238371)}
Corner 485 541 {wid=1303 normal=(-0.534979 0.834261 0.133437)}
Corner 288 541 {wid=799 normal=(-0.69883 -0.707966 -0.102083)}
Corner 68 544 {wid=594 normal=(-0.350995 -0.854014 -0.384008)}
Corner 400 544 {wid=802 normal=(-0.302598 -0.835834 -0.458057)}
Corner 223 544 {wid=592 normal=(-0.472212 -0.872108 -0.128232)}
Corner 68 545 {wid=190 normal=(-0.483984 -0.841711 -0.239337)}
Corner 189 545 {wid=499 normal=(0.0839995 -0.832451 -0.547694)}
Corner 400 545 {wid=803 normal=(-0.633127 -0.774 -0.00858711)}
Corner 121 546 {wid=197 normal=(-0.142646 -1.39781e-005 0.989774)}
Corner 291 546 {wid=804 normal=(-0.922822 -5.45893e-006 0.385228)}
Corner 196 546 {wid=198 normal=(-0.687546 -1.02436e-005 0.726141)}
Corner 333 547 {wid=245 normal=(-0.231565 -0.428902 0.873167)}
Corner 376 547 {wid=330 normal=(-0.466977 -0.0365867 0.883513)}
Corner 292 547 {wid=805 normal=(-0.899131 0.0092287 0.437583)}
Corner 291 548 {wid=808 normal=(-0.179608 -0.983238 0.0313665)}
Corner 292 548 {wid=806 normal=(-0.0136195 -0.983052 0.182819)}
Corner 141 548 {wid=810 normal=(-0.233455 -0.972363 0.00286952)}
Corner 291 549 {wid=809 normal=(2.08877e-006 1 1.74426e-005)}
Corner 121 549 {wid=811 normal=(-4.6294e-006 1 1.21104e-005)}
Corner 292 549 {wid=807 normal=(1.92502e-006 1 1.58114e-005)}
Corner 366 550 {wid=814 normal=(-0.0644327 -0.981412 -0.180773)}
Corner 325 550 {wid=812 normal=(-0.416397 -0.729375 0.542794)}
Corner 234 550 {wid=816 normal=(-0.625788 -0.664936 0.407738)}
Corner 263 551 {wid=815 normal=(0.639075 0.768756 -0.0244405)}
Corner 124 551 {wid=817 normal=(0.537594 0.818395 0.203031)}
Corner 293 551 {wid=813 normal=(0.317975 0.792042 0.521115)}
Corner 137 552 {wid=819 normal=(-0.7761 -0.242131 0.582272)}
Corner 308 552 {wid=856 normal=(-0.491351 -0.317371 0.811079)}
Corner 158 552 {wid=429 normal=(-0.433532 -0.517833 0.737496)}
Corner 137 553 {wid=372 normal=(0.537093 -0.226403 0.812572)}
Corner 95 553 {wid=252 normal=(0.686827 0.296644 -0.663529)}
Corner 294 553 {wid=818 normal=(0.578853 0.0194597 -0.815199)}
Corner 491 554 {wid=1317 normal=(-0.34401 -0.102476 0.933358)}
Corner 295 554 {wid=820 normal=(-0.997572 -0.0654858 -0.0237164)}
Corner 493 554 {wid=1321 normal=(-0.825323 -0.052926 0.562174)}
Corner 491 555 {wid=1318 normal=(-0.381745 -0.0985827 0.918994)}
Corner 303 555 {wid=157 normal=(-0.996647 -0.0664181 0.0477801)}
Corner 295 555 {wid=821 normal=(-0.997054 -0.0676643 0.0361118)}
Corner 296 556 {wid=822 normal=(0.933305 0.342152 0.108973)}
Corner 286 557 {wid=426 normal=(0.677438 0.517632 0.522623)}
Corner 296 557 {wid=822 normal=(0.933305 0.342152 0.108973)}
Corner 468 558 {wid=825 normal=(0.0157145 -0.999852 -0.00695027)}
Corner 297 558 {wid=823 normal=(0.0157145 -0.999852 -0.00695027)}
Corner 119 558 {wid=826 normal=(0.0157145 -0.999852 -0.00695027)}
Corner 468 559 {wid=1269 normal=(-0.710195 -0.657447 0.251767)}
Corner 120 559 {wid=325 normal=(-0.729423 0.184251 -0.658782)}
Corner 297 559 {wid=824 normal=(-0.710195 -0.657447 0.251767)}
Corner 186 560 {wid=491 normal=(-0.31112 -0.619302 -0.720881)}
Corner 298 560 {wid=827 normal=(-0.32368 -0.633194 -0.703062)}
Corner 42 560 {wid=494 normal=(-0.32368 -0.633194 -0.703062)}
Corner 186 561 {wid=829 normal=(-0.175924 -0.953989 -0.242808)}
Corner 455 561 {wid=830 normal=(-0.343435 -0.934565 -0.0929585)}
Corner 298 561 {wid=828 normal=(-0.24585 -0.951927 -0.182738)}
Corner 89 562 {wid=174 normal=(-0.769754 -0.211784 0.602185)}
Corner 299 562 {wid=831 normal=(-0.21561 -0.352229 -0.91074)}
Corner 387 562 {wid=1074 normal=(0.0150934 0.0262485 -0.999542)}
Corner 430 563 {wid=150 normal=(-0.277194 0.756013 -0.592965)}
Corner 69 563 {wid=705 normal=(-0.284235 0.762055 -0.581793)}
Corner 299 563 {wid=832 normal=(-0.0967323 0.979323 -0.177677)}
Corner 44 564 {wid=103 normal=(-0.758315 -0.224429 -0.612039)}
Corner 300 564 {wid=833 normal=(0.407364 -0.12871 -0.904151)}
Corner 67 564 {wid=163 normal=(-0.0655602 -0.158371 -0.985201)}
Corner 44 565 {wid=170 normal=(-0.749024 -0.226827 -0.622504)}
Corner 163 565 {wid=437 normal=(-0.110531 -0.132589 -0.984989)}
Corner 300 565 {wid=834 normal=(0.414419 -0.129161 -0.900874)}
Corner 50 566 {wid=117 normal=(-0.638923 -0.0807716 0.765018)}
Corner 301 566 {wid=835 normal=(0.699632 -0.208878 0.683289)}
Corner 153 566 {wid=300 normal=(0.162149 -0.146138 0.975885)}
Corner 50 567 {wid=297 normal=(-0.577613 -0.0155202 0.816162)}
Corner 112 567 {wid=302 normal=(0.194745 -0.474158 0.858632)}
Corner 301 567 {wid=836 normal=(0.715968 0.0696846 0.694645)}
Corner 100 568 {wid=838 normal=(-0.157891 0.938295 0.30769)}
Corner 302 568 {wid=837 normal=(-0.156341 0.93871 0.307215)}
Corner 481 568 {wid=839 normal=(-0.926478 0.0317794 0.375004)}
Corner 100 569 {wid=838 normal=(-0.157891 0.938295 0.30769)}
Corner 84 569 {wid=840 normal=(0.593272 0.804172 -0.0365475)}
Corner 302 569 {wid=837 normal=(-0.156341 0.93871 0.307215)}
Corner 63 570 {wid=158 normal=(-0.7581 -0.608838 0.23367)}
Corner 303 570 {wid=841 normal=(-0.52363 -0.834479 0.171631)}
Corner 184 570 {wid=488 normal=(-0.52363 -0.834479 0.171631)}
Corner 63 571 {wid=843 normal=(-0.585757 -0.800985 -0.12374)}
Corner 187 571 {wid=844 normal=(-0.451581 -0.77522 -0.441711)}
Corner 303 571 {wid=842 normal=(-0.585757 -0.800985 -0.12374)}
Corner 178 572 {wid=846 normal=(-0.00041185 -0.0515133 0.998672)}
Corner 304 572 {wid=845 normal=(0 -0.051026 0.998697)}
Corner 437 572 {wid=848 normal=(0.00041185 -0.0515133 0.998672)}
Corner 178 573 {wid=847 normal=(-0.80458 0.593225 0.0271322)}
Corner 451 573 {wid=747 normal=(-0.823243 0.566297 0.0397297)}
Corner 304 573 {wid=470 normal=(-0.820134 0.570936 0.037586)}
Corner 235 574 {wid=632 normal=(0.93671 0.042744 0.347486)}
Corner 305 574 {wid=849 normal=(0.926878 0.200156 0.317544)}
Corner 276 574 {wid=755 normal=(0.983031 0.12505 0.134214)}
Corner 461 575 {wid=851 normal=(-0.0157145 -0.999852 -0.00695027)}
Corner 103 575 {wid=852 normal=(-0.0157145 -0.999852 -0.00695027)}
Corner 305 575 {wid=850 normal=(-0.0157145 -0.999852 -0.00695027)}
Corner 156 576 {wid=422 normal=(-0.513976 -0.0141403 -0.857688)}
Corner 309 576 {wid=490 normal=(0.133989 -0.267693 0.954142)}
Corner 156 577 {wid=422 normal=(-0.513976 -0.0141403 -0.857688)}
Corner 294 578 {wid=424 normal=(-0.430439 -0.374061 0.821463)}
Corner 307 578 {wid=854 normal=(-0.297729 -0.393513 0.869773)}
Corner 185 578 {wid=425 normal=(0 -0.544973 0.838454)}
Corner 294 579 {wid=818 normal=(0.578853 0.0194597 -0.815199)}
Corner 486 579 {wid=1305 normal=(-0.419169 0.132876 -0.898132)}
Corner 307 579 {wid=855 normal=(0.262798 -0.0164802 -0.96471)}
Corner 294 580 {wid=818 normal=(0.578853 0.0194597 -0.815199)}
Corner 308 580 {wid=857 normal=(0.667057 -0.0582146 -0.742729)}
Corner 137 580 {wid=372 normal=(0.537093 -0.226403 0.812572)}
Corner 294 581 {wid=424 normal=(-0.430439 -0.374061 0.821463)}
Corner 185 581 {wid=425 normal=(0 -0.544973 0.838454)}
Corner 308 581 {wid=856 normal=(-0.491351 -0.317371 0.811079)}
Corner 185 582 {wid=489 normal=(-3.57628e-007 -0.610405 -0.792089)}
Corner 457 582 {wid=858 normal=(-0.794626 -0.589094 -0.14676)}
Corner 185 583 {wid=425 normal=(0 -0.544973 0.838454)}
Corner 156 583 {wid=423 normal=(0.27638 -0.639914 0.717025)}
Corner 309 583 {wid=859 normal=(0.78527 -0.252403 0.56537)}
Corner 192 584 {wid=862 normal=(0.61907 0.726321 -0.298682)}
Corner 310 584 {wid=860 normal=(0.872592 0.360974 -0.329061)}
Corner 99 584 {wid=864 normal=(0.483785 0.84392 0.231844)}
Corner 460 585 {wid=863 normal=(0.400346 -0.909307 -0.113507)}
Corner 407 585 {wid=865 normal=(0.506678 -0.84641 0.163914)}
Corner 327 585 {wid=861 normal=(0.732597 -0.679972 0.0306614)}
Corner 55 586 {wid=132 normal=(0.353376 -0.327211 -0.876389)}
Corner 311 586 {wid=866 normal=(0.103675 0.746416 -0.657354)}
Corner 9 586 {wid=9 normal=(-0.203103 0.248811 -0.947017)}
Corner 55 587 {wid=659 normal=(-0.383541 -0.342221 -0.857777)}
Corner 312 587 {wid=660 normal=(-0.63609 -0.0819 -0.767256)}
Corner 311 587 {wid=867 normal=(-0.57151 0.433009 -0.69705)}
Corner 208 588 {wid=404 normal=(-0.935042 -0.152174 -0.320216)}
Corner 312 588 {wid=868 normal=(-0.93504 -0.152174 -0.320223)}
Corner 243 588 {wid=405 normal=(-0.935041 -0.152173 -0.320221)}
Corner 208 589 {wid=869 normal=(-0.902467 0.343409 -0.260044)}
Corner 311 589 {wid=867 normal=(-0.57151 0.433009 -0.69705)}
Corner 312 589 {wid=660 normal=(-0.63609 -0.0819 -0.767256)}
Corner 125 590 {wid=871 normal=(-0.225312 -0.349112 0.909591)}
Corner 313 590 {wid=604 normal=(0.0492503 0.0101562 -0.998735)}
Corner 511 590 {wid=603 normal=(-0.210646 -0.561168 -0.800449)}
Corner 314 591 {wid=144 normal=(-0.201106 0.336165 0.920081)}
Corner 226 591 {wid=140 normal=(-0.580706 0.285838 0.762284)}
Corner 313 591 {wid=870 normal=(-0.580706 0.285838 0.762284)}
Corner 125 592 {wid=873 normal=(0.617653 -0.780622 0.0955695)}
Corner 314 592 {wid=872 normal=(0.672534 -0.615184 0.411396)}
Corner 313 592 {wid=875 normal=(0.584368 -0.811434 -0.00938159)}
Corner 125 593 {wid=874 normal=(0.998142 0.0581908 0.0180403)}
Corner 237 593 {wid=634 normal=(0.988649 -0.149506 -0.0148549)}
Corner 454 594 {wid=1235 normal=(-0.273945 -0.383981 0.881766)}
Corner 320 594 {wid=885 normal=(0.582796 -0.404103 0.705018)}
Corner 454 595 {wid=1235 normal=(-0.273945 -0.383981 0.881766)}
Corner 285 596 {wid=794 normal=(-0.12469 0.675132 0.727083)}
Corner 316 596 {wid=877 normal=(-0.347808 -0.759033 0.550364)}
Corner 384 596 {wid=1066 normal=(-0.212633 0.429771 0.877545)}
Corner 285 597 {wid=879 normal=(-0.124689 0.675133 0.727082)}
Corner 217 597 {wid=880 normal=(-0.965451 0.188576 0.179843)}
Corner 316 597 {wid=878 normal=(-0.347809 -0.759032 0.550363)}
Corner 217 598 {wid=578 normal=(-0.96545 0.188575 0.179844)}
Corner 217 599 {wid=578 normal=(-0.96545 0.188575 0.179844)}
Corner 95 602 {wid=884 normal=(-0.0858566 -0.837552 -0.53957)}
Corner 465 602 {wid=446 normal=(-0.0248163 -0.920525 -0.389895)}
Corner 168 602 {wid=444 normal=(0.015772 -0.822228 -0.56894)}
Corner 95 603 {wid=252 normal=(0.686827 0.296644 -0.663529)}
Corner 320 604 {wid=885 normal=(0.582796 -0.404103 0.705018)}
Corner 185 605 {wid=489 normal=(-3.57628e-007 -0.610405 -0.792089)}
Corner 320 605 {wid=885 normal=(0.582796 -0.404103 0.705018)}
Corner 481 606 {wid=839 normal=(-0.926478 0.0317794 0.375004)}
Corner 321 606 {wid=886 normal=(-0.926478 0.0317794 0.375004)}
Corner 100 606 {wid=838 normal=(-0.157891 0.938295 0.30769)}
Corner 481 607 {wid=888 normal=(0 -1 0)}
Corner 29 607 {wid=889 normal=(0 -1 0)}
Corner 321 607 {wid=887 normal=(0 -1 0)}
Corner 323 608 {wid=312 normal=(0.935015 -0.152194 -0.320288)}
Corner 322 608 {wid=890 normal=(0.935023 -0.152186 -0.320266)}
Corner 114 608 {wid=310 normal=(0.935042 -0.152173 -0.320219)}
Corner 181 609 {wid=892 normal=(0.684877 0.720019 0.111873)}
Corner 265 609 {wid=893 normal=(0.768737 0.0289046 0.638911)}
Corner 322 609 {wid=891 normal=(0.682568 0.723341 0.104306)}
Corner 181 610 {wid=896 normal=(0.964105 -0.00323172 -0.265502)}
Corner 323 610 {wid=894 normal=(0.93832 0.0118371 -0.345564)}
Corner 268 610 {wid=897 normal=(0.899963 -0.0375275 -0.434348)}
Corner 181 611 {wid=892 normal=(0.684877 0.720019 0.111873)}
Corner 322 611 {wid=891 normal=(0.682568 0.723341 0.104306)}
Corner 323 611 {wid=895 normal=(0.541818 0.784052 -0.302812)}
Corner 66 612 {wid=161 normal=(0.353673 -0.100818 0.92992)}
Corner 324 612 {wid=898 normal=(0.987937 -0.0634772 -0.141247)}
Corner 164 612 {wid=162 normal=(0.614169 -0.0831513 0.784781)}
Corner 66 613 {wid=250 normal=(0.331068 -0.0360768 0.942917)}
Corner 94 613 {wid=249 normal=(0.522959 -0.815795 -0.246966)}
Corner 324 613 {wid=899 normal=(0.985658 0.150248 -0.0768383)}
Corner 419 614 {wid=902 normal=(0.13847 0.985552 -0.097537)}
Corner 418 614 {wid=900 normal=(0.378274 0.919649 0.105614)}
Corner 450 614 {wid=904 normal=(0.366535 0.921596 0.127722)}
Corner 293 615 {wid=903 normal=(-0.473595 -0.0668016 0.878205)}
Corner 234 615 {wid=905 normal=(-0.392182 0.238146 0.888527)}
Corner 325 615 {wid=901 normal=(-0.43054 0.198616 0.880447)}
Corner 505 616 {wid=908 normal=(0.608669 -0.658414 -0.442734)}
Corner 326 616 {wid=906 normal=(0.746449 -0.485579 0.455003)}
Corner 15 616 {wid=910 normal=(0.905586 -0.108628 0.410016)}
Corner 90 617 {wid=909 normal=(0.585757 -0.800985 -0.12374)}
Corner 189 617 {wid=911 normal=(0.451581 -0.77522 -0.441711)}
Corner 326 617 {wid=907 normal=(0.585757 -0.800985 -0.12374)}
Corner 406 618 {wid=914 normal=(-0.482148 -0.0425754 -0.875055)}
Corner 327 618 {wid=912 normal=(-0.0970998 0.255476 -0.961927)}
Corner 407 618 {wid=916 normal=(0.108579 0.14612 -0.98329)}
Corner 310 619 {wid=915 normal=(-0.0477115 0.127817 0.990649)}
Corner 460 619 {wid=917 normal=(-0.12264 0.298573 0.946474)}
Corner 327 619 {wid=913 normal=(-0.191925 0.150621 0.969782)}
Corner 25 620 {wid=153 normal=(0.0189398 0.74245 0.669634)}
Corner 328 620 {wid=718 normal=(0.0395833 0.744261 0.666715)}
Corner 24 620 {wid=152 normal=(-0.957923 0.0920842 0.27185)}
Corner 25 621 {wid=153 normal=(0.0189398 0.74245 0.669634)}
Corner 501 621 {wid=1334 normal=(0.537346 0.705587 0.46196)}
Corner 328 621 {wid=718 normal=(0.0395833 0.744261 0.666715)}
Corner 7 624 {wid=7 normal=(-0.824241 0.178461 -0.537381)}
Corner 330 624 {wid=919 normal=(-0.0988593 0.0704348 0.992606)}
Corner 6 624 {wid=6 normal=(-0.865239 -0.0778686 0.495276)}
Corner 7 625 {wid=280 normal=(-0.836927 0.0674514 -0.543142)}
Corner 8 625 {wid=289 normal=(-0.0189398 0.74245 0.669634)}
Corner 330 625 {wid=920 normal=(-0.0395833 0.744261 0.666715)}
Corner 35 626 {wid=71 normal=(0.373135 0.0229888 0.927492)}
Corner 331 626 {wid=921 normal=(0.7667 -0.171988 -0.61854)}
Corner 439 626 {wid=69 normal=(0.662237 -0.194709 -0.723554)}
Corner 35 627 {wid=343 normal=(0.849738 0.18401 0.494051)}
Corner 237 627 {wid=634 normal=(0.988649 -0.149506 -0.0148549)}
Corner 331 627 {wid=922 normal=(0.732505 0.0983596 -0.673618)}
Corner 121 630 {wid=925 normal=(0.00688992 -0.996321 0.0854212)}
Corner 333 630 {wid=924 normal=(-0.0468879 -0.993825 0.100561)}
Corner 292 630 {wid=926 normal=(-0.231854 -0.957202 0.173227)}
Corner 121 631 {wid=925 normal=(0.00688992 -0.996321 0.0854212)}
Corner 173 631 {wid=927 normal=(0.231854 -0.957202 0.173227)}
Corner 333 631 {wid=924 normal=(-0.0468879 -0.993825 0.100561)}
Corner 19 632 {wid=581 normal=(-0.00198819 -0.392589 -0.919711)}
Corner 334 632 {wid=928 normal=(-0.475024 -0.827081 0.300481)}
Corner 258 632 {wid=580 normal=(0.311888 -0.943783 0.109541)}
Corner 19 633 {wid=581 normal=(-0.00198819 -0.392589 -0.919711)}
Corner 218 633 {wid=929 normal=(-0.175241 0.977197 -0.119909)}
Corner 334 633 {wid=928 normal=(-0.475024 -0.827081 0.300481)}
Corner 278 634 {wid=932 normal=(-0.275376 0.256107 0.926594)}
Corner 335 634 {wid=930 normal=(-0.313275 0.264206 0.91217)}
Corner 277 634 {wid=934 normal=(-0.135501 0.407122 0.903267)}
Corner 278 635 {wid=933 normal=(0.529116 -0.573087 -0.625786)}
Corner 353 635 {wid=935 normal=(0.482369 -0.605988 -0.632534)}
Corner 335 635 {wid=931 normal=(0.482369 -0.605988 -0.632534)}
Corner 64 636 {wid=156 normal=(-0.482358 -0.205572 -0.851511)}
Corner 336 636 {wid=936 normal=(-0.863052 -0.0451684 0.503092)}
Corner 1 636 {wid=155 normal=(-0.992525 -0.117469 0.0330816)}
Corner 64 637 {wid=342 normal=(-0.574638 0.117965 -0.809862)}
Corner 466 637 {wid=1263 normal=(-0.646524 0.194492 0.737686)}
Corner 336 637 {wid=937 normal=(-0.849738 0.184009 0.494051)}
Corner 84 638 {wid=840 normal=(0.593272 0.804172 -0.0365475)}
Corner 337 638 {wid=938 normal=(0.64223 0.7633 -0.0701029)}
Corner 29 638 {wid=939 normal=(0.93337 0.0302482 -0.357639)}
Corner 84 639 {wid=840 normal=(0.593272 0.804172 -0.0365475)}
Corner 100 639 {wid=838 normal=(-0.157891 0.938295 0.30769)}
Corner 337 639 {wid=938 normal=(0.64223 0.7633 -0.0701029)}
Corner 29 640 {wid=939 normal=(0.93337 0.0302482 -0.357639)}
Corner 338 640 {wid=940 normal=(0.93337 0.0302482 -0.357639)}
Corner 84 640 {wid=840 normal=(0.593272 0.804172 -0.0365475)}
Corner 29 641 {wid=889 normal=(0 -1 0)}
Corner 481 641 {wid=888 normal=(0 -1 0)}
Corner 338 641 {wid=941 normal=(0 -1 0)}
Corner 250 643 {wid=692 normal=(0.244695 -0.097176 -0.964718)}
Corner 144 644 {wid=540 normal=(0 0.702883 -0.711305)}
Corner 340 644 {wid=255 normal=(-0.0184147 0.468522 -0.88326)}
Corner 232 644 {wid=253 normal=(0.00520121 0.69086 -0.72297)}
Corner 144 645 {wid=540 normal=(0 0.702883 -0.711305)}
Corner 177 645 {wid=539 normal=(0 0.941437 -0.337188)}
Corner 340 645 {wid=255 normal=(-0.0184147 0.468522 -0.88326)}
Corner 314 646 {wid=943 normal=(0.757133 0.280682 0.589889)}
Corner 342 646 {wid=944 normal=(0.441329 0.371835 0.816681)}
Corner 314 647 {wid=943 normal=(0.757133 0.280682 0.589889)}
Corner 125 647 {wid=874 normal=(0.998142 0.0581908 0.0180403)}
Corner 204 648 {wid=344 normal=(0.27705 0.461878 0.842563)}
Corner 342 648 {wid=945 normal=(0.821176 0.135048 0.554466)}
Corner 204 649 {wid=947 normal=(-0.0952917 0.0707151 0.992934)}
Corner 215 649 {wid=948 normal=(-0.050699 0.258793 0.964601)}
Corner 342 649 {wid=946 normal=(-0.0875934 0.128379 0.987849)}
Corner 448 650 {wid=950 normal=(-0.710938 0.608896 -0.35187)}
Corner 343 650 {wid=569 normal=(0.250449 -0.594698 -0.763944)}
Corner 345 650 {wid=567 normal=(-0.960975 0.122341 -0.248112)}
Corner 448 651 {wid=951 normal=(0.473082 0.825278 -0.308399)}
Corner 216 651 {wid=952 normal=(0.8433 0.506676 -0.179235)}
Corner 343 651 {wid=949 normal=(0.335425 0.0428716 -0.941091)}
Corner 216 652 {wid=954 normal=(0.901492 -0.432667 -0.0105772)}
Corner 344 652 {wid=571 normal=(0.385009 -0.918713 -0.0879471)}
Corner 343 652 {wid=569 normal=(0.250449 -0.594698 -0.763944)}
Corner 216 653 {wid=955 normal=(0.323916 -0.74131 0.587825)}
Corner 215 653 {wid=956 normal=(0.323916 -0.74131 0.587825)}
Corner 344 653 {wid=953 normal=(0.452853 -0.790504 0.412344)}
Corner 215 654 {wid=959 normal=(-0.430336 -0.370067 0.823323)}
Corner 345 654 {wid=957 normal=(-0.804729 -0.141515 0.576529)}
Corner 344 654 {wid=960 normal=(-0.0177075 -0.74342 0.668591)}
Corner 215 655 {wid=566 normal=(-0.782873 0.498596 0.372174)}
Corner 448 655 {wid=1217 normal=(-0.935025 0.205428 0.289011)}
Corner 345 655 {wid=958 normal=(-0.929926 0.275767 0.243292)}
Corner 440 656 {wid=1199 normal=(0.0639027 -0.274665 0.959414)}
Corner 237 658 {wid=634 normal=(0.988649 -0.149506 -0.0148549)}
Corner 347 658 {wid=962 normal=(0.647487 0.021701 -0.761767)}
Corner 331 658 {wid=922 normal=(0.732505 0.0983596 -0.673618)}
Corner 237 659 {wid=635 normal=(0.544284 -0.838716 -0.0176263)}
Corner 123 659 {wid=669 normal=(0.201138 -0.781966 -0.589977)}
Corner 347 659 {wid=963 normal=(0.484023 -0.843071 -0.234422)}
Corner 123 660 {wid=966 normal=(-0.182516 0.0816396 -0.979808)}
Corner 348 660 {wid=965 normal=(-0.108579 0.14612 -0.98329)}
Corner 246 660 {wid=967 normal=(0.957973 0.286687 -0.00992233)}
Corner 123 661 {wid=669 normal=(0.201138 -0.781966 -0.589977)}
Corner 237 661 {wid=635 normal=(0.544284 -0.838716 -0.0176263)}
Corner 348 661 {wid=964 normal=(0.316301 -0.702564 -0.637462)}
Corner 282 662 {wid=779 normal=(0.43039 0.199548 0.88031)}
Corner 349 662 {wid=968 normal=(0.461835 -0.103252 0.880935)}
Corner 281 662 {wid=781 normal=(0.43054 0.198616 0.880447)}
Corner 446 663 {wid=970 normal=(-0.188212 0.981655 0.0304768)}
Corner 398 663 {wid=971 normal=(-0.366535 0.921596 0.127722)}
Corner 349 663 {wid=969 normal=(-0.378274 0.919649 0.105614)}
Corner 130 664 {wid=973 normal=(0.161809 0.0720117 0.984192)}
Corner 350 664 {wid=46 normal=(-0.47972 0.0996945 0.87174)}
Corner 116 664 {wid=317 normal=(0.662786 0.0799745 0.744525)}
Corner 130 665 {wid=551 normal=(-0.00712216 -0.999973 0.00188856)}
Corner 51 665 {wid=552 normal=(-4.99408e-006 -1 -1.61264e-005)}
Corner 350 665 {wid=972 normal=(-0.0287352 -0.999134 0.0301066)}
Corner 119 666 {wid=975 normal=(0.860201 0.00831142 -0.509888)}
Corner 351 666 {wid=498 normal=(0.860201 0.00831142 -0.509888)}
Corner 261 666 {wid=717 normal=(0.876333 0.118797 -0.466828)}
Corner 119 667 {wid=826 normal=(0.0157145 -0.999852 -0.00695027)}
Corner 297 667 {wid=823 normal=(0.0157145 -0.999852 -0.00695027)}
Corner 351 667 {wid=974 normal=(0.0157145 -0.999852 -0.00695027)}
Corner 117 668 {wid=319 normal=(-0.213802 -0.0586599 0.975114)}
Corner 352 668 {wid=976 normal=(-0.384018 -0.8482 0.364811)}
Corner 117 669 {wid=978 normal=(0.476997 -0.213336 0.85262)}
Corner 401 669 {wid=979 normal=(-0.374561 -0.162978 0.912766)}
Corner 352 669 {wid=977 normal=(-0.513577 -0.170239 0.840986)}
Corner 356 670 {wid=981 normal=(-0.0673561 0.0188643 -0.997551)}
Corner 353 670 {wid=980 normal=(-0.150137 0.0580168 -0.986961)}
Corner 278 670 {wid=982 normal=(-0.0492503 0.0101562 -0.998735)}
Corner 356 671 {wid=981 normal=(-0.0673561 0.0188643 -0.997551)}
Corner 354 671 {wid=983 normal=(-0.666753 0.477185 -0.572482)}
Corner 353 671 {wid=980 normal=(-0.150137 0.0580168 -0.986961)}
Corner 277 672 {wid=986 normal=(-0.159931 0.984098 0.077287)}
Corner 355 672 {wid=984 normal=(-0.363126 0.886933 -0.285464)}
Corner 356 672 {wid=987 normal=(-0.485233 0.586755 -0.64828)}
Corner 277 673 {wid=934 normal=(-0.135501 0.407122 0.903267)}
Corner 335 673 {wid=930 normal=(-0.313275 0.264206 0.91217)}
Corner 355 673 {wid=985 normal=(-0.452073 0.543151 0.707543)}
Corner 354 674 {wid=990 normal=(-0.641788 0.670921 0.371447)}
Corner 355 674 {wid=988 normal=(-0.356261 -0.00658997 0.934363)}
Corner 335 674 {wid=992 normal=(-0.356261 -0.00658997 0.934363)}
Corner 354 675 {wid=991 normal=(-0.971326 -0.231543 -0.0539855)}
Corner 356 675 {wid=993 normal=(-0.529653 -0.826042 -0.192671)}
Corner 355 675 {wid=989 normal=(-0.592508 -0.68821 0.418689)}
Corner 191 676 {wid=995 normal=(0.385686 -0.65863 0.646106)}
Corner 356 676 {wid=981 normal=(-0.0673561 0.0188643 -0.997551)}
Corner 278 676 {wid=982 normal=(-0.0492503 0.0101562 -0.998735)}
Corner 191 677 {wid=504 normal=(0.85741 0.17342 -0.484535)}
Corner 3 677 {wid=267 normal=(0.951888 0.223843 0.209292)}
Corner 356 677 {wid=994 normal=(0.95293 0.267271 0.143147)}
Corner 462 678 {wid=998 normal=(-0.806095 0.370098 -0.461778)}
Corner 357 678 {wid=996 normal=(-0.765716 0.468038 -0.441157)}
Corner 192 678 {wid=1000 normal=(-0.837084 0.267847 -0.47702)}
Corner 462 679 {wid=999 normal=(-0.419061 0.897434 0.137839)}
Corner 249 679 {wid=1001 normal=(0.758185 0.649619 0.0561323)}
Corner 357 679 {wid=997 normal=(0.356774 0.93393 0.0220666)}
Corner 103 680 {wid=852 normal=(-0.0157145 -0.999852 -0.00695027)}
Corner 358 680 {wid=1003 normal=(-0.0157145 -0.999852 -0.00695027)}
Corner 305 680 {wid=850 normal=(-0.0157145 -0.999852 -0.00695027)}
Corner 103 681 {wid=276 normal=(-0.860201 0.00831142 -0.509888)}
Corner 7 681 {wid=280 normal=(-0.836927 0.0674514 -0.543142)}
Corner 358 681 {wid=1002 normal=(-0.860201 0.00831142 -0.509888)}
Corner 213 682 {wid=1006 normal=(0.860032 0.255452 -0.441689)}
Corner 359 682 {wid=1004 normal=(0.71896 0.597288 -0.355449)}
Corner 231 682 {wid=1008 normal=(0.710938 0.608896 -0.35187)}
Corner 213 683 {wid=1007 normal=(0.801792 0.35065 0.483916)}
Corner 467 683 {wid=1009 normal=(0.801792 0.35065 0.483916)}
Corner 359 683 {wid=1005 normal=(0.782873 0.498596 0.372173)}
Corner 231 684 {wid=565 normal=(-0.901492 -0.432667 -0.0105772)}
Corner 240 684 {wid=561 normal=(-0.886219 -0.463015 -0.0152685)}
Corner 231 685 {wid=1008 normal=(0.710938 0.608896 -0.35187)}
Corner 359 685 {wid=1004 normal=(0.71896 0.597288 -0.355449)}
Corner 360 685 {wid=1010 normal=(0.960975 0.122342 -0.248112)}
Corner 226 686 {wid=1012 normal=(0.275376 0.256107 0.926594)}
Corner 361 686 {wid=1011 normal=(0.28492 0.368305 0.88497)}
Corner 313 686 {wid=1013 normal=(0.275376 0.256107 0.926594)}
Corner 226 687 {wid=1012 normal=(0.275376 0.256107 0.926594)}
Corner 369 687 {wid=1014 normal=(0.400795 0.53787 0.74166)}
Corner 361 687 {wid=1011 normal=(0.28492 0.368305 0.88497)}
Corner 191 688 {wid=1017 normal=(0.016731 0.394151 0.918893)}
Corner 362 688 {wid=1015 normal=(-0.195269 0.281412 0.939509)}
Corner 462 688 {wid=1018 normal=(-0.251568 0.201604 0.94661)}
Corner 191 689 {wid=503 normal=(-0.40538 -0.633565 0.658985)}
Corner 192 689 {wid=3 normal=(0.159692 -0.670057 -0.724929)}
Corner 362 689 {wid=1016 normal=(0.0238279 -0.515418 0.856607)}
Corner 81 690 {wid=546 normal=(0.936621 -0.000655751 0.350343)}
Corner 363 690 {wid=1019 normal=(0.936621 -0.000655751 0.350343)}
Corner 207 690 {wid=542 normal=(0.926478 0.0317794 0.375004)}
Corner 81 691 {wid=1021 normal=(0.729441 0.585339 0.35397)}
Corner 106 691 {wid=1022 normal=(-0.289148 0.946954 0.140253)}
Corner 363 691 {wid=1020 normal=(0.729441 0.585339 0.35397)}
Corner 276 692 {wid=1025 normal=(-0.0957809 0.975151 0.199764)}
Corner 364 692 {wid=1023 normal=(-0.110105 0.978965 0.171769)}
Corner 383 692 {wid=1026 normal=(-0.231091 0.954947 0.186206)}
Corner 276 693 {wid=291 normal=(0.851956 0.284125 -0.439822)}
Corner 416 693 {wid=293 normal=(0.759173 -0.532975 -0.373624)}
Corner 364 693 {wid=1024 normal=(0.851956 0.284125 -0.439822)}
Corner 365 694 {wid=1027 normal=(0 0.999995 -0.00325906)}
Corner 485 694 {wid=1304 normal=(-0.534979 0.834261 0.133437)}
Corner 22 695 {wid=201 normal=(0.633129 0.771813 0.0587491)}
Corner 365 695 {wid=1027 normal=(0 0.999995 -0.00325906)}
Corner 263 696 {wid=339 normal=(0.610714 -0.106722 -0.784627)}
Corner 366 696 {wid=1028 normal=(0.259452 -0.51857 -0.81472)}
Corner 234 696 {wid=629 normal=(-0.935322 -0.188589 -0.299344)}
Corner 263 697 {wid=339 normal=(0.610714 -0.106722 -0.784627)}
Corner 293 697 {wid=1029 normal=(-0.405249 -0.873656 0.269255)}
Corner 366 697 {wid=1028 normal=(0.259452 -0.51857 -0.81472)}
Corner 313 698 {wid=604 normal=(0.0492503 0.0101562 -0.998735)}
Corner 367 698 {wid=1030 normal=(0.113809 -0.135757 -0.984184)}
Corner 369 698 {wid=1040 normal=(0.0900393 -0.0543206 -0.994456)}
Corner 313 699 {wid=1032 normal=(-0.53609 -0.824953 0.179052)}
Corner 361 699 {wid=1033 normal=(-0.835613 -0.480955 0.265393)}
Corner 367 699 {wid=1031 normal=(-0.841873 -0.506749 0.185623)}
Corner 361 700 {wid=1036 normal=(-0.903478 0.426576 -0.0419504)}
Corner 368 700 {wid=1034 normal=(-0.6071 0.792395 -0.0594916)}
Corner 367 700 {wid=1038 normal=(-0.89479 0.44402 0.0468745)}
Corner 361 701 {wid=1037 normal=(0.356261 -0.00658997 0.934363)}
Corner 369 701 {wid=1039 normal=(0.356261 -0.00658997 0.934363)}
Corner 368 701 {wid=1035 normal=(0.610154 0.759138 0.226765)}
Corner 511 702 {wid=598 normal=(-0.822572 -0.12787 -0.554098)}
Corner 369 702 {wid=1041 normal=(-0.95293 0.267271 0.143147)}
Corner 226 702 {wid=601 normal=(-0.943845 0.310279 0.113502)}
Corner 511 703 {wid=603 normal=(-0.210646 -0.561168 -0.800449)}
Corner 313 703 {wid=604 normal=(0.0492503 0.0101562 -0.998735)}
Corner 369 703 {wid=1040 normal=(0.0900393 -0.0543206 -0.994456)}
Corner 413 704 {wid=1043 normal=(-0.00730279 -0.485785 0.874047)}
Corner 370 704 {wid=512 normal=(-0.0525061 -0.448979 0.891998)}
Corner 180 704 {wid=47 normal=(0.0247551 0.0123975 0.999617)}
Corner 116 705 {wid=317 normal=(0.662786 0.0799745 0.744525)}
Corner 371 705 {wid=1044 normal=(0.89887 -0.350427 0.263121)}
Corner 370 706 {wid=1042 normal=(0.507817 -0.651272 0.563885)}
Corner 371 706 {wid=1044 normal=(0.89887 -0.350427 0.263121)}
Corner 456 706 {wid=1241 normal=(0.901058 -0.428474 0.0671149)}
Corner 370 707 {wid=1042 normal=(0.507817 -0.651272 0.563885)}
Corner 413 707 {wid=1045 normal=(0.384018 -0.8482 0.364811)}
Corner 371 707 {wid=1044 normal=(0.89887 -0.350427 0.263121)}
Corner 218 708 {wid=929 normal=(-0.175241 0.977197 -0.119909)}
Corner 372 708 {wid=713 normal=(0.411303 0.189226 0.891641)}
Corner 334 708 {wid=928 normal=(-0.475024 -0.827081 0.300481)}
Corner 218 709 {wid=929 normal=(-0.175241 0.977197 -0.119909)}
Corner 21 709 {wid=582 normal=(-0.0213408 -0.365928 -0.930398)}
Corner 372 709 {wid=713 normal=(0.411303 0.189226 0.891641)}
Corner 316 711 {wid=877 normal=(-0.347808 -0.759033 0.550364)}
Corner 217 711 {wid=578 normal=(-0.96545 0.188575 0.179844)}
Corner 429 714 {wid=1174 normal=(0.617079 -0.547384 0.565319)}
Corner 296 714 {wid=822 normal=(0.933305 0.342152 0.108973)}
Corner 376 716 {wid=1049 normal=(-0.206474 -0.819079 0.535236)}
Corner 178 716 {wid=469 normal=(-0.058053 0.0128031 0.998232)}
Corner 161 717 {wid=434 normal=(-0.829604 -0.447757 -0.333573)}
Corner 376 717 {wid=1049 normal=(-0.206474 -0.819079 0.535236)}
Corner 110 718 {wid=121 normal=(0.879339 -0.474861 0.0356342)}
Corner 48 718 {wid=120 normal=(0.53755 0.292608 -0.790835)}
Corner 110 719 {wid=121 normal=(0.879339 -0.474861 0.0356342)}
Corner 118 719 {wid=303 normal=(-0.606342 -0.750993 0.261453)}
Corner 100 720 {wid=360 normal=(-0.355815 0.917834 0.176005)}
Corner 378 720 {wid=1051 normal=(-0.765794 0.604494 0.219425)}
Corner 129 720 {wid=358 normal=(0.534997 0.764104 0.360448)}
Corner 100 721 {wid=1053 normal=(-0.442451 0.181772 -0.878178)}
Corner 321 721 {wid=1054 normal=(-0.33119 -0.0703699 -0.940936)}
Corner 378 721 {wid=1052 normal=(-0.399313 0.0189141 -0.916619)}
Corner 195 724 {wid=1057 normal=(-7.26556e-007 -1 -1.46397e-005)}
Corner 380 724 {wid=1056 normal=(2.83128e-006 -1 -1.53292e-005)}
Corner 196 724 {wid=1058 normal=(-1.59798e-006 -1 -1.66152e-005)}
Corner 408 725 {wid=1120 normal=(0 -1 -1.21187e-005)}
Corner 91 725 {wid=1059 normal=(1.67919e-007 -1 -1.09642e-005)}
Corner 380 725 {wid=1056 normal=(2.83128e-006 -1 -1.53292e-005)}
Corner 122 726 {wid=1061 normal=(-0.907933 -0.23706 -0.345629)}
Corner 381 726 {wid=1060 normal=(-0.907933 -0.23706 -0.345629)}
Corner 136 726 {wid=1063 normal=(-0.881904 0.241906 -0.404631)}
Corner 122 727 {wid=1062 normal=(-0.493487 -0.8148 -0.304256)}
Corner 223 727 {wid=333 normal=(-0.399457 -0.914021 0.0707083)}
Corner 381 727 {wid=331 normal=(-0.443806 -0.893066 -0.0739529)}
Corner 6 728 {wid=127 normal=(-0.65579 0.646986 -0.389035)}
Corner 382 728 {wid=1064 normal=(-0.663897 0.64944 -0.370767)}
Corner 105 728 {wid=1065 normal=(-0.246541 0.288326 -0.925249)}
Corner 6 729 {wid=127 normal=(-0.65579 0.646986 -0.389035)}
Corner 104 729 {wid=126 normal=(0.268312 0.89905 0.346002)}
Corner 382 729 {wid=1064 normal=(-0.663897 0.64944 -0.370767)}
Corner 5 730 {wid=278 normal=(0.105432 0.131005 -0.985759)}
Corner 383 730 {wid=757 normal=(0.0218794 0.124831 -0.991937)}
Corner 358 730 {wid=1002 normal=(-0.860201 0.00831142 -0.509888)}
Corner 5 731 {wid=278 normal=(0.105432 0.131005 -0.985759)}
Corner 107 731 {wid=756 normal=(0.88708 0.201574 -0.415279)}
Corner 383 731 {wid=757 normal=(0.0218794 0.124831 -0.991937)}
Corner 384 732 {wid=1066 normal=(-0.212633 0.429771 0.877545)}
Corner 316 732 {wid=877 normal=(-0.347808 -0.759033 0.550364)}
Corner 260 733 {wid=716 normal=(0.00429493 -0.830333 0.557252)}
Corner 384 733 {wid=1066 normal=(-0.212633 0.429771 0.877545)}
Corner 188 734 {wid=1069 normal=(0.298057 0.893921 0.334765)}
Corner 385 734 {wid=1067 normal=(0.231091 0.954947 0.186206)}
Corner 386 734 {wid=1070 normal=(0.110105 0.978965 0.171769)}
Corner 188 735 {wid=420 normal=(0.553129 0.00661669 -0.83307)}
Corner 155 735 {wid=416 normal=(0.396052 0.0261731 -0.917855)}
Corner 385 735 {wid=1068 normal=(0.389073 0.0869761 -0.917092)}
Corner 120 736 {wid=1071 normal=(0.117596 0.980577 0.156971)}
Corner 386 736 {wid=1070 normal=(0.110105 0.978965 0.171769)}
Corner 297 736 {wid=1072 normal=(0.350326 -0.00194418 0.936626)}
Corner 120 737 {wid=1071 normal=(0.117596 0.980577 0.156971)}
Corner 188 737 {wid=1069 normal=(0.298057 0.893921 0.334765)}
Corner 386 737 {wid=1070 normal=(0.110105 0.978965 0.171769)}
Corner 24 738 {wid=152 normal=(-0.957923 0.0920842 0.27185)}
Corner 387 738 {wid=1073 normal=(-0.105432 0.131005 -0.985759)}
Corner 120 738 {wid=325 normal=(-0.729423 0.184251 -0.658782)}
Corner 24 739 {wid=54 normal=(-0.962513 0.0685396 0.262437)}
Corner 89 739 {wid=174 normal=(-0.769754 -0.211784 0.602185)}
Corner 387 739 {wid=1074 normal=(0.0150934 0.0262485 -0.999542)}
Corner 21 740 {wid=1075 normal=(0.151259 0.959982 -0.235702)}
Corner 21 741 {wid=1075 normal=(0.151259 0.959982 -0.235702)}
Corner 218 741 {wid=579 normal=(-0.0709034 0.671173 -0.737902)}
Corner 390 744 {wid=1077 normal=(-0.640406 -0.40235 0.654213)}
Corner 168 745 {wid=443 normal=(-0.474002 0.372686 -0.797764)}
Corner 390 745 {wid=1077 normal=(-0.640406 -0.40235 0.654213)}
Corner 286 746 {wid=795 normal=(0.538335 -0.409545 -0.736524)}
Corner 80 748 {wid=545 normal=(0 -1 0)}
Corner 392 748 {wid=1079 normal=(0 -1 0)}
Corner 72 748 {wid=543 normal=(0 -1 0)}
Corner 80 749 {wid=1081 normal=(-0.93337 0.0302482 -0.357639)}
Corner 427 749 {wid=1082 normal=(-0.840889 0.486077 -0.237981)}
Corner 392 749 {wid=1080 normal=(-0.93337 0.0302482 -0.357639)}
Corner 19 750 {wid=19 normal=(-0.151259 0.959982 -0.235702)}
Corner 218 750 {wid=579 normal=(-0.0709034 0.671173 -0.737902)}
Corner 19 751 {wid=19 normal=(-0.151259 0.959982 -0.235702)}
Corner 162 751 {wid=436 normal=(-0.501228 -0.441033 -0.744487)}
Corner 113 752 {wid=1086 normal=(0.907933 -0.23706 -0.345629)}
Corner 394 752 {wid=1084 normal=(0.907933 -0.23706 -0.345629)}
Corner 132 752 {wid=1087 normal=(0.881904 0.241906 -0.404631)}
Corner 113 753 {wid=204 normal=(0.443806 -0.893067 -0.0739522)}
Corner 193 753 {wid=206 normal=(0.399457 -0.914021 0.0707083)}
Corner 394 753 {wid=1085 normal=(0.493487 -0.8148 -0.304256)}
Corner 207 754 {wid=1089 normal=(0 -1 0)}
Corner 395 754 {wid=357 normal=(0 -1 0)}
Corner 80 754 {wid=355 normal=(0 -1 0)}
Corner 207 755 {wid=212 normal=(0.954761 0.0258756 0.296246)}
Corner 128 755 {wid=211 normal=(-0.847783 0.183224 0.497687)}
Corner 395 755 {wid=1088 normal=(-0.0677854 -0.0181222 0.997535)}
Corner 280 759 {wid=1094 normal=(0.319459 0.920756 -0.223951)}
Corner 398 759 {wid=1092 normal=(0.717084 0.681669 -0.145319)}
Corner 282 759 {wid=1095 normal=(0.426064 0.89554 0.128362)}
Corner 280 760 {wid=31 normal=(-0.610713 -0.106723 -0.784627)}
Corner 281 760 {wid=770 normal=(-0.259452 -0.51857 -0.814721)}
Corner 398 760 {wid=1093 normal=(0.0236898 0.166605 -0.985739)}
Corner 137 762 {wid=372 normal=(0.537093 -0.226403 0.812572)}
Corner 290 763 {wid=595 normal=(-0.161351 0.986814 -0.0127871)}
Corner 400 763 {wid=1097 normal=(-0.159257 0.983472 -0.0861419)}
Corner 189 763 {wid=1098 normal=(0.0921581 0.989073 -0.115074)}
Corner 290 764 {wid=595 normal=(-0.161351 0.986814 -0.0127871)}
Corner 223 764 {wid=593 normal=(-0.169808 0.984837 0.0355105)}
Corner 400 764 {wid=1097 normal=(-0.159257 0.983472 -0.0861419)}
Corner 148 765 {wid=1099 normal=(0.281157 0.0446223 0.958624)}
Corner 401 765 {wid=979 normal=(-0.374561 -0.162978 0.912766)}
Corner 117 765 {wid=978 normal=(0.476997 -0.213336 0.85262)}
Corner 148 766 {wid=1100 normal=(-0.024755 0.0123975 0.999617)}
Corner 180 766 {wid=47 normal=(0.0247551 0.0123975 0.999617)}
Corner 401 766 {wid=62 normal=(0.283469 -0.26181 0.922551)}
Corner 148 767 {wid=477 normal=(0.0002943 -0.999998 0.00206073)}
Corner 402 767 {wid=1101 normal=(0.000284401 -0.999998 0.00199279)}
Corner 210 767 {wid=475 normal=(-0.000284401 -0.999998 0.00199279)}
Corner 148 768 {wid=477 normal=(0.0002943 -0.999998 0.00206073)}
Corner 54 768 {wid=1102 normal=(0.0252291 -0.999332 0.0264289)}
Corner 402 768 {wid=1101 normal=(0.000284401 -0.999998 0.00199279)}
Corner 148 769 {wid=477 normal=(0.0002943 -0.999998 0.00206073)}
Corner 403 769 {wid=1103 normal=(0.00712203 -0.999973 0.00188856)}
Corner 54 769 {wid=1102 normal=(0.0252291 -0.999332 0.0264289)}
Corner 148 770 {wid=1099 normal=(0.281157 0.0446223 0.958624)}
Corner 117 770 {wid=978 normal=(0.476997 -0.213336 0.85262)}
Corner 403 770 {wid=1104 normal=(0.676588 0.0929373 0.730473)}
Corner 187 771 {wid=1107 normal=(0.0199924 -0.675713 -0.736893)}
Corner 404 771 {wid=1105 normal=(-0.0126334 -0.53062 -0.847516)}
Corner 37 771 {wid=1108 normal=(-0.0350127 -0.419273 -0.907185)}
Corner 187 772 {wid=844 normal=(-0.451581 -0.77522 -0.441711)}
Corner 63 772 {wid=843 normal=(-0.585757 -0.800985 -0.12374)}
Corner 404 772 {wid=1106 normal=(-0.451581 -0.77522 -0.441711)}
Corner 310 775 {wid=1111 normal=(-0.43829 0.865637 -0.24202)}
Corner 406 775 {wid=1110 normal=(-0.846246 -0.341047 -0.409335)}
Corner 407 775 {wid=1113 normal=(-0.847538 -0.338438 -0.408826)}
Corner 310 776 {wid=1112 normal=(-0.957973 0.286687 -0.00992228)}
Corner 327 776 {wid=912 normal=(-0.0970998 0.255476 -0.961927)}
Corner 406 776 {wid=914 normal=(-0.482148 -0.0425754 -0.875055)}
Corner 124 777 {wid=1116 normal=(0.182516 0.0816397 -0.979808)}
Corner 407 777 {wid=1114 normal=(0.108579 0.14612 -0.98329)}
Corner 234 777 {wid=1118 normal=(0.182516 0.0816396 -0.979808)}
Corner 124 778 {wid=1117 normal=(0.673642 0.67002 -0.311897)}
Corner 310 778 {wid=1119 normal=(0.612849 0.76051 0.214572)}
Corner 407 778 {wid=1115 normal=(0.578781 0.81427 -0.044461)}
Corner 195 779 {wid=1057 normal=(-7.26556e-007 -1 -1.46397e-005)}
Corner 408 779 {wid=1120 normal=(0 -1 -1.21187e-005)}
Corner 380 779 {wid=1056 normal=(2.83128e-006 -1 -1.53292e-005)}
Corner 195 780 {wid=199 normal=(-0.879861 6.70713e-006 -0.47523)}
Corner 283 780 {wid=88 normal=(-0.225944 1.37548e-005 -0.97414)}
Corner 408 780 {wid=1121 normal=(0 1.41228e-005 -1)}
Corner 174 781 {wid=1124 normal=(0.932057 -0.308344 -0.190247)}
Corner 409 781 {wid=1122 normal=(0.674988 -0.35259 -0.648129)}
Corner 475 781 {wid=1126 normal=(0.782214 -0.349057 -0.516044)}
Corner 174 782 {wid=1125 normal=(0.965489 0.214311 -0.14799)}
Corner 73 782 {wid=1127 normal=(0.930608 0.351687 0.101412)}
Corner 409 782 {wid=1123 normal=(0.965489 0.214311 -0.14799)}
Corner 83 783 {wid=597 normal=(0.00884043 0.99186 0.127024)}
Corner 410 783 {wid=1128 normal=(-0.0586022 0.987693 0.145012)}
Corner 223 783 {wid=593 normal=(-0.169808 0.984837 0.0355105)}
Corner 83 784 {wid=1130 normal=(-0.47111 -0.826591 0.307899)}
Corner 279 784 {wid=1131 normal=(-0.488681 -0.286407 0.824113)}
Corner 410 784 {wid=1129 normal=(-0.47111 -0.826591 0.307899)}
Corner 155 785 {wid=321 normal=(-0.371525 -0.377398 -0.848257)}
Corner 411 785 {wid=1132 normal=(-0.345151 -0.49242 -0.798995)}
Corner 386 785 {wid=323 normal=(-0.451303 0.221246 -0.864509)}
Corner 155 786 {wid=1133 normal=(-0.000100061 -1 0.000102336)}
Corner 351 786 {wid=419 normal=(0.00198237 -0.999998 0.000241191)}
Corner 411 786 {wid=417 normal=(0.00254064 -0.999997 0.000278416)}
Corner 208 787 {wid=869 normal=(-0.902467 0.343409 -0.260044)}
Corner 412 787 {wid=1134 normal=(-0.791026 0.608201 -0.0661048)}
Corner 311 787 {wid=867 normal=(-0.57151 0.433009 -0.69705)}
Corner 208 788 {wid=869 normal=(-0.902467 0.343409 -0.260044)}
Corner 160 788 {wid=1135 normal=(-0.887285 0.136978 0.440412)}
Corner 412 788 {wid=1134 normal=(-0.791026 0.608201 -0.0661048)}
Corner 116 789 {wid=478 normal=(-0.196305 -0.727873 0.657012)}
Corner 413 789 {wid=1136 normal=(0.513577 -0.170239 0.840986)}
Corner 180 789 {wid=474 normal=(-0.281157 0.0446223 0.958624)}
Corner 116 790 {wid=1138 normal=(0.640911 -0.707263 0.298349)}
Corner 371 790 {wid=1139 normal=(0.833487 -0.40752 0.373131)}
Corner 413 790 {wid=1137 normal=(0.91762 -0.088393 0.387505)}
Corner 56 791 {wid=134 normal=(0.948439 0.0166693 0.316522)}
Corner 414 791 {wid=1141 normal=(0.388515 -0.192574 0.901094)}
Corner 464 791 {wid=242 normal=(0.395789 -0.238275 0.886891)}
Corner 56 792 {wid=97 normal=(0.547319 -0.831191 0.097798)}
Corner 273 792 {wid=746 normal=(-0.0385036 0.23259 0.971813)}
Corner 414 792 {wid=1140 normal=(0.206474 -0.819079 0.535236)}
Corner 34 793 {wid=146 normal=(0.68621 0.250027 0.683082)}
Corner 34 794 {wid=146 normal=(0.68621 0.250027 0.683082)}
Corner 126 795 {wid=279 normal=(-0.00230553 -0.999998 0.000255022)}
Corner 416 795 {wid=1143 normal=(-0.00787849 -0.999969 0.000809694)}
Corner 305 795 {wid=281 normal=(-0.00373078 -0.999993 0.000396875)}
Corner 126 796 {wid=346 normal=(0.345151 -0.49242 -0.798995)}
Corner 364 796 {wid=350 normal=(0.451303 0.221246 -0.864509)}
Corner 416 796 {wid=1144 normal=(0.345151 -0.49242 -0.798995)}
Corner 229 797 {wid=613 normal=(0.285196 -0.349738 -0.892383)}
Corner 417 797 {wid=1145 normal=(0.906052 -0.272825 0.323476)}
Corner 107 797 {wid=125 normal=(0.984446 -0.0348826 -0.172193)}
Corner 229 798 {wid=1146 normal=(0.0401659 0.996302 -0.0759506)}
Corner 105 798 {wid=287 normal=(0.284235 0.762056 -0.581792)}
Corner 417 798 {wid=614 normal=(0.239118 0.841127 -0.485106)}
Corner 325 799 {wid=901 normal=(-0.43054 0.198616 0.880447)}
Corner 418 799 {wid=1147 normal=(-0.461835 -0.103252 0.880935)}
Corner 293 799 {wid=903 normal=(-0.473595 -0.0668016 0.878205)}
Corner 325 800 {wid=1149 normal=(0.693478 -0.656899 0.295927)}
Corner 450 800 {wid=1150 normal=(0.961738 -0.272502 -0.0283278)}
Corner 418 800 {wid=1148 normal=(0.883645 -0.42114 0.204483)}
Corner 293 801 {wid=1029 normal=(-0.405249 -0.873656 0.269255)}
Corner 419 801 {wid=1151 normal=(-0.666122 0.436009 -0.605126)}
Corner 450 801 {wid=1225 normal=(-0.0236898 0.166605 -0.985739)}
Corner 293 802 {wid=903 normal=(-0.473595 -0.0668016 0.878205)}
Corner 418 802 {wid=1147 normal=(-0.461835 -0.103252 0.880935)}
Corner 419 802 {wid=1152 normal=(-0.821859 0.493605 0.284432)}
Corner 74 803 {wid=1155 normal=(-0.965489 0.214311 -0.14799)}
Corner 420 803 {wid=1153 normal=(-0.965489 0.214311 -0.14799)}
Corner 101 803 {wid=1157 normal=(-0.930608 0.351687 0.101412)}
Corner 74 804 {wid=1156 normal=(-0.932057 -0.308344 -0.190247)}
Corner 68 804 {wid=1158 normal=(-0.932057 -0.308344 -0.190247)}
Corner 420 804 {wid=1154 normal=(-0.674988 -0.35259 -0.648129)}
Corner 189 805 {wid=911 normal=(0.451581 -0.77522 -0.441711)}
Corner 421 805 {wid=1159 normal=(0.451581 -0.77522 -0.441711)}
Corner 326 805 {wid=907 normal=(0.585757 -0.800985 -0.12374)}
Corner 189 806 {wid=1161 normal=(-0.0199924 -0.675713 -0.736893)}
Corner 45 806 {wid=1162 normal=(0.0350127 -0.419273 -0.907185)}
Corner 421 806 {wid=1160 normal=(0.0126335 -0.53062 -0.847516)}
Corner 82 809 {wid=218 normal=(0.821084 -0.0516671 0.568465)}
Corner 423 809 {wid=1164 normal=(0.855577 -0.132652 -0.500392)}
Corner 189 809 {wid=171 normal=(0.425673 -0.201149 -0.882236)}
Corner 82 810 {wid=438 normal=(0.806427 -0.0546584 0.588802)}
Corner 498 810 {wid=1330 normal=(0.9456 -0.0937641 -0.311527)}
Corner 423 810 {wid=1165 normal=(0.827383 -0.112459 -0.550264)}
Corner 28 815 {wid=130 normal=(0.857805 7.30082e-006 -0.513976)}
Corner 426 815 {wid=1168 normal=(0.526783 1.20048e-005 -0.85)}
Corner 150 815 {wid=406 normal=(0.857806 7.3008e-006 -0.513974)}
Corner 28 816 {wid=63 normal=(0.844464 0.27469 -0.459812)}
Corner 26 816 {wid=59 normal=(0.32379 0.188469 -0.927168)}
Corner 426 816 {wid=1169 normal=(0.561629 0.298281 -0.771752)}
Corner 106 817 {wid=1022 normal=(-0.289148 0.946954 0.140253)}
Corner 427 817 {wid=1170 normal=(-0.289148 0.946954 0.140253)}
Corner 363 817 {wid=1020 normal=(0.729441 0.585339 0.35397)}
Corner 106 818 {wid=1171 normal=(-0.840889 0.486077 -0.237981)}
Corner 392 818 {wid=1080 normal=(-0.93337 0.0302482 -0.357639)}
Corner 427 818 {wid=1082 normal=(-0.840889 0.486077 -0.237981)}
Corner 1 819 {wid=155 normal=(-0.992525 -0.117469 0.0330816)}
Corner 428 819 {wid=1172 normal=(-0.424149 -0.208663 -0.881225)}
Corner 64 819 {wid=156 normal=(-0.482358 -0.205572 -0.851511)}
Corner 484 820 {wid=1 normal=(-0.962462 0.261098 -0.0741227)}
Corner 428 820 {wid=1173 normal=(-0.550002 -0.0093556 -0.835111)}
Corner 260 821 {wid=1175 normal=(0.00429505 -0.830332 0.557252)}
Corner 429 821 {wid=462 normal=(0.617079 -0.547383 0.565319)}
Corner 384 821 {wid=464 normal=(-0.212634 0.429772 0.877544)}
Corner 429 822 {wid=1174 normal=(0.617079 -0.547384 0.565319)}
Corner 89 823 {wid=1177 normal=(-0.902133 0.402011 -0.156661)}
Corner 430 823 {wid=1176 normal=(-0.863709 0.446679 -0.23342)}
Corner 299 823 {wid=1178 normal=(-0.207635 0.57765 -0.789436)}
Corner 89 824 {wid=1177 normal=(-0.902133 0.402011 -0.156661)}
Corner 60 824 {wid=1179 normal=(-0.725011 0.65665 0.207773)}
Corner 430 824 {wid=1176 normal=(-0.863709 0.446679 -0.23342)}
Corner 426 825 {wid=1168 normal=(0.526783 1.20048e-005 -0.85)}
Corner 432 825 {wid=1180 normal=(0.22411 1.3766e-005 -0.974564)}
Corner 287 825 {wid=797 normal=(0.102579 1.40492e-005 -0.994725)}
Corner 426 826 {wid=1169 normal=(0.561629 0.298281 -0.771752)}
Corner 42 826 {wid=82 normal=(0 -0.139361 -0.990242)}
Corner 431 826 {wid=1181 normal=(0.13043 0.357426 -0.924789)}
Corner 431 827 {wid=1183 normal=(5.41513e-006 -1 -1.45493e-005)}
Corner 432 827 {wid=1182 normal=(3.55377e-006 -1 -1.69459e-005)}
Corner 426 827 {wid=1184 normal=(0.133532 -0.966143 -0.220762)}
Corner 431 828 {wid=1183 normal=(5.41513e-006 -1 -1.45493e-005)}
Corner 209 828 {wid=1185 normal=(-1.84279e-006 -1 -1.91625e-005)}
Corner 432 828 {wid=1182 normal=(3.55377e-006 -1 -1.69459e-005)}
Corner 209 829 {wid=1185 normal=(-1.84279e-006 -1 -1.91625e-005)}
Corner 433 829 {wid=1186 normal=(-9.2847e-007 -1 -1.11907e-005)}
Corner 432 829 {wid=1182 normal=(3.55377e-006 -1 -1.69459e-005)}
Corner 209 830 {wid=1185 normal=(-1.84279e-006 -1 -1.91625e-005)}
Corner 435 830 {wid=1187 normal=(5.42929e-006 -1 -5.75675e-006)}
Corner 433 830 {wid=1186 normal=(-9.2847e-007 -1 -1.11907e-005)}
Corner 433 831 {wid=550 normal=(-0.342231 1.32704e-005 -0.939615)}
Corner 434 831 {wid=1188 normal=(-0.857805 7.30072e-006 -0.513975)}
Corner 151 831 {wid=407 normal=(-0.857805 7.30093e-006 -0.513975)}
Corner 433 832 {wid=1186 normal=(-9.2847e-007 -1 -1.11907e-005)}
Corner 435 832 {wid=1187 normal=(5.42929e-006 -1 -5.75675e-006)}
Corner 434 832 {wid=1189 normal=(3.4853e-006 -1 -6.14065e-006)}
Corner 51 833 {wid=122 normal=(-0.878715 0.225038 0.420973)}
Corner 435 833 {wid=1190 normal=(-0.844464 0.274691 -0.459812)}
Corner 101 833 {wid=275 normal=(-0.736123 0.398544 -0.547068)}
Corner 51 834 {wid=1191 normal=(-4.99408e-006 -1 -1.61264e-005)}
Corner 434 834 {wid=1189 normal=(3.4853e-006 -1 -6.14065e-006)}
Corner 435 834 {wid=1187 normal=(5.42929e-006 -1 -5.75675e-006)}
Corner 40 835 {wid=131 normal=(0.134376 -1.39895e-005 0.99093)}
Corner 436 835 {wid=1192 normal=(-0.687629 -1.0239e-005 0.726063)}
Corner 51 835 {wid=365 normal=(-0.981946 -2.67981e-006 0.189162)}
Corner 40 836 {wid=450 normal=(0.137465 -1.39866e-005 0.990507)}
Corner 92 836 {wid=133 normal=(0.137464 -1.39866e-005 0.990507)}
Corner 436 836 {wid=1193 normal=(-0.690295 -9.25497e-006 0.723528)}
Corner 438 837 {wid=1195 normal=(0 -0.051026 0.998697)}
Corner 437 837 {wid=848 normal=(0.00041185 -0.0515133 0.998672)}
Corner 304 837 {wid=845 normal=(0 -0.051026 0.998697)}
Corner 97 838 {wid=257 normal=(0.038502 0.23259 0.971813)}
Corner 437 838 {wid=1194 normal=(0.0580514 0.0128031 0.998232)}
Corner 97 839 {wid=397 normal=(0.823243 0.566297 0.0397297)}
Corner 438 839 {wid=1196 normal=(0.820134 0.570936 0.0375861)}
Corner 146 839 {wid=395 normal=(0.8313 0.554691 -0.0354683)}
Corner 97 840 {wid=397 normal=(0.823243 0.566297 0.0397297)}
Corner 437 840 {wid=1197 normal=(0.80458 0.593225 0.0271322)}
Corner 438 840 {wid=1196 normal=(0.820134 0.570936 0.0375861)}
Corner 439 841 {wid=1198 normal=(0.855113 0.123779 -0.503448)}
Corner 34 842 {wid=146 normal=(0.68621 0.250027 0.683082)}
Corner 439 842 {wid=1198 normal=(0.855113 0.123779 -0.503448)}
Corner 175 843 {wid=457 normal=(0.0769674 -0.843962 0.530852)}
Corner 440 843 {wid=1199 normal=(0.0639027 -0.274665 0.959414)}
Corner 175 844 {wid=458 normal=(0.0769674 -0.843962 0.530852)}
Corner 197 844 {wid=459 normal=(-0.0923452 0.7469 0.658493)}
Corner 440 844 {wid=1200 normal=(0.0639027 -0.274665 0.959414)}
Corner 243 845 {wid=658 normal=(-0.660614 -0.615839 -0.429339)}
Corner 441 845 {wid=1201 normal=(-0.446972 -0.774972 -0.446805)}
Corner 149 845 {wid=1202 normal=(-0.75203 -0.596929 0.279512)}
Corner 243 846 {wid=658 normal=(-0.660614 -0.615839 -0.429339)}
Corner 55 846 {wid=659 normal=(-0.383541 -0.342221 -0.857777)}
Corner 441 846 {wid=1201 normal=(-0.446972 -0.774972 -0.446805)}
Corner 149 847 {wid=1202 normal=(-0.75203 -0.596929 0.279512)}
Corner 442 847 {wid=1203 normal=(-0.815434 -0.577298 0.0423699)}
Corner 243 847 {wid=658 normal=(-0.660614 -0.615839 -0.429339)}
Corner 149 848 {wid=1202 normal=(-0.75203 -0.596929 0.279512)}
Corner 160 848 {wid=1204 normal=(-0.887285 0.136978 0.440412)}
Corner 442 848 {wid=1203 normal=(-0.815434 -0.577298 0.0423699)}
Corner 236 851 {wid=633 normal=(-0.90941 -0.340812 -0.238371)}
Corner 236 852 {wid=633 normal=(-0.90941 -0.340812 -0.238371)}
Corner 288 852 {wid=10 normal=(-0.69883 -0.707966 -0.102083)}
Corner 159 853 {wid=1207 normal=(0.982907 0.148424 0.108925)}
Corner 445 853 {wid=431 normal=(0.964442 -0.0385043 -0.261475)}
Corner 62 853 {wid=269 normal=(0.816214 0.268905 -0.511356)}
Corner 159 854 {wid=1208 normal=(0.13447 0.712199 0.688977)}
Corner 336 854 {wid=433 normal=(0.130865 0.713508 0.688317)}
Corner 445 854 {wid=430 normal=(0.351847 0.673001 0.650594)}
Corner 282 855 {wid=779 normal=(0.43039 0.199548 0.88031)}
Corner 446 855 {wid=1209 normal=(0.821859 0.493605 0.284432)}
Corner 349 855 {wid=968 normal=(0.461835 -0.103252 0.880935)}
Corner 282 856 {wid=1211 normal=(0.405249 -0.873656 0.269256)}
Corner 398 856 {wid=1212 normal=(0.0236898 0.166605 -0.985739)}
Corner 446 856 {wid=1210 normal=(0.803622 0.526692 -0.277106)}
Corner 102 857 {wid=1214 normal=(-0.115738 -0.983081 -0.141976)}
Corner 447 857 {wid=787 normal=(-0.115738 -0.983081 -0.141976)}
Corner 283 857 {wid=785 normal=(-0.0422059 -0.99194 -0.119473)}
Corner 102 858 {wid=1215 normal=(-0.99813 0.0208377 0.0574692)}
Corner 133 858 {wid=1216 normal=(-0.977059 -0.207437 -0.0482349)}
Corner 447 858 {wid=1213 normal=(-0.996035 -0.0888412 0.00458071)}
Corner 203 859 {wid=568 normal=(-0.801792 0.35065 0.483916)}
Corner 448 859 {wid=1217 normal=(-0.935025 0.205428 0.289011)}
Corner 215 859 {wid=566 normal=(-0.782873 0.498596 0.372174)}
Corner 203 860 {wid=1219 normal=(-0.289116 0.0549553 -0.955715)}
Corner 216 860 {wid=1220 normal=(-0.289116 0.0549553 -0.955715)}
Corner 448 860 {wid=1218 normal=(-0.449911 -0.353984 -0.819924)}
Corner 497 861 {wid=1223 normal=(-0.229145 0.48856 0.841904)}
Corner 449 861 {wid=1221 normal=(-0.554089 0.271437 0.786961)}
Corner 496 861 {wid=1224 normal=(-0.538468 0.0768128 0.839138)}
Corner 246 862 {wid=967 normal=(0.957973 0.286687 -0.00992233)}
Corner 348 862 {wid=965 normal=(-0.108579 0.14612 -0.98329)}
Corner 449 862 {wid=1222 normal=(0.0970998 0.255476 -0.961927)}
Corner 366 863 {wid=1226 normal=(0.728329 -0.637246 0.251902)}
Corner 450 863 {wid=1150 normal=(0.961738 -0.272502 -0.0283278)}
Corner 325 863 {wid=1149 normal=(0.693478 -0.656899 0.295927)}
Corner 366 864 {wid=1028 normal=(0.259452 -0.51857 -0.81472)}
Corner 293 864 {wid=1029 normal=(-0.405249 -0.873656 0.269255)}
Corner 450 864 {wid=1225 normal=(-0.0236898 0.166605 -0.985739)}
Corner 273 865 {wid=1229 normal=(-0.167569 0.0780136 0.982769)}
Corner 451 865 {wid=1227 normal=(-0.167569 0.0780136 0.982769)}
Corner 178 865 {wid=1231 normal=(-0.0856723 0.130911 0.987685)}
Corner 273 866 {wid=1230 normal=(0.392041 0.312524 0.865236)}
Corner 275 866 {wid=1232 normal=(0.801586 0.399196 0.445087)}
Corner 451 866 {wid=1228 normal=(0.392041 0.312524 0.865236)}
Corner 197 867 {wid=515 normal=(-0.0923451 0.7469 0.658492)}
Corner 197 868 {wid=515 normal=(-0.0923451 0.7469 0.658492)}
Corner 162 871 {wid=1237 normal=(0.064406 -0.994596 -0.0814278)}
Corner 454 871 {wid=1236 normal=(0.0504099 -0.995293 -0.0827718)}
Corner 320 871 {wid=1238 normal=(-0.064406 -0.994596 -0.0814278)}
Corner 162 872 {wid=436 normal=(-0.501228 -0.441033 -0.744487)}
Corner 19 872 {wid=19 normal=(-0.151259 0.959982 -0.235702)}
Corner 454 872 {wid=1235 normal=(-0.273945 -0.383981 0.881766)}
Corner 456 873 {wid=74 normal=(-0.901057 -0.428475 0.0671155)}
Corner 455 873 {wid=1239 normal=(-0.947636 -0.304113 0.0974719)}
Corner 352 873 {wid=976 normal=(-0.384018 -0.8482 0.364811)}
Corner 456 874 {wid=1240 normal=(-0.343435 -0.934565 -0.0929585)}
Corner 298 874 {wid=828 normal=(-0.24585 -0.951927 -0.182738)}
Corner 455 874 {wid=830 normal=(-0.343435 -0.934565 -0.0929585)}
Corner 15 875 {wid=15 normal=(0.947637 -0.304113 0.0974711)}
Corner 456 875 {wid=1241 normal=(0.901058 -0.428474 0.0671149)}
Corner 371 875 {wid=1044 normal=(0.89887 -0.350427 0.263121)}
Corner 15 876 {wid=85 normal=(0.343435 -0.934565 -0.0929585)}
Corner 298 876 {wid=84 normal=(0.24585 -0.951927 -0.182738)}
Corner 456 876 {wid=1242 normal=(0.343435 -0.934565 -0.0929585)}
Corner 309 877 {wid=859 normal=(0.78527 -0.252403 0.56537)}
Corner 457 877 {wid=1243 normal=(0.388951 -0.52054 0.760102)}
Corner 185 877 {wid=425 normal=(0 -0.544973 0.838454)}
Corner 309 878 {wid=1244 normal=(0.133989 -0.267693 0.954142)}
Corner 11 878 {wid=50 normal=(-0.828352 -0.0345488 0.559142)}
Corner 457 878 {wid=858 normal=(-0.794626 -0.589094 -0.14676)}
Corner 192 881 {wid=1248 normal=(-0.028191 0.116077 -0.99284)}
Corner 459 881 {wid=1247 normal=(0.225738 -0.320443 -0.919977)}
Corner 310 881 {wid=1249 normal=(0.225738 -0.320443 -0.919977)}
Corner 192 882 {wid=3 normal=(0.159692 -0.670057 -0.724929)}
Corner 478 882 {wid=38 normal=(-0.520127 -0.61836 0.589152)}
Corner 459 882 {wid=1246 normal=(-0.437007 -0.898389 -0.0438495)}
Corner 459 883 {wid=1251 normal=(0.0889453 0.0858136 0.992333)}
Corner 460 883 {wid=917 normal=(-0.12264 0.298573 0.946474)}
Corner 310 883 {wid=915 normal=(-0.0477115 0.127817 0.990649)}
Corner 459 884 {wid=1246 normal=(-0.437007 -0.898389 -0.0438495)}
Corner 234 884 {wid=36 normal=(-0.401139 -0.87131 -0.282678)}
Corner 460 884 {wid=1250 normal=(-0.443909 -0.539081 0.715776)}
Corner 235 885 {wid=632 normal=(0.93671 0.042744 0.347486)}
Corner 461 885 {wid=1252 normal=(0.926878 0.200156 0.317544)}
Corner 305 885 {wid=849 normal=(0.926878 0.200156 0.317544)}
Corner 235 886 {wid=631 normal=(0.879032 0.0281601 0.475931)}
Corner 72 886 {wid=181 normal=(0.973367 0.0443024 -0.22493)}
Corner 461 886 {wid=1253 normal=(0.792612 -0.00310954 0.609719)}
Corner 99 887 {wid=864 normal=(0.483785 0.84392 0.231844)}
Corner 462 887 {wid=1254 normal=(0.633137 0.773251 0.0349348)}
Corner 192 887 {wid=862 normal=(0.61907 0.726321 -0.298682)}
Corner 99 888 {wid=864 normal=(0.483785 0.84392 0.231844)}
Corner 191 888 {wid=1255 normal=(0.562627 0.806963 0.179616)}
Corner 462 888 {wid=1254 normal=(0.633137 0.773251 0.0349348)}
Corner 183 889 {wid=483 normal=(0.903737 -0.139763 0.404631)}
Corner 463 889 {wid=1256 normal=(0.406227 0.128465 0.904697)}
Corner 328 889 {wid=56 normal=(0.0988593 0.0704348 0.992606)}
Corner 183 890 {wid=484 normal=(0.685062 0.46838 -0.557951)}
Corner 255 890 {wid=486 normal=(0.663897 0.64944 -0.370767)}
Corner 463 890 {wid=1257 normal=(0.110271 0.958584 0.262595)}
Corner 173 891 {wid=927 normal=(0.231854 -0.957202 0.173227)}
Corner 464 891 {wid=1258 normal=(0.506783 -0.837552 0.204152)}
Corner 333 891 {wid=924 normal=(-0.0468879 -0.993825 0.100561)}
Corner 173 892 {wid=1260 normal=(0.0136195 -0.983052 0.182819)}
Corner 199 892 {wid=1261 normal=(0.233455 -0.972363 0.00286952)}
Corner 464 892 {wid=1259 normal=(-0.185254 -0.818211 0.544253)}
Corner 465 893 {wid=1262 normal=(0.636156 -0.404153 0.65724)}
Corner 95 893 {wid=252 normal=(0.686827 0.296644 -0.663529)}
Corner 390 894 {wid=1077 normal=(-0.640406 -0.40235 0.654213)}
Corner 465 894 {wid=1262 normal=(0.636156 -0.404153 0.65724)}
Corner 142 895 {wid=385 normal=(-0.757132 0.280681 0.589889)}
Corner 466 895 {wid=1263 normal=(-0.646524 0.194492 0.737686)}
Corner 64 895 {wid=342 normal=(-0.574638 0.117965 -0.809862)}
Corner 142 896 {wid=1265 normal=(0.145493 0.332305 0.931883)}
Corner 214 896 {wid=1266 normal=(0.145493 0.332305 0.931883)}
Corner 466 896 {wid=1264 normal=(0.145493 0.332305 0.931883)}
Corner 214 897 {wid=1268 normal=(-0.859078 -0.0523962 0.509154)}
Corner 467 897 {wid=386 normal=(-0.248883 0.548747 0.798081)}
Corner 466 897 {wid=1263 normal=(-0.646524 0.194492 0.737686)}
Corner 214 898 {wid=647 normal=(0.0875935 0.128379 0.987849)}
Corner 359 898 {wid=649 normal=(0.204073 0.368481 0.90696)}
Corner 467 898 {wid=1267 normal=(0.0952917 0.0707151 0.992934)}
Corner 61 899 {wid=196 normal=(-0.876826 -0.0381892 0.479289)}
Corner 468 899 {wid=1270 normal=(-0.792612 -0.00310947 0.609719)}
Corner 75 899 {wid=193 normal=(-0.973367 0.044302 -0.22493)}
Corner 61 900 {wid=151 normal=(-0.93671 0.042744 0.347486)}
Corner 120 900 {wid=325 normal=(-0.729423 0.184251 -0.658782)}
Corner 468 900 {wid=1269 normal=(-0.710195 -0.657447 0.251767)}
Corner 22 901 {wid=201 normal=(0.633129 0.771813 0.0587491)}
Corner 285 902 {wid=794 normal=(-0.12469 0.675132 0.727083)}
Corner 22 903 {wid=53 normal=(0.633129 0.771813 0.0587491)}
Corner 218 903 {wid=579 normal=(-0.0709034 0.671173 -0.737902)}
Corner 22 904 {wid=53 normal=(0.633129 0.771813 0.0587491)}
Corner 513 904 {wid=427 normal=(0.765972 -0.625534 0.148303)}
Corner 288 907 {wid=10 normal=(-0.69883 -0.707966 -0.102083)}
Corner 288 908 {wid=10 normal=(-0.69883 -0.707966 -0.102083)}
Corner 94 909 {wid=249 normal=(0.522959 -0.815795 -0.246966)}
Corner 324 909 {wid=899 normal=(0.985658 0.150248 -0.0768383)}
Corner 94 910 {wid=249 normal=(0.522959 -0.815795 -0.246966)}
Corner 93 910 {wid=246 normal=(-0.439854 -0.793636 -0.420323)}
Corner 92 911 {wid=200 normal=(0.142648 -1.39781e-005 0.989775)}
Corner 474 911 {wid=1276 normal=(0.687548 -1.02546e-005 0.726141)}
Corner 173 911 {wid=451 normal=(0.687547 -1.02545e-005 0.72614)}
Corner 92 912 {wid=133 normal=(0.137464 -1.39866e-005 0.990507)}
Corner 40 912 {wid=450 normal=(0.137465 -1.39866e-005 0.990507)}
Corner 474 912 {wid=1277 normal=(0.690295 -9.26699e-006 0.723528)}
Corner 79 913 {wid=306 normal=(0.302597 -0.835833 -0.458058)}
Corner 475 913 {wid=1278 normal=(0.39653 -0.865229 -0.306826)}
Corner 394 913 {wid=304 normal=(0.483685 -0.874025 0.0461481)}
Corner 79 914 {wid=412 normal=(0.585519 -0.805486 -0.0914339)}
Corner 152 914 {wid=408 normal=(-0.228757 -0.450348 -0.863051)}
Corner 475 914 {wid=1279 normal=(0.564232 -0.816065 -0.125222)}
Corner 140 915 {wid=1281 normal=(0.0219785 -0.962802 -0.269314)}
Corner 476 915 {wid=792 normal=(0.0219785 -0.962802 -0.269314)}
Corner 284 915 {wid=703 normal=(0.00114083 -0.985566 -0.16929)}
Corner 140 916 {wid=1282 normal=(-0.459494 -0.478404 -0.748328)}
Corner 39 916 {wid=1283 normal=(-0.218376 -0.0499032 -0.974588)}
Corner 476 916 {wid=1280 normal=(-0.398693 -0.206427 -0.89355)}
Corner 260 917 {wid=716 normal=(0.00429493 -0.830333 0.557252)}
Corner 142 919 {wid=764 normal=(-0.672534 -0.615184 0.411396)}
Corner 478 919 {wid=1286 normal=(-0.617653 -0.780622 0.0955695)}
Corner 191 919 {wid=762 normal=(-0.205656 -0.975747 0.074986)}
Corner 142 920 {wid=385 normal=(-0.757132 0.280681 0.589889)}
Corner 64 920 {wid=342 normal=(-0.574638 0.117965 -0.809862)}
Corner 478 920 {wid=1285 normal=(-0.998142 0.0581908 0.0180403)}
Corner 316 921 {wid=877 normal=(-0.347808 -0.759033 0.550364)}
Corner 316 922 {wid=877 normal=(-0.347808 -0.759033 0.550364)}
Corner 70 923 {wid=697 normal=(-0.315277 -0.54924 0.773909)}
Corner 480 923 {wid=1288 normal=(-0.450216 -0.762915 0.463968)}
Corner 252 923 {wid=695 normal=(-0.373527 -0.649391 0.662397)}
Corner 70 924 {wid=72 normal=(-0.121938 -0.561137 0.818692)}
Corner 184 924 {wid=237 normal=(-0.331964 -0.857713 0.392592)}
Corner 480 924 {wid=1289 normal=(-0.0640179 -0.877756 0.474812)}
Corner 75 925 {wid=1291 normal=(0.37563 -0.108027 0.920452)}
Corner 481 925 {wid=1290 normal=(0.920899 -0.0652175 0.384308)}
Corner 302 925 {wid=1292 normal=(0.422486 -0.192434 0.885706)}
Corner 75 926 {wid=1291 normal=(0.37563 -0.108027 0.920452)}
Corner 338 926 {wid=1293 normal=(0.280064 -0.10998 0.953661)}
Corner 481 926 {wid=1290 normal=(0.920899 -0.0652175 0.384308)}
Corner 140 927 {wid=1296 normal=(0.99813 0.0208377 0.0574692)}
Corner 482 927 {wid=1294 normal=(0.996035 -0.0888412 0.0045807)}
Corner 39 927 {wid=1297 normal=(0.977059 -0.207437 -0.0482349)}
Corner 140 928 {wid=789 normal=(0.115738 -0.983081 -0.141976)}
Corner 447 928 {wid=787 normal=(-0.115738 -0.983081 -0.141976)}
Corner 482 928 {wid=1295 normal=(0.115738 -0.983081 -0.141976)}
Corner 286 929 {wid=795 normal=(0.538335 -0.409545 -0.736524)}
Corner 1 931 {wid=1300 normal=(-0.0479454 0.998834 -0.00562707)}
Corner 484 931 {wid=1299 normal=(-0.040367 0.998737 -0.02992)}
Corner 428 931 {wid=1301 normal=(0.0392202 0.99413 -0.100834)}
Corner 1 932 {wid=1300 normal=(-0.0479454 0.998834 -0.00562707)}
Corner 2 932 {wid=1302 normal=(-0.0432227 0.986315 0.159107)}
Corner 484 932 {wid=1299 normal=(-0.040367 0.998737 -0.02992)}
Corner 10 933 {wid=49 normal=(-0.683589 0.238787 0.6897)}
Corner 485 933 {wid=1303 normal=(-0.534979 0.834261 0.133437)}
Corner 288 933 {wid=799 normal=(-0.69883 -0.707966 -0.102083)}
Corner 10 934 {wid=48 normal=(-0.683589 0.238787 0.6897)}
Corner 485 934 {wid=1304 normal=(-0.534979 0.834261 0.133437)}
Corner 156 935 {wid=422 normal=(-0.513976 -0.0141403 -0.857688)}
Corner 486 935 {wid=1305 normal=(-0.419169 0.132876 -0.898132)}
Corner 156 936 {wid=1307 normal=(-0.513976 -0.0141403 -0.857688)}
Corner 307 936 {wid=1308 normal=(0.262798 -0.0164802 -0.96471)}
Corner 486 936 {wid=1306 normal=(-0.419169 0.132876 -0.898132)}
Corner 232 937 {wid=1310 normal=(-5.6198e-006 0.419246 0.907873)}
Corner 487 937 {wid=1309 normal=(-5.6198e-006 0.419246 0.907873)}
Corner 144 937 {wid=1312 normal=(5.6198e-006 0.419246 0.907873)}
Corner 232 938 {wid=1311 normal=(1 1.49578e-005 0.000330856)}
Corner 233 938 {wid=625 normal=(1 1.82504e-006 0.000121235)}
Corner 487 938 {wid=627 normal=(1 1.49578e-005 0.000330856)}
Corner 230 941 {wid=615 normal=(-0.0296346 0.0852488 0.995919)}
Corner 489 941 {wid=1314 normal=(-0.892668 -0.251227 -0.374204)}
Corner 31 941 {wid=67 normal=(-0.695748 -8.50387e-005 0.718286)}
Corner 230 942 {wid=616 normal=(-0.134954 0.152573 0.979035)}
Corner 489 942 {wid=1315 normal=(-0.900996 -0.0910117 -0.424173)}
Corner 111 945 {wid=301 normal=(0.439072 -0.16797 0.882611)}
Corner 491 945 {wid=1317 normal=(-0.34401 -0.102476 0.933358)}
Corner 153 945 {wid=414 normal=(0.139682 -0.145153 0.979499)}
Corner 111 946 {wid=159 normal=(0.420084 -0.164547 0.892442)}
Corner 184 946 {wid=487 normal=(-0.804192 -0.0531573 0.591987)}
Corner 491 946 {wid=1318 normal=(-0.381745 -0.0985827 0.918994)}
Corner 153 949 {wid=300 normal=(0.162149 -0.146138 0.975885)}
Corner 493 949 {wid=1320 normal=(-0.833485 -0.0539916 0.549898)}
Corner 50 949 {wid=117 normal=(-0.638923 -0.0807716 0.765018)}
Corner 153 950 {wid=414 normal=(0.139682 -0.145153 0.979499)}
Corner 491 950 {wid=1317 normal=(-0.34401 -0.102476 0.933358)}
Corner 493 950 {wid=1321 normal=(-0.825323 -0.052926 0.562174)}
Corner 494 951 {wid=1322 normal=(-0.122348 0.0806769 0.989203)}
Corner 175 951 {wid=457 normal=(0.0769674 -0.843962 0.530852)}
Corner 494 952 {wid=1322 normal=(-0.122348 0.0806769 0.989203)}
Corner 30 953 {wid=30 normal=(-0.438481 -0.0943603 -0.893773)}
Corner 439 953 {wid=1198 normal=(0.855113 0.123779 -0.503448)}
Corner 30 954 {wid=30 normal=(-0.438481 -0.0943603 -0.893773)}
Corner 245 955 {wid=1325 normal=(-0.400346 -0.909307 -0.113507)}
Corner 496 955 {wid=673 normal=(-0.722548 -0.689809 0.0456897)}
Corner 348 955 {wid=675 normal=(-0.506678 -0.84641 0.163914)}
Corner 245 956 {wid=674 normal=(0.12264 0.298573 0.946474)}
Corner 246 956 {wid=672 normal=(0.183393 0.167208 0.968715)}
Corner 496 956 {wid=1324 normal=(0.191925 0.150621 0.969782)}
Corner 246 957 {wid=672 normal=(0.183393 0.167208 0.968715)}
Corner 497 957 {wid=1326 normal=(0.531554 0.41718 0.737165)}
Corner 496 957 {wid=1324 normal=(0.191925 0.150621 0.969782)}
Corner 246 958 {wid=1328 normal=(-0.642566 0.724698 -0.24884)}
Corner 449 958 {wid=1329 normal=(-0.684322 0.723088 -0.0940578)}
Corner 497 958 {wid=1327 normal=(-0.708489 0.702892 0.0631422)}
Corner 164 959 {wid=439 normal=(0.623812 -0.0797057 0.7775)}
Corner 498 959 {wid=1330 normal=(0.9456 -0.0937641 -0.311527)}
Corner 82 959 {wid=438 normal=(0.806427 -0.0546584 0.588802)}
Corner 164 960 {wid=162 normal=(0.614169 -0.0831513 0.784781)}
Corner 324 960 {wid=898 normal=(0.987937 -0.0634772 -0.141247)}
Corner 498 960 {wid=1331 normal=(0.990214 -0.0617275 -0.125162)}
Corner 258 961 {wid=711 normal=(0.311888 -0.943783 0.109541)}
Corner 372 962 {wid=715 normal=(0.411303 0.189226 0.891641)}
Corner 11 963 {wid=50 normal=(-0.828352 -0.0345488 0.559142)}
Corner 457 963 {wid=858 normal=(-0.794626 -0.589094 -0.14676)}
Corner 11 964 {wid=50 normal=(-0.828352 -0.0345488 0.559142)}
Corner 502 965 {wid=1335 normal=(0.818872 0.539945 0.194697)}
Corner 501 965 {wid=223 normal=(0.628226 0.6916 0.356401)}
Corner 84 965 {wid=195 normal=(0.504899 0.759721 0.409758)}
Corner 261 966 {wid=717 normal=(0.876333 0.118797 -0.466828)}
Corner 328 966 {wid=718 normal=(0.0395833 0.744261 0.666715)}
Corner 501 966 {wid=1334 normal=(0.537346 0.705587 0.46196)}
Corner 261 967 {wid=1337 normal=(0.976187 0.0424635 -0.212736)}
Corner 502 967 {wid=222 normal=(0.98103 0.0389605 -0.189902)}
Corner 119 967 {wid=24 normal=(0.908819 -0.00467443 -0.417165)}
Corner 261 968 {wid=1338 normal=(-0.372186 0.735049 -0.566728)}
Corner 501 968 {wid=1339 normal=(-0.40927 0.763939 -0.498894)}
Corner 502 968 {wid=1336 normal=(-0.426128 0.781047 -0.456487)}
Corner 2 969 {wid=1342 normal=(-0.0432227 0.986315 0.159107)}
Corner 503 969 {wid=1341 normal=(0.097471 0.988889 0.112245)}
Corner 253 969 {wid=1343 normal=(0.242048 0.970157 0.0143965)}
Corner 2 970 {wid=39 normal=(-0.648158 0.0211275 0.761213)}
Corner 336 970 {wid=936 normal=(-0.863052 -0.0451684 0.503092)}
Corner 503 970 {wid=1340 normal=(0.0296358 0.0852481 0.99592)}
Corner 260 971 {wid=716 normal=(0.00429493 -0.830333 0.557252)}
Corner 429 971 {wid=1174 normal=(0.617079 -0.547384 0.565319)}
Corner 260 972 {wid=716 normal=(0.00429493 -0.830333 0.557252)}
Corner 90 973 {wid=109 normal=(0.52363 -0.834479 0.171631)}
Corner 505 973 {wid=1345 normal=(0.758099 -0.608837 0.233671)}
Corner 90 974 {wid=1346 normal=(0.672636 -0.739922 0.00880541)}
Corner 326 974 {wid=906 normal=(0.746449 -0.485579 0.455003)}
Corner 505 974 {wid=908 normal=(0.608669 -0.658414 -0.442734)}
Corner 360 975 {wid=1010 normal=(0.960975 0.122342 -0.248112)}
Corner 231 975 {wid=1008 normal=(0.710938 0.608896 -0.35187)}
Corner 360 976 {wid=1010 normal=(0.960975 0.122342 -0.248112)}
Corner 240 976 {wid=561 normal=(-0.886219 -0.463015 -0.0152685)}
Corner 509 977 {wid=1350 normal=(0.923793 0.119347 0.363817)}
Corner 507 977 {wid=1348 normal=(0.431871 0.614814 0.659917)}
Corner 224 977 {wid=1352 normal=(0.341534 0.0374198 0.939124)}
Corner 510 978 {wid=1351 normal=(-0.356774 0.93393 0.0220667)}
Corner 242 978 {wid=1353 normal=(-0.758185 0.649619 0.0561323)}
Corner 507 978 {wid=1349 normal=(0.419061 0.897434 0.137839)}
Corner 508 979 {wid=1354 normal=(-0.351874 -0.508599 -0.785819)}
Corner 115 979 {wid=314 normal=(0.829604 -0.447757 -0.333573)}
Corner 264 980 {wid=726 normal=(-0.190205 0.546764 -0.815397)}
Corner 508 980 {wid=1354 normal=(-0.351874 -0.508599 -0.785819)}
Corner 244 981 {wid=1357 normal=(0.321735 -0.849626 -0.417878)}
Corner 509 981 {wid=1355 normal=(0.870238 -0.492525 0.010214)}
Corner 224 981 {wid=1359 normal=(0.506028 -0.85119 0.139328)}
Corner 510 982 {wid=1358 normal=(0.380431 0.316408 -0.868998)}
Corner 507 982 {wid=1360 normal=(0.727412 0.558316 -0.398941)}
Corner 509 982 {wid=1356 normal=(0.919897 0.0987296 -0.379528)}
Corner 244 983 {wid=1362 normal=(0.168281 0.0162169 -0.985606)}
Corner 510 983 {wid=1358 normal=(0.380431 0.316408 -0.868998)}
Corner 509 983 {wid=1356 normal=(0.919897 0.0987296 -0.379528)}
Corner 244 984 {wid=1363 normal=(-0.365922 0.459896 -0.809072)}
Corner 242 984 {wid=1364 normal=(-0.365922 0.459896 -0.809072)}
Corner 510 984 {wid=1361 normal=(-0.162392 0.450416 -0.877926)}
Corner 224 985 {wid=1367 normal=(-0.633137 0.773251 0.0349348)}
Corner 511 985 {wid=1365 normal=(-0.562627 0.806963 0.179616)}
Corner 58 985 {wid=1368 normal=(-0.872592 0.360974 -0.329061)}
Corner 224 986 {wid=653 normal=(0.183264 0.245187 0.951997)}
Corner 125 986 {wid=655 normal=(-0.016731 0.394151 0.918893)}
Corner 511 986 {wid=1366 normal=(-0.016731 0.394151 0.918893)}
Corner 250 988 {wid=692 normal=(0.244695 -0.097176 -0.964718)}
Corner 513 989 {wid=1370 normal=(0.765972 -0.625534 0.148303)}
Corner 286 989 {wid=795 normal=(0.538335 -0.409545 -0.736524)}
Corner 137 990 {wid=372 normal=(0.537093 -0.226403 0.812572)}
Corner 513 990 {wid=1370 normal=(0.765972 -0.625534 0.148303)}
#  (_write_mesh:             0.15)
#  (FilterPM:                0.17)
