# |Created on 2003/10/31 09:19:57 using:
# | C:\cygwin\home\Zoe\hh_src\bin\filtermesh.exe cessna_color500.m -removekey
# |  normal
# |(Timing on cpu=x86-L6-R0806 host=BUTTERCUP)
# | (_readmesh:               0.02)
# | (Filtermesh:              0.03)
# Created on 2003/10/31 09:22:02 using:
#  C:\cygwin\home\Zoe\hh_src\bin\filtermesh.exe c.m -removekey wid
# (Timing on cpu=x86-L6-R0806 host=BUTTERCUP)
#  (_readmesh:               0.02)
#  (Filtermesh:              0.02)
Vertex 1  -11.2429 -3.34616 -7.6444
Vertex 2  -11.4049 -3.2215 -7.5698
Vertex 3  -11.348 -3.47795 -7.71857
Vertex 4  -11.3587 -5.03145 -4.69954
Vertex 5  -11.2317 -3.07954 -7.70508
Vertex 6  -11.3373 0.265308 -7.80791
Vertex 7  -11.3929 -3.07629 -7.97425
Vertex 8  -11.3996 -3.07894 -7.7704
Vertex 9  -11.2704 -3.41977 -7.92181
Vertex 10  -11.4072 -4.92862 -10.2727
Vertex 11  -11.2997 -3.27368 -8.00828
Vertex 12  -11.2567 -4.67238 5.63925
Vertex 13  -11.3409 -5.00291 4.74338
Vertex 14  -11.4337 -4.30584 5.54256
Vertex 15  -11.3279 -3.48714 7.18154
Vertex 16  -11.3632 -4.15839 6.44287
Vertex 17  -11.2607 -0.885498 7.81201
Vertex 18  -11.4144 -0.465431 8.01354
Vertex 19  -11.3156 0.05431 7.75596
Vertex 20  -11.2389 -4.73976 10.5342
Vertex 21  -11.4135 -4.96246 10.3438
Vertex 22  -11.3323 -4.45603 10.2159
Vertex 23  -11.3419 -3.37287 7.94242
Vertex 24  -2.56373 -5.02805 0.899863
Vertex 25  -0.157729 -4.91732 0.928425
Vertex 26  -0.164229 -5.02968 -0.893371
Vertex 27  -1.78791 -4.30222 -2.48474
Vertex 28  -11.3489 -3.70489 -7.79146
Vertex 29  -11.1305 -3.10882 -8.33526
Vertex 30  -11.386 -3.33254 -8.33538
Vertex 31  -11.7354 -2.84954 -8.0453
Vertex 32  -11.3586 -3.0958 -7.34579
Vertex 33  -10.109 -2.85502 -6.56999
Vertex 34  -10.1863 -4.21425 -6.62607
Vertex 35  1.89827 -4.05522 -9.14679
Vertex 36  -10.1031 -2.86381 -8.96068
Vertex 37  -10.1781 -4.21366 6.59512
Vertex 38  -10.1241 -2.90343 6.4078
Vertex 39  -0.829151 -3.70095 8.63871
Vertex 40  -10.0932 -2.74701 8.6081
Vertex 41  -11.0998 -3.74205 7.82856
Vertex 42  -12.5183 -3.25372 7.79196
Vertex 43  -11.1762 -2.92501 8.20368
Vertex 44  -11.142 -2.91983 7.40455
Vertex 45  -11.2977 -3.50282 7.37258
Vertex 46  -11.4076 -3.08184 7.84094
Vertex 47  -11.4254 -3.35667 -7.95766
Vertex 48  18.9516 -2.31453 0.522404
Vertex 49  -0.155335 -0.216196 0.0961053
Vertex 50  -0.347151 -4.50954 -6.42412
Vertex 51  -2.70998 -3.38206 -22.1529
Vertex 52  -3.18481 -4.11531 13.3012
Vertex 53  18.927 -2.3574 -0.108172
Vertex 54  -7.39831 -4.63184 2.15221
Vertex 55  7.41935 -3.84473 2.10658
Vertex 56  -12.5087 -2.54419 -2.42289
Vertex 57  12.533 -2.58462 -1.47224
Vertex 58  -7.23466 -4.18859 10.2562
Vertex 59  -4.91658 -3.35218 16.1792
Vertex 60  -0.680317 -4.14481 -10.2505
Vertex 61  -0.681453 -4.29603 -10.2509
Vertex 62  -7.31656 -4.10195 -10.2588
Vertex 63  12.5618 0.515457 0.244445
Vertex 64  21.6703 5.09033 -0.0944992
Vertex 65  15.7337 -1.06548 -0.182942
Vertex 66  5.98 -0.733647 -1.35195
Vertex 67  1.24305 -1.63884 2.40269
Vertex 68  -13.4191 -5.16651 0.672846
Vertex 69  -6.72557 -3.83223 10.2578
Vertex 70  -6.20573 -3.42215 22.1539
Vertex 71  13.0416 -2.34073 1.44625
Vertex 72  13.9185 -2.42451 8.54118
Vertex 73  16.7063 -2.50268 8.61671
Vertex 74  -6.70658 -3.74122 -10.252
Vertex 75  1.88454 -4.18869 6.60922
Vertex 76  1.87813 -4.30066 9.09842
Vertex 77  -7.31276 -4.6197 -2.6485
Vertex 78  17.622 4.05037 0.240187
Vertex 79  18.192 5.03987 -0.198878
Vertex 80  12.6226 -2.68184 -1.46117
Vertex 81  13.9495 -2.37125 -7.00607
Vertex 82  13.3137 -2.58751 8.61806
Vertex 83  1.87295 -4.22788 -6.53973
Vertex 84  1.87204 -4.61032 -9.10595
Vertex 85  -0.326997 -4.38949 6.4326
Vertex 86  -0.343544 -4.54461 6.43121
Vertex 87  17.9382 -2.49078 -0.846229
Vertex 88  -6.32957 -3.37292 -22.1607
Vertex 89  13.9184 -2.42149 7.0258
Vertex 90  17.9342 -2.5033 0.870213
Vertex 91  -7.36194 -4.33265 6.42929
Vertex 92  16.7232 -2.53142 -8.593
Vertex 93  13.261 -2.62506 -8.51971
Vertex 94  -2.61083 -4.10085 -6.43229
Vertex 95  14.4305 0.0924068 0.244909
Vertex 96  11.6542 -0.258267 0.195894
Vertex 97  12.7237 0.285452 -0.223774
Vertex 98  -7.03889 -4.71171 2.66272
Vertex 99  -0.157895 -4.65733 -2.29819
Vertex 100  -5.9328 -4.05909 2.54482
Vertex 101  -2.59553 -4.29708 2.44597
Vertex 102  -18.8386 -2.73165 -0.640777
Vertex 103  -7.90715 -0.426592 -1.40047
Vertex 104  -11.8881 -2.38622 2.30811
Vertex 105  14.1638 -2.37695 7.01053
Vertex 106  13.318 -2.54942 -8.59581
Vertex 107  21.6746 5.09423 0.166146
Vertex 108  13.9039 -2.45869 -8.51982
Vertex 109  17.9373 -2.577 -0.860383
Vertex 110  16.7483 4.12514 -0.218186
Vertex 111  12.6206 -2.68089 1.48057
Vertex 112  11.6505 -0.246442 -0.173479
Vertex 113  7.44839 -0.824882 1.3836
Vertex 114  10.8002 -2.73151 1.6626
Vertex 115  18.9667 -2.81345 0.028035
Vertex 116  14.2278 -2.4148 -8.5175
Vertex 117  -2.74513 -3.29139 22.1529
Vertex 118  -2.20946 -3.5291 19.1112
Vertex 119  -1.18565 -4.0002 13.303
Vertex 120  19.5014 4.01321 -0.227995
Vertex 121  -0.97767 -1.60334 -2.55209
Vertex 122  -4.52032 -0.180064 0.0999518
Vertex 123  -5.70519 -0.113574 -0.0803541
Vertex 124  -1.80493 -0.488807 -1.5941
Vertex 125  4.33029 -1.56825 -2.16363
Vertex 126  5.91939 -0.815866 -1.3384
Vertex 127  4.32513 -0.724012 -1.38619
Vertex 128  5.38612 -1.6617 -2.08027
Vertex 129  5.34176 -1.66417 -2.01575
Vertex 130  -5.93758 -1.8574 -2.52584
Vertex 131  -8.28549 -2.00594 -2.22972
Vertex 132  19.5093 4.02176 0.290085
Vertex 133  -10.9267 -2.98422 -8.73647
Vertex 134  -10.9992 -3.74193 -7.85734
Vertex 135  -10.8725 -2.98623 -8.15301
Vertex 136  9.01751 -0.830129 0.199173
Vertex 137  18.9841 4.03192 0.191109
Vertex 138  15.7159 -1.05377 0.243501
Vertex 139  -10.8341 -3.57906 7.51761
Vertex 140  -5.75294 -1.70342 2.46916
Vertex 141  -2.55951 -0.481386 1.56852
Vertex 142  -4.53111 -0.461747 1.57312
Vertex 143  -10.8977 -3.62409 8.11986
Vertex 144  -10.9888 -2.88766 7.52823
Vertex 145  18.2931 5.02525 0.231181
Vertex 146  -0.797783 -3.65046 -6.91484
Vertex 147  -0.727876 -3.76185 -8.67229
Vertex 148  -0.221925 -3.87452 -6.96214
Vertex 149  -3.53483 -1.66275 -2.56435
Vertex 150  -4.51184 -0.474176 -1.57239
Vertex 151  -2.5496 -0.518823 -1.57355
Vertex 152  17.9364 -2.5965 0.875425
Vertex 153  18.1362 4.06445 -0.213771
Vertex 154  -0.500571 -3.80422 6.98172
Vertex 155  1.89831 -4.04665 9.17964
Vertex 156  -0.107641 -3.90075 8.60855
Vertex 157  -10.1703 -3.91777 9.19468
Vertex 158  -2.87451 -3.68042 13.2994
Vertex 159  -15.7825 -3.7188 1.9209
Vertex 160  -10.1796 -4.00965 -9.18925
Vertex 161  -6.66847 -3.28092 -22.1023
Vertex 162  4.31389 -0.651154 1.41559
Vertex 163  -3.53113 -1.61347 2.55292
Vertex 164  0.433884 -0.582514 1.54366
Vertex 165  -7.25432 -4.41878 2.63562
Vertex 166  4.29944 -0.637923 -1.39304
Vertex 167  4.29738 -1.64236 -2.23572
Vertex 168  2.0649 -0.647234 -1.44438
Vertex 169  0.436211 -0.587284 -1.53176
Vertex 170  2.06066 -1.60696 -2.16935
Vertex 171  0.43847 -1.56637 -2.31813
Vertex 172  -0.161153 -0.595432 -1.55352
Vertex 173  -0.155476 -4.6494 2.29512
Vertex 174  -7.5843 -0.482669 1.44317
Vertex 175  17.6236 4.04994 -0.197454
Vertex 176  4.78088 -1.69215 2.19724
Vertex 177  2.06253 -0.645579 1.45547
Vertex 178  5.92868 -0.800311 1.32182
Vertex 179  -2.30035 -4.12298 6.43014
Vertex 180  -5.22995 -4.1043 -2.48562
Vertex 181  -2.34961 -4.32589 -2.44089
Vertex 182  -10.4597 -1.50028 0.0107484
Vertex 183  6.01935 -4.9906 0.538016
Vertex 184  -12.7776 -4.72668 -1.92254
Vertex 185  -2.2113 -3.63405 19.1134
Vertex 186  17.9329 -2.14106 0.233672
Vertex 187  -6.34083 -3.04867 22.1537
Vertex 188  -18.594 -3.59686 -0.850123
Vertex 189  -1.80655 -0.513929 1.59308
Vertex 190  -0.0442178 -1.05337 2.05687
Vertex 191  -1.80483 -1.52721 2.38196
Vertex 192  -10.9788 -2.96562 -7.40955
Vertex 193  6.62733 -4.39231 -1.88787
Vertex 194  -10.7185 -3.23019 8.88245
Vertex 195  -6.66258 -4.22551 -2.65608
Vertex 196  0.113585 -4.72375 7.03528
Vertex 197  -10.9794 -3.53973 -6.91143
Vertex 198  -10.7174 -3.25631 -6.7385
Vertex 199  -10.7323 -3.27169 -7.28108
Vertex 200  0.120021 -4.64414 -7.0153
Vertex 201  12.5309 -2.58367 1.49134
Vertex 202  5.85763 -0.436522 -0.174432
Vertex 203  -7.42621 -4.5569 -2.14161
Vertex 204  -6.56681 -0.361699 -1.54156
Vertex 205  -1.38067 -0.219921 0.0537108
Vertex 206  -4.52018 -0.180127 -0.0995772
Vertex 207  -6.69859 -3.26684 22.1023
Vertex 208  -10.8643 -3.45108 -8.91629
Vertex 209  -4.73055 -3.71208 -6.01487
Vertex 210  18.9719 4.02605 -0.161307
Vertex 211  -10.9657 -3.4203 6.72008
Vertex 212  -10.9469 -3.06758 7.39378
Vertex 213  -10.7604 -3.51892 -8.13956
Vertex 214  -10.6956 -3.39843 -6.73132
Vertex 215  -10.9269 -3.03472 -6.74505
Vertex 216  -10.9668 -3.43513 -6.70503
Vertex 217  -10.086 -2.6029 -7.04492
Vertex 218  1.88239 -4.21696 -9.43036
Vertex 219  -10.7647 -3.41076 8.89897
Vertex 220  -10.7081 -3.32619 8.2115
Vertex 221  -10.7824 -3.32873 8.24463
Vertex 222  -10.7836 -3.34609 8.24264
Vertex 223  -10.7301 -3.36097 6.73802
Vertex 224  -10.7259 -3.29055 7.39937
Vertex 225  -10.7061 -3.23231 6.74842
Vertex 226  -10.7993 -3.04093 8.0836
Vertex 227  -2.67724 -4.56771 6.42878
Vertex 228  -2.17541 -4.33423 2.41826
Vertex 229  -10.1199 -3.08132 9.15233
Vertex 230  -18.6137 -4.13116 0.260052
Vertex 231  -11.1057 -3.00842 -7.31792
Vertex 232  -11.2548 -3.78379 -7.73023
Vertex 233  13.0489 -2.36527 -1.4537
Vertex 234  1.88226 -4.26161 6.37999
Vertex 235  -7.34806 -4.34749 -6.42995
Vertex 236  -6.60953 -4.32779 -10.2621
Vertex 237  -10.7778 -3.57402 -7.45905
Vertex 238  -3.58889 -3.34245 19.1058
Vertex 239  -3.41283 -3.34426 -19.1126
Vertex 240  -3.17376 -3.66956 -13.2955
Vertex 241  -3.73098 -3.31078 -19.1087
Vertex 242  -8.7713 -1.98459 2.02962
Vertex 243  0.108643 -4.78798 8.63168
Vertex 244  -10.6705 -3.12961 -8.85484
Vertex 245  18.9466 -2.34038 -0.501887
Vertex 246  -18.6536 -2.75862 0.874513
Vertex 247  -6.30475 -3.09574 -22.1006
Vertex 248  16.7613 4.11029 0.247038
Vertex 249  -10.7726 -3.07436 8.76595
Vertex 250  -10.6979 -3.2099 -8.1977
Vertex 251  -7.88719 -2.79595 6.52165
Vertex 252  -10.6437 -2.93944 -7.44027
Vertex 253  -3.44249 0.509074 -0.00321054
Vertex 254  -3.82656 0.497653 -0.0328462
Vertex 255  -3.8266 0.497674 0.0318818
Vertex 256  -11.2992 -3.61146 8.18574
Vertex 257  -10.7101 -3.33316 -8.87937
Vertex 258  -10.1897 -4.33301 7.82632
Vertex 259  -0.246129 -3.86686 -8.62854
Vertex 260  -0.132844 -4.65091 -2.49338
Vertex 261  -3.74921 -3.63669 19.1115
Vertex 262  -8.76556 -1.96748 -2.06073
Vertex 263  -8.26894 -2.00362 2.27298
Vertex 264  -0.157205 -0.257352 -0.101252
Vertex 265  -10.9386 -3.10207 8.91951
Vertex 266  -7.27698 -4.44622 2.40803
Vertex 267  -5.56821 -4.57212 -8.98866
Vertex 268  -11.3521 -4.84434 -10.6985
Vertex 269  18.7598 5.13164 0.0765112
Vertex 270  -0.106297 -4.62612 2.24659
Vertex 271  1.8883 -4.17104 9.36989
Vertex 272  -10.685 -3.02375 7.42784
Face 1  2 3 4 {rgb=(1 0 0) matid=3}
Face 2  18 17 19 {rgb=(1 0 0) matid=3}
Face 3  251 40 39 {rgb=(.9 .9 .9) matid=0}
Face 4  14 16 15 {rgb=(1 0 0) matid=3}
Face 5  7 6 5 {rgb=(1 0 0) matid=3}
Face 6  6 7 8 {rgb=(1 0 0) matid=3}
Face 7  12 14 15 {rgb=(1 0 0) matid=3}
Face 8  234 37 38 {rgb=(.9 .9 .9) matid=0}
Face 9  13 12 16 {rgb=(1 0 0) matid=3}
Face 10  42 45 256 {rgb=(1 0 0) matid=3}
Face 11  19 46 18 {rgb=(1 0 0) matid=3}
Face 12  8 5 6 {rgb=(1 0 0) matid=3}
Face 13  21 20 22 {rgb=(1 0 0) matid=3}
Face 14  37 211 38 {rgb=(.9 .9 .9) matid=0}
Face 15  9 47 10 {rgb=(1 0 0) matid=3}
Face 16  217 35 36 {rgb=(.9 .9 .9) matid=0}
Face 17  8 7 5 {rgb=(1 0 0) matid=3}
Face 18  29 30 31 {rgb=(.9 .9 .9) matid=0}
Face 19  23 22 20 {rgb=(1 0 0) matid=3}
Face 20  229 271 155 {rgb=(.9 .9 .9) matid=0}
Face 21  26 25 24 {rgb=(1 0 0) matid=3}
Face 22  13 14 12 {rgb=(1 0 0) matid=3}
Face 23  10 47 11 {rgb=(1 0 0) matid=3}
Face 24  28 30 29 {rgb=(.9 .9 .9) matid=0}
Face 25  28 32 31 {rgb=(.9 .9 .9) matid=0}
Face 26  1 2 4 {rgb=(1 0 0) matid=3}
Face 27  14 13 16 {rgb=(1 0 0) matid=3}
Face 28  28 31 30 {rgb=(.9 .9 .9) matid=0}
Face 29  42 44 45 {rgb=(1 0 0) matid=3}
Face 30  4 3 1 {rgb=(1 0 0) matid=3}
Face 31  28 231 32 {rgb=(.9 .9 .9) matid=0}
Face 32  23 21 22 {rgb=(1 0 0) matid=3}
Face 33  43 42 256 {rgb=(1 0 0) matid=3}
Face 34  32 231 31 {rgb=(.9 .9 .9) matid=0}
Face 35  91 58 69 {rgb=(.9 .9 .9) matid=0}
Face 36  12 15 16 {rgb=(1 0 0) matid=3}
Face 37  33 36 133 {rgb=(.9 .9 .9) matid=0}
Face 38  68 26 24 {rgb=(1 0 0) matid=3}
Face 39  41 44 43 {rgb=(1 0 0) matid=3}
Face 40  9 11 47 {rgb=(1 0 0) matid=3}
Face 41  34 209 33 {rgb=(.9 .9 .9) matid=0}
Face 42  26 193 183 {rgb=(1 0 0) matid=3}
Face 43  41 45 44 {rgb=(1 0 0) matid=3}
Face 44  42 43 44 {rgb=(1 0 0) matid=3}
Face 45  46 17 18 {rgb=(1 0 0) matid=3}
Face 46  21 23 20 {rgb=(1 0 0) matid=3}
Face 47  19 17 46 {rgb=(1 0 0) matid=3}
Face 48  1 3 2 {rgb=(1 0 0) matid=3}
Face 49  268 11 9 {rgb=(1 0 0) matid=3}
Face 50  267 160 218 {rgb=(.9 .9 .9) matid=0}
Face 51  260 193 99 {rgb=(1 0 0) matid=3}
Face 52  66 202 245 {rgb=(1 0 0) matid=3}
Face 53  113 178 176 {rgb=(1 0 0) matid=3}
Face 54  113 48 136 {rgb=(1 0 0) matid=3}
Face 55  26 99 193 {rgb=(1 0 0) matid=3}
Face 56  236 51 61 {rgb=(.9 .9 .9) matid=0}
Face 57  247 88 161 {rgb=(0 0 0) matid=1}
Face 58  60 61 51 {rgb=(.9 .9 .9) matid=0}
Face 59  119 52 86 {rgb=(.9 .9 .9) matid=0}
Face 60  59 165 69 {rgb=(.9 .9 .9) matid=0}
Face 61  186 138 136 {rgb=(.9 .9 .9) matid=0}
Face 62  193 260 109 {rgb=(1 0 0) matid=3}
Face 63  67 100 55 {rgb=(1 0 0) matid=3}
Face 64  184 26 68 {rgb=(1 0 0) matid=3}
Face 65  173 55 100 {rgb=(1 0 0) matid=3}
Face 66  183 115 55 {rgb=(1 0 0) matid=3}
Face 67  233 66 245 {rgb=(1 0 0) matid=3}
Face 68  203 26 184 {rgb=(1 0 0) matid=3}
Face 69  260 80 109 {rgb=(1 0 0) matid=3}
Face 70  27 56 130 {rgb=(1 0 0) matid=3}
Face 71  98 58 91 {rgb=(.9 .9 .9) matid=0}
Face 72  24 52 58 {rgb=(.9 .9 .9) matid=0}
Face 73  85 119 86 {rgb=(.9 .9 .9) matid=0}
Face 74  101 100 59 {rgb=(.9 .9 .9) matid=0}
Face 75  195 74 62 {rgb=(.9 .9 .9) matid=0}
Face 76  27 50 60 {rgb=(.9 .9 .9) matid=0}
Face 77  50 61 60 {rgb=(.9 .9 .9) matid=0}
Face 78  50 236 61 {rgb=(.9 .9 .9) matid=0}
Face 79  26 236 50 {rgb=(.9 .9 .9) matid=0}
Face 80  26 77 236 {rgb=(.9 .9 .9) matid=0}
Face 81  132 137 186 {rgb=(.9 .9 .9) matid=0}
Face 82  97 112 63 {rgb=(.9 .9 .9) matid=0}
Face 83  53 107 186 {rgb=(.9 .9 .9) matid=0}
Face 84  248 63 78 {rgb=(0 0 0) matid=1}
Face 85  53 65 120 {rgb=(.9 .9 .9) matid=0}
Face 86  53 202 65 {rgb=(.9 .9 .9) matid=0}
Face 87  262 204 131 {rgb=(1 0 0) matid=3}
Face 88  141 49 205 {rgb=(1 0 0) matid=3}
Face 89  103 174 123 {rgb=(1 0 0) matid=3}
Face 90  188 230 102 {rgb=(0 0 0) matid=1}
Face 91  54 68 24 {rgb=(1 0 0) matid=3}
Face 92  266 104 159 {rgb=(1 0 0) matid=3}
Face 93  117 187 70 {rgb=(.9 .9 .9) matid=0}
Face 94  117 59 187 {rgb=(.9 .9 .9) matid=0}
Face 95  58 70 207 {rgb=(0 0 0) matid=1}
Face 96  58 52 70 {rgb=(.9 .9 .9) matid=0}
Face 97  55 113 176 {rgb=(1 0 0) matid=3}
Face 98  72 105 89 {rgb=(.9 .9 .9) matid=0}
Face 99  82 72 71 {rgb=(.9 .9 .9) matid=0}
Face 100  82 73 72 {rgb=(.9 .9 .9) matid=0}
Face 101  152 73 82 {rgb=(.9 .9 .9) matid=0}
Face 102  152 90 73 {rgb=(.9 .9 .9) matid=0}
Face 103  94 74 180 {rgb=(.9 .9 .9) matid=0}
Face 104  241 51 247 {rgb=(.9 .9 .9) matid=0}
Face 105  154 75 251 {rgb=(.9 .9 .9) matid=0}
Face 106  155 76 75 {rgb=(.9 .9 .9) matid=0}
Face 107  157 271 229 {rgb=(.9 .9 .9) matid=0}
Face 108  37 234 196 {rgb=(.9 .9 .9) matid=0}
Face 109  27 203 184 {rgb=(1 0 0) matid=3}
Face 110  180 74 195 {rgb=(.9 .9 .9) matid=0}
Face 111  107 132 186 {rgb=(.9 .9 .9) matid=0}
Face 112  64 79 269 {rgb=(.9 .9 .9) matid=0}
Face 113  65 210 120 {rgb=(.9 .9 .9) matid=0}
Face 114  97 63 110 {rgb=(0 0 0) matid=1}
Face 115  57 80 260 {rgb=(1 0 0) matid=3}
Face 116  92 109 80 {rgb=(.9 .9 .9) matid=0}
Face 117  57 106 93 {rgb=(0 0 0) matid=1}
Face 118  87 109 92 {rgb=(.9 .9 .9) matid=0}
Face 119  111 82 201 {rgb=(0 0 0) matid=1}
Face 120  111 152 82 {rgb=(.9 .9 .9) matid=0}
Face 121  35 83 84 {rgb=(.9 .9 .9) matid=0}
Face 122  35 217 147 {rgb=(.9 .9 .9) matid=0}
Face 123  200 84 83 {rgb=(.9 .9 .9) matid=0}
Face 124  34 160 267 {rgb=(.9 .9 .9) matid=0}
Face 125  25 85 86 {rgb=(.7 .7 .7) matid=2}
Face 126  101 158 179 {rgb=(.9 .9 .9) matid=0}
Face 127  24 227 52 {rgb=(.9 .9 .9) matid=0}
Face 128  24 25 86 {rgb=(.7 .7 .7) matid=2}
Face 129  233 87 81 {rgb=(.9 .9 .9) matid=0}
Face 130  233 245 87 {rgb=(1 0 0) matid=3}
Face 131  51 88 247 {rgb=(.9 .9 .9) matid=0}
Face 132  51 236 88 {rgb=(.9 .9 .9) matid=0}
Face 133  71 89 105 {rgb=(.9 .9 .9) matid=0}
Face 134  71 72 89 {rgb=(.9 .9 .9) matid=0}
Face 135  71 90 48 {rgb=(1 0 0) matid=3}
Face 136  71 73 90 {rgb=(.9 .9 .9) matid=0}
Face 137  165 91 69 {rgb=(.9 .9 .9) matid=0}
Face 138  165 98 91 {rgb=(0 0 0) matid=1}
Face 139  106 92 93 {rgb=(.9 .9 .9) matid=0}
Face 140  81 87 92 {rgb=(.9 .9 .9) matid=0}
Face 141  80 93 92 {rgb=(.9 .9 .9) matid=0}
Face 142  80 57 93 {rgb=(0 0 0) matid=1}
Face 143  60 94 27 {rgb=(.9 .9 .9) matid=0}
Face 144  240 74 94 {rgb=(.9 .9 .9) matid=0}
Face 145  63 95 78 {rgb=(0 0 0) matid=1}
Face 146  63 112 96 {rgb=(.9 .9 .9) matid=0}
Face 147  95 96 136 {rgb=(.9 .9 .9) matid=0}
Face 148  95 63 96 {rgb=(.9 .9 .9) matid=0}
Face 149  65 97 210 {rgb=(.9 .9 .9) matid=0}
Face 150  65 112 97 {rgb=(.9 .9 .9) matid=0}
Face 151  24 98 54 {rgb=(.9 .9 .9) matid=0}
Face 152  24 58 98 {rgb=(.9 .9 .9) matid=0}
Face 153  50 99 26 {rgb=(.9 .9 .9) matid=0}
Face 154  50 27 99 {rgb=(.9 .9 .9) matid=0}
Face 155  266 100 104 {rgb=(1 0 0) matid=3}
Face 156  165 59 100 {rgb=(.9 .9 .9) matid=0}
Face 157  173 228 179 {rgb=(.7 .7 .7) matid=2}
Face 158  173 100 228 {rgb=(1 0 0) matid=3}
Face 159  104 246 159 {rgb=(1 0 0) matid=3}
Face 160  104 182 246 {rgb=(1 0 0) matid=3}
Face 161  56 262 131 {rgb=(1 0 0) matid=3}
Face 162  56 102 182 {rgb=(1 0 0) matid=3}
Face 163  140 104 100 {rgb=(1 0 0) matid=3}
Face 164  174 182 242 {rgb=(.7 .7 .7) matid=2}
Face 165  73 105 72 {rgb=(.9 .9 .9) matid=0}
Face 166  73 71 105 {rgb=(.9 .9 .9) matid=0}
Face 167  81 106 233 {rgb=(.9 .9 .9) matid=0}
Face 168  81 108 106 {rgb=(.9 .9 .9) matid=0}
Face 169  64 107 53 {rgb=(.9 .9 .9) matid=0}
Face 170  64 269 107 {rgb=(.9 .9 .9) matid=0}
Face 171  116 108 81 {rgb=(.9 .9 .9) matid=0}
Face 172  116 106 108 {rgb=(.9 .9 .9) matid=0}
Face 173  245 109 87 {rgb=(1 0 0) matid=3}
Face 174  245 115 109 {rgb=(1 0 0) matid=3}
Face 175  79 110 145 {rgb=(.9 .9 .9) matid=0}
Face 176  175 97 110 {rgb=(0 0 0) matid=1}
Face 177  114 111 201 {rgb=(1 0 0) matid=3}
Face 178  114 152 111 {rgb=(1 0 0) matid=3}
Face 179  202 112 65 {rgb=(.9 .9 .9) matid=0}
Face 180  264 96 112 {rgb=(.9 .9 .9) matid=0}
Face 181  71 113 114 {rgb=(1 0 0) matid=3}
Face 182  71 48 113 {rgb=(1 0 0) matid=3}
Face 183  55 114 113 {rgb=(.7 .7 .7) matid=2}
Face 184  55 115 114 {rgb=(1 0 0) matid=3}
Face 185  48 115 53 {rgb=(1 0 0) matid=3}
Face 186  152 114 115 {rgb=(1 0 0) matid=3}
Face 187  92 116 81 {rgb=(.9 .9 .9) matid=0}
Face 188  92 106 116 {rgb=(.9 .9 .9) matid=0}
Face 189  185 117 70 {rgb=(.9 .9 .9) matid=0}
Face 190  118 238 117 {rgb=(.9 .9 .9) matid=0}
Face 191  185 118 117 {rgb=(.9 .9 .9) matid=0}
Face 192  185 119 118 {rgb=(.7 .7 .7) matid=2}
Face 193  158 119 85 {rgb=(.9 .9 .9) matid=0}
Face 194  158 118 119 {rgb=(.7 .7 .7) matid=2}
Face 195  64 120 79 {rgb=(.9 .9 .9) matid=0}
Face 196  64 53 120 {rgb=(.9 .9 .9) matid=0}
Face 197  57 167 128 {rgb=(1 0 0) matid=3}
Face 198  57 260 167 {rgb=(1 0 0) matid=3}
Face 199  124 205 264 {rgb=(1 0 0) matid=3}
Face 200  123 141 122 {rgb=(1 0 0) matid=3}
Face 201  124 123 206 {rgb=(1 0 0) matid=3}
Face 202  124 150 123 {rgb=(1 0 0) matid=3}
Face 203  66 166 202 {rgb=(1 0 0) matid=3}
Face 204  125 167 166 {rgb=(.3 .3 .3) matid=4}
Face 205  126 127 166 {rgb=(.3 .3 .3) matid=4}
Face 206  66 233 128 {rgb=(1 0 0) matid=3}
Face 207  66 126 166 {rgb=(.3 .3 .3) matid=4}
Face 208  66 128 126 {rgb=(.3 .3 .3) matid=4}
Face 209  125 127 126 {rgb=(.7 .7 .7) matid=2}
Face 210  125 166 127 {rgb=(.3 .3 .3) matid=4}
Face 211  125 128 167 {rgb=(.3 .3 .3) matid=4}
Face 212  129 126 128 {rgb=(.3 .3 .3) matid=4}
Face 213  125 129 128 {rgb=(.3 .3 .3) matid=4}
Face 214  125 126 129 {rgb=(.7 .7 .7) matid=2}
Face 215  149 130 204 {rgb=(1 0 0) matid=3}
Face 216  121 27 130 {rgb=(1 0 0) matid=3}
Face 217  130 131 204 {rgb=(.7 .7 .7) matid=2}
Face 218  130 56 131 {rgb=(1 0 0) matid=3}
Face 219  145 132 107 {rgb=(.9 .9 .9) matid=0}
Face 220  78 137 132 {rgb=(.9 .9 .9) matid=0}
Face 221  134 133 36 {rgb=(.9 .9 .9) matid=0}
Face 222  135 33 133 {rgb=(.9 .9 .9) matid=0}
Face 223  34 134 160 {rgb=(.9 .9 .9) matid=0}
Face 224  34 33 216 {rgb=(.9 .9 .9) matid=0}
Face 225  134 213 208 {rgb=(.9 .9 .9) matid=0}
Face 226  134 34 197 {rgb=(.9 .9 .9) matid=0}
Face 227  49 136 96 {rgb=(.9 .9 .9) matid=0}
Face 228  49 141 162 {rgb=(1 0 0) matid=3}
Face 229  138 137 78 {rgb=(.9 .9 .9) matid=0}
Face 230  138 186 137 {rgb=(.9 .9 .9) matid=0}
Face 231  95 138 78 {rgb=(.9 .9 .9) matid=0}
Face 232  95 136 138 {rgb=(.9 .9 .9) matid=0}
Face 233  229 265 157 {rgb=(.9 .9 .9) matid=0}
Face 234  40 38 144 {rgb=(.9 .9 .9) matid=0}
Face 235  163 140 100 {rgb=(1 0 0) matid=3}
Face 236  142 123 174 {rgb=(1 0 0) matid=3}
Face 237  142 141 123 {rgb=(1 0 0) matid=3}
Face 238  164 177 141 {rgb=(1 0 0) matid=3}
Face 239  163 142 140 {rgb=(1 0 0) matid=3}
Face 240  163 141 142 {rgb=(.7 .7 .7) matid=2}
Face 241  144 249 40 {rgb=(.9 .9 .9) matid=0}
Face 242  139 37 143 {rgb=(.9 .9 .9) matid=0}
Face 243  211 144 38 {rgb=(.9 .9 .9) matid=0}
Face 244  212 143 144 {rgb=(.9 .9 .9) matid=0}
Face 245  78 145 248 {rgb=(.9 .9 .9) matid=0}
Face 246  78 132 145 {rgb=(.9 .9 .9) matid=0}
Face 247  209 146 217 {rgb=(.9 .9 .9) matid=0}
Face 248  83 35 148 {rgb=(.9 .9 .9) matid=0}
Face 249  146 147 217 {rgb=(.9 .9 .9) matid=0}
Face 250  259 35 147 {rgb=(.9 .9 .9) matid=0}
Face 251  146 148 147 {rgb=(0 0 0) matid=1}
Face 252  146 83 148 {rgb=(.9 .9 .9) matid=0}
Face 253  121 149 124 {rgb=(1 0 0) matid=3}
Face 254  121 130 149 {rgb=(1 0 0) matid=3}
Face 255  151 150 124 {rgb=(1 0 0) matid=3}
Face 256  149 204 150 {rgb=(1 0 0) matid=3}
Face 257  149 151 124 {rgb=(1 0 0) matid=3}
Face 258  149 150 151 {rgb=(.7 .7 .7) matid=2}
Face 259  48 152 115 {rgb=(1 0 0) matid=3}
Face 260  48 90 152 {rgb=(1 0 0) matid=3}
Face 261  175 153 97 {rgb=(.9 .9 .9) matid=0}
Face 262  79 120 153 {rgb=(.9 .9 .9) matid=0}
Face 263  39 154 251 {rgb=(.9 .9 .9) matid=0}
Face 264  156 75 154 {rgb=(.9 .9 .9) matid=0}
Face 265  156 155 75 {rgb=(.9 .9 .9) matid=0}
Face 266  39 40 155 {rgb=(.9 .9 .9) matid=0}
Face 267  39 156 154 {rgb=(0 0 0) matid=1}
Face 268  39 155 156 {rgb=(.9 .9 .9) matid=0}
Face 269  37 258 143 {rgb=(.9 .9 .9) matid=0}
Face 270  37 196 258 {rgb=(.9 .9 .9) matid=0}
Face 271  238 158 101 {rgb=(.9 .9 .9) matid=0}
Face 272  238 118 158 {rgb=(.7 .7 .7) matid=2}
Face 273  230 159 246 {rgb=(1 0 0) matid=3}
Face 274  68 266 159 {rgb=(1 0 0) matid=3}
Face 275  36 160 134 {rgb=(.9 .9 .9) matid=0}
Face 276  36 218 160 {rgb=(.9 .9 .9) matid=0}
Face 277  62 161 88 {rgb=(0 0 0) matid=1}
Face 278  62 74 161 {rgb=(0 0 0) matid=1}
Face 279  136 178 113 {rgb=(1 0 0) matid=3}
Face 280  136 49 162 {rgb=(1 0 0) matid=3}
Face 281  191 163 100 {rgb=(1 0 0) matid=3}
Face 282  189 141 163 {rgb=(1 0 0) matid=3}
Face 283  189 164 141 {rgb=(1 0 0) matid=3}
Face 284  67 177 164 {rgb=(.7 .7 .7) matid=2}
Face 285  54 165 100 {rgb=(.9 .9 .9) matid=0}
Face 286  54 98 165 {rgb=(.9 .9 .9) matid=0}
Face 287  124 168 169 {rgb=(1 0 0) matid=3}
Face 288  124 202 166 {rgb=(1 0 0) matid=3}
Face 289  121 167 260 {rgb=(1 0 0) matid=3}
Face 290  170 166 167 {rgb=(1 0 0) matid=3}
Face 291  166 168 124 {rgb=(1 0 0) matid=3}
Face 292  166 170 168 {rgb=(1 0 0) matid=3}
Face 293  171 169 168 {rgb=(.7 .7 .7) matid=2}
Face 294  172 124 169 {rgb=(1 0 0) matid=3}
Face 295  171 170 167 {rgb=(1 0 0) matid=3}
Face 296  171 168 170 {rgb=(.7 .7 .7) matid=2}
Face 297  121 171 167 {rgb=(1 0 0) matid=3}
Face 298  121 169 171 {rgb=(1 0 0) matid=3}
Face 299  121 172 169 {rgb=(1 0 0) matid=3}
Face 300  121 124 172 {rgb=(.7 .7 .7) matid=2}
Face 301  25 173 85 {rgb=(.7 .7 .7) matid=2}
Face 302  270 55 173 {rgb=(1 0 0) matid=3}
Face 303  140 174 263 {rgb=(.7 .7 .7) matid=2}
Face 304  140 142 174 {rgb=(1 0 0) matid=3}
Face 305  79 175 110 {rgb=(.9 .9 .9) matid=0}
Face 306  79 153 175 {rgb=(.9 .9 .9) matid=0}
Face 307  67 176 177 {rgb=(1 0 0) matid=3}
Face 308  67 55 176 {rgb=(1 0 0) matid=3}
Face 309  162 177 176 {rgb=(1 0 0) matid=3}
Face 310  162 141 177 {rgb=(1 0 0) matid=3}
Face 311  162 178 136 {rgb=(1 0 0) matid=3}
Face 312  162 176 178 {rgb=(.7 .7 .7) matid=2}
Face 313  85 179 158 {rgb=(.9 .9 .9) matid=0}
Face 314  85 173 179 {rgb=(.7 .7 .7) matid=2}
Face 315  27 180 203 {rgb=(1 0 0) matid=3}
Face 316  181 94 180 {rgb=(.9 .9 .9) matid=0}
Face 317  27 181 180 {rgb=(1 0 0) matid=3}
Face 318  27 94 181 {rgb=(.9 .9 .9) matid=0}
Face 319  103 182 174 {rgb=(.7 .7 .7) matid=2}
Face 320  262 56 182 {rgb=(1 0 0) matid=3}
Face 321  25 270 173 {rgb=(1 0 0) matid=3}
Face 322  25 26 183 {rgb=(1 0 0) matid=3}
Face 323  56 188 102 {rgb=(1 0 0) matid=3}
Face 324  56 27 184 {rgb=(1 0 0) matid=3}
Face 325  52 261 70 {rgb=(.9 .9 .9) matid=0}
Face 326  52 119 261 {rgb=(.7 .7 .7) matid=2}
Face 327  48 186 136 {rgb=(1 0 0) matid=3}
Face 328  48 53 186 {rgb=(1 0 0) matid=3}
Face 329  69 187 59 {rgb=(.9 .9 .9) matid=0}
Face 330  69 58 207 {rgb=(0 0 0) matid=1}
Face 331  184 188 56 {rgb=(1 0 0) matid=3}
Face 332  184 230 188 {rgb=(1 0 0) matid=3}
Face 333  67 190 100 {rgb=(1 0 0) matid=3}
Face 334  67 164 190 {rgb=(1 0 0) matid=3}
Face 335  189 190 164 {rgb=(1 0 0) matid=3}
Face 336  191 100 190 {rgb=(1 0 0) matid=3}
Face 337  189 191 190 {rgb=(.7 .7 .7) matid=2}
Face 338  189 163 191 {rgb=(1 0 0) matid=3}
Face 339  135 215 33 {rgb=(.9 .9 .9) matid=0}
Face 340  135 237 192 {rgb=(.9 .9 .9) matid=0}
Face 341  115 193 109 {rgb=(1 0 0) matid=3}
Face 342  115 183 193 {rgb=(1 0 0) matid=3}
Face 343  220 194 226 {rgb=(1 0 0) matid=3}
Face 344  265 40 249 {rgb=(.9 .9 .9) matid=0}
Face 345  77 235 62 {rgb=(.9 .9 .9) matid=0}
Face 346  77 180 195 {rgb=(.9 .9 .9) matid=0}
Face 347  76 196 234 {rgb=(.9 .9 .9) matid=0}
Face 348  243 258 196 {rgb=(.9 .9 .9) matid=0}
Face 349  216 197 34 {rgb=(.9 .9 .9) matid=0}
Face 350  214 237 197 {rgb=(0 0 0) matid=1}
Face 351  192 198 197 {rgb=(0 0 0) matid=1}
Face 352  199 237 214 {rgb=(1 0 0) matid=3}
Face 353  192 252 198 {rgb=(0 0 0) matid=1}
Face 354  192 237 199 {rgb=(0 0 0) matid=1}
Face 355  34 200 209 {rgb=(.9 .9 .9) matid=0}
Face 356  34 84 200 {rgb=(.9 .9 .9) matid=0}
Face 357  71 201 82 {rgb=(0 0 0) matid=1}
Face 358  71 114 201 {rgb=(1 0 0) matid=3}
Face 359  264 202 124 {rgb=(1 0 0) matid=3}
Face 360  264 112 202 {rgb=(.9 .9 .9) matid=0}
Face 361  77 203 180 {rgb=(.9 .9 .9) matid=0}
Face 362  77 26 203 {rgb=(.9 .9 .9) matid=0}
Face 363  123 204 103 {rgb=(1 0 0) matid=3}
Face 364  123 150 204 {rgb=(1 0 0) matid=3}
Face 365  206 205 124 {rgb=(1 0 0) matid=3}
Face 366  122 141 205 {rgb=(1 0 0) matid=3}
Face 367  253 206 123 {rgb=(.9 .9 .9) matid=0}
Face 368  122 205 206 {rgb=(1 0 0) matid=3}
Face 369  187 207 70 {rgb=(0 0 0) matid=1}
Face 370  187 69 207 {rgb=(0 0 0) matid=1}
Face 371  133 208 244 {rgb=(0 0 0) matid=1}
Face 372  133 134 208 {rgb=(.9 .9 .9) matid=0}
Face 373  83 209 200 {rgb=(.9 .9 .9) matid=0}
Face 374  83 146 209 {rgb=(.9 .9 .9) matid=0}
Face 375  153 210 97 {rgb=(.9 .9 .9) matid=0}
Face 376  153 120 210 {rgb=(.9 .9 .9) matid=0}
Face 377  139 211 37 {rgb=(.9 .9 .9) matid=0}
Face 378  212 144 211 {rgb=(.9 .9 .9) matid=0}
Face 379  139 224 223 {rgb=(1 0 0) matid=3}
Face 380  139 143 212 {rgb=(.9 .9 .9) matid=0}
Face 381  135 213 134 {rgb=(.9 .9 .9) matid=0}
Face 382  250 257 213 {rgb=(1 0 0) matid=3}
Face 383  198 214 197 {rgb=(0 0 0) matid=1}
Face 384  198 199 214 {rgb=(1 0 0) matid=3}
Face 385  192 215 135 {rgb=(.9 .9 .9) matid=0}
Face 386  216 33 215 {rgb=(.9 .9 .9) matid=0}
Face 387  192 216 215 {rgb=(.9 .9 .9) matid=0}
Face 388  192 197 216 {rgb=(.9 .9 .9) matid=0}
Face 389  33 217 36 {rgb=(.9 .9 .9) matid=0}
Face 390  33 209 217 {rgb=(.9 .9 .9) matid=0}
Face 391  35 218 36 {rgb=(.9 .9 .9) matid=0}
Face 392  35 84 218 {rgb=(.9 .9 .9) matid=0}
Face 393  221 222 194 {rgb=(1 0 0) matid=3}
Face 394  143 157 219 {rgb=(.9 .9 .9) matid=0}
Face 395  143 220 226 {rgb=(0 0 0) matid=1}
Face 396  143 219 220 {rgb=(1 0 0) matid=3}
Face 397  220 221 194 {rgb=(1 0 0) matid=3}
Face 398  220 222 221 {rgb=(1 0 0) matid=3}
Face 399  219 222 220 {rgb=(1 0 0) matid=3}
Face 400  219 194 222 {rgb=(1 0 0) matid=3}
Face 401  211 223 225 {rgb=(0 0 0) matid=1}
Face 402  211 139 223 {rgb=(0 0 0) matid=1}
Face 403  212 224 139 {rgb=(0 0 0) matid=1}
Face 404  225 223 224 {rgb=(1 0 0) matid=3}
Face 405  272 225 224 {rgb=(1 0 0) matid=3}
Face 406  212 211 225 {rgb=(0 0 0) matid=1}
Face 407  144 226 249 {rgb=(.9 .9 .9) matid=0}
Face 408  144 143 226 {rgb=(.9 .9 .9) matid=0}
Face 409  86 227 24 {rgb=(.7 .7 .7) matid=2}
Face 410  86 52 227 {rgb=(.9 .9 .9) matid=0}
Face 411  101 228 100 {rgb=(1 0 0) matid=3}
Face 412  101 179 228 {rgb=(.9 .9 .9) matid=0}
Face 413  40 229 155 {rgb=(.9 .9 .9) matid=0}
Face 414  40 265 229 {rgb=(.9 .9 .9) matid=0}
Face 415  68 230 184 {rgb=(1 0 0) matid=3}
Face 416  68 159 230 {rgb=(1 0 0) matid=3}
Face 417  29 232 28 {rgb=(.9 .9 .9) matid=0}
Face 418  29 31 231 {rgb=(.9 .9 .9) matid=0}
Face 419  231 232 29 {rgb=(.9 .9 .9) matid=0}
Face 420  231 28 232 {rgb=(.9 .9 .9) matid=0}
Face 421  57 233 106 {rgb=(0 0 0) matid=1}
Face 422  57 128 233 {rgb=(1 0 0) matid=3}
Face 423  75 234 251 {rgb=(.9 .9 .9) matid=0}
Face 424  75 76 234 {rgb=(.9 .9 .9) matid=0}
Face 425  195 235 77 {rgb=(0 0 0) matid=1}
Face 426  195 62 235 {rgb=(.9 .9 .9) matid=0}
Face 427  62 236 77 {rgb=(.9 .9 .9) matid=0}
Face 428  62 88 236 {rgb=(0 0 0) matid=1}
Face 429  134 237 135 {rgb=(.9 .9 .9) matid=0}
Face 430  134 197 237 {rgb=(.9 .9 .9) matid=0}
Face 431  59 238 101 {rgb=(.9 .9 .9) matid=0}
Face 432  59 117 238 {rgb=(.9 .9 .9) matid=0}
Face 433  60 239 94 {rgb=(.9 .9 .9) matid=0}
Face 434  60 51 239 {rgb=(.9 .9 .9) matid=0}
Face 435  239 240 94 {rgb=(.9 .9 .9) matid=0}
Face 436  241 74 240 {rgb=(.9 .9 .9) matid=0}
Face 437  239 241 240 {rgb=(.9 .9 .9) matid=0}
Face 438  239 51 241 {rgb=(.9 .9 .9) matid=0}
Face 439  104 242 182 {rgb=(1 0 0) matid=3}
Face 440  104 140 263 {rgb=(1 0 0) matid=3}
Face 441  76 243 196 {rgb=(.9 .9 .9) matid=0}
Face 442  271 157 243 {rgb=(.9 .9 .9) matid=0}
Face 443  250 244 257 {rgb=(1 0 0) matid=3}
Face 444  135 133 244 {rgb=(0 0 0) matid=1}
Face 445  53 245 202 {rgb=(1 0 0) matid=3}
Face 446  53 115 245 {rgb=(1 0 0) matid=3}
Face 447  102 246 182 {rgb=(1 0 0) matid=3}
Face 448  102 230 246 {rgb=(0 0 0) matid=1}
Face 449  74 247 161 {rgb=(0 0 0) matid=1}
Face 450  74 241 247 {rgb=(.9 .9 .9) matid=0}
Face 451  110 248 145 {rgb=(.9 .9 .9) matid=0}
Face 452  110 63 248 {rgb=(0 0 0) matid=1}
Face 453  194 249 226 {rgb=(1 0 0) matid=3}
Face 454  194 219 249 {rgb=(0 0 0) matid=1}
Face 455  135 250 213 {rgb=(0 0 0) matid=1}
Face 456  135 244 250 {rgb=(1 0 0) matid=3}
Face 457  38 251 234 {rgb=(.9 .9 .9) matid=0}
Face 458  38 40 251 {rgb=(.9 .9 .9) matid=0}
Face 459  199 252 192 {rgb=(0 0 0) matid=1}
Face 460  199 198 252 {rgb=(1 0 0) matid=3}
Face 461  255 254 123 {rgb=(.9 .9 .9) matid=0}
Face 462  122 206 253 {rgb=(.9 .9 .9) matid=0}
Face 463  253 254 255 {rgb=(.9 .9 .9) matid=0}
Face 464  253 123 254 {rgb=(.9 .9 .9) matid=0}
Face 465  122 255 123 {rgb=(.9 .9 .9) matid=0}
Face 466  122 253 255 {rgb=(.9 .9 .9) matid=0}
Face 467  41 256 45 {rgb=(1 0 0) matid=3}
Face 468  41 43 256 {rgb=(1 0 0) matid=3}
Face 469  208 257 244 {rgb=(0 0 0) matid=1}
Face 470  208 213 257 {rgb=(1 0 0) matid=3}
Face 471  157 258 243 {rgb=(.9 .9 .9) matid=0}
Face 472  157 143 258 {rgb=(.9 .9 .9) matid=0}
Face 473  148 259 147 {rgb=(0 0 0) matid=1}
Face 474  148 35 259 {rgb=(.9 .9 .9) matid=0}
Face 475  27 260 99 {rgb=(1 0 0) matid=3}
Face 476  27 121 260 {rgb=(1 0 0) matid=3}
Face 477  185 261 119 {rgb=(.7 .7 .7) matid=2}
Face 478  185 70 261 {rgb=(.9 .9 .9) matid=0}
Face 479  103 262 182 {rgb=(.7 .7 .7) matid=2}
Face 480  103 204 262 {rgb=(1 0 0) matid=3}
Face 481  242 263 174 {rgb=(1 0 0) matid=3}
Face 482  242 104 263 {rgb=(1 0 0) matid=3}
Face 483  49 264 205 {rgb=(.9 .9 .9) matid=0}
Face 484  49 96 264 {rgb=(.9 .9 .9) matid=0}
Face 485  219 265 249 {rgb=(.9 .9 .9) matid=0}
Face 486  219 157 265 {rgb=(.9 .9 .9) matid=0}
Face 487  54 266 68 {rgb=(1 0 0) matid=3}
Face 488  54 100 266 {rgb=(1 0 0) matid=3}
Face 489  84 267 218 {rgb=(.9 .9 .9) matid=0}
Face 490  84 34 267 {rgb=(.9 .9 .9) matid=0}
Face 491  10 268 9 {rgb=(1 0 0) matid=3}
Face 492  10 11 268 {rgb=(1 0 0) matid=3}
Face 493  145 269 79 {rgb=(.9 .9 .9) matid=0}
Face 494  145 107 269 {rgb=(.9 .9 .9) matid=0}
Face 495  183 270 25 {rgb=(1 0 0) matid=3}
Face 496  183 55 270 {rgb=(1 0 0) matid=3}
Face 497  76 271 243 {rgb=(.9 .9 .9) matid=0}
Face 498  76 155 271 {rgb=(.9 .9 .9) matid=0}
Face 499  212 272 224 {rgb=(0 0 0) matid=1}
Face 500  212 225 272 {rgb=(0 0 0) matid=1}
